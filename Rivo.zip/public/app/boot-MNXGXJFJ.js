"use strict";
(() => {
  // client/shared/lib/storage.ts
  var keys = {
    theme: "rivo-theme",
    accent: "rivo-accent",
    wallpaper: "rivo-wallpaper",
    revealedCapsules: "rivo.revealedCapsules",
    notifyAsked: "rivo.notifyAsked",
    /** a display copy of the signed-in user, for an instant first paint */
    user: "user"
  };
  function read(key) {
    try {
      return window.localStorage.getItem(key);
    } catch {
      return null;
    }
  }

  // client/shared/lib/theme.ts
  var BACKGROUND = { light: "#f7f0f0", dark: "#1a1a1a" };
  var HEX_RE = /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i;
  function normalizeHex(value) {
    if (typeof value !== "string") return null;
    const v = value.trim();
    if (!HEX_RE.test(v)) return null;
    const h = v.slice(1).toLowerCase();
    return h.length === 3 ? `#${h[0]}${h[0]}${h[1]}${h[1]}${h[2]}${h[2]}` : `#${h}`;
  }
  function rgb(hex) {
    const n = parseInt(hex.slice(1), 16);
    return [n >> 16 & 255, n >> 8 & 255, n & 255];
  }
  function darken(hex, percent) {
    const d = Math.round(2.55 * percent);
    return `#${rgb(hex).map((v) => Math.max(0, v - d).toString(16).padStart(2, "0")).join("")}`;
  }
  function alpha(hex, a) {
    const [r, g, b] = rgb(hex);
    return `rgba(${r},${g},${b},${a})`;
  }
  function storedTheme() {
    return read(keys.theme) === "dark" ? "dark" : "light";
  }
  function storedAccent() {
    return normalizeHex(read(keys.accent));
  }
  function currentTheme() {
    return document.documentElement.classList.contains("dark-mode") ? "dark" : "light";
  }
  var ACCENT_VARS = [
    "--accent",
    "--messages-outgoing",
    "--active-chat-bg-color",
    "--active-chat-bg-color-hover",
    "--bold-active-chat-bg-color",
    "--bold-active-chat-bg-color-hover",
    "--accent-gradient-top",
    "--accent-gradient-bottom",
    "--accent-glass"
  ];
  function applyAccent(hex) {
    const style = document.documentElement.style;
    const color = normalizeHex(hex);
    if (!color) {
      for (const v of ACCENT_VARS) style.removeProperty(v);
      return;
    }
    const base = currentTheme() === "dark" ? darken(color, 8) : color;
    style.setProperty("--accent", base);
    style.setProperty("--messages-outgoing", base);
    style.setProperty("--active-chat-bg-color", base);
    style.setProperty("--active-chat-bg-color-hover", darken(base, 5));
    style.setProperty("--bold-active-chat-bg-color", darken(base, 10));
    style.setProperty("--bold-active-chat-bg-color-hover", darken(base, 15));
    style.setProperty("--accent-gradient-top", `radial-gradient(circle at top, ${darken(base, 8)}, ${base})`);
    style.setProperty("--accent-gradient-bottom", `radial-gradient(circle at right, ${darken(base, 8)}, ${base})`);
    style.setProperty("--accent-glass", `linear-gradient(to right, ${alpha(base, 0.21)}, ${alpha(base, 0.21)})`);
  }
  function applyTheme(theme) {
    const root = document.documentElement;
    root.classList.toggle("dark-mode", theme === "dark");
    root.style.colorScheme = theme;
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", BACKGROUND[theme]);
    applyAccent(storedAccent());
  }
  var WALLPAPER_RE = /^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/;
  function storedWallpaper() {
    const v = read(keys.wallpaper);
    return v && WALLPAPER_RE.test(v) ? v : null;
  }
  function applyWallpaper(dataUrl) {
    const style = document.documentElement.style;
    if (dataUrl && WALLPAPER_RE.test(dataUrl)) style.setProperty("--chat-wallpaper", `url("${dataUrl}")`);
    else style.removeProperty("--chat-wallpaper");
  }
  function applyStoredAppearance() {
    applyTheme(storedTheme());
    applyWallpaper(storedWallpaper());
  }

  // client/boot/theme.ts
  try {
    applyStoredAppearance();
  } catch {
  }
})();
//# sourceMappingURL=boot-MNXGXJFJ.js.map
