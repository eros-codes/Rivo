import "./chunks/chunk-RWXBUR7X.js";
import {
  ApiError,
  PasswordInput,
  authApi,
  errorText,
  keys,
  write
} from "./chunks/chunk-OXYREE6K.js";
import {
  require_client,
  require_jsx_runtime,
  require_react
} from "./chunks/chunk-GRWXGSY5.js";
import {
  __toESM
} from "./chunks/chunk-EXRSNSHP.js";

// client/reset/main.tsx
var import_react2 = __toESM(require_react(), 1);
var import_client = __toESM(require_client(), 1);

// client/reset/ResetApp.tsx
var import_react = __toESM(require_react(), 1);
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
var MIN = 8;
var MAX = 128;
var TOKEN_KEY = "rivo.resetToken";
function takeToken() {
  let token = "";
  try {
    const params = new URLSearchParams(window.location.search);
    token = (params.get("token") || "").trim();
    if (token) {
      sessionStorage.setItem(TOKEN_KEY, token);
      history.replaceState(null, "", window.location.pathname);
    } else token = sessionStorage.getItem(TOKEN_KEY) || "";
  } catch {
  }
  return token;
}
function ResetApp() {
  const [token] = (0, import_react.useState)(takeToken);
  const [password, setPassword] = (0, import_react.useState)("");
  const [confirm, setConfirm] = (0, import_react.useState)("");
  const [busy, setBusy] = (0, import_react.useState)(false);
  const [status, setStatus] = (0, import_react.useState)(
    () => token ? { kind: "idle" } : { kind: "dead", text: "This link is not complete. Ask for a new reset link from the sign-in page." }
  );
  const passRef = (0, import_react.useRef)(null);
  const confirmRef = (0, import_react.useRef)(null);
  const locked = busy || status.kind === "done" || status.kind === "dead";
  const submit = async () => {
    if (locked) return;
    if (password.length < MIN) {
      setStatus({ kind: "error", text: `Password must be at least ${MIN} characters.` });
      return passRef.current?.focus();
    }
    if (password.length > MAX) {
      setStatus({ kind: "error", text: "Password is too long." });
      return passRef.current?.focus();
    }
    if (password !== confirm) {
      setStatus({ kind: "error", text: "Passwords do not match." });
      return confirmRef.current?.focus();
    }
    setBusy(true);
    try {
      await authApi.resetPassword(token, password);
      try {
        sessionStorage.removeItem(TOKEN_KEY);
      } catch {
      }
      write(keys.user, null);
      setStatus({ kind: "done" });
      window.setTimeout(() => window.location.replace("/auth/?reset=1"), 1500);
    } catch (e) {
      setBusy(false);
      if (e instanceof ApiError && e.status === 400 && /expired/i.test(e.message)) {
        try {
          sessionStorage.removeItem(TOKEN_KEY);
        } catch {
        }
        setStatus({ kind: "dead", text: "This link has expired or was already used. Ask for a new one from the sign-in page." });
      } else setStatus({ kind: "error", text: errorText(e, "Something went wrong. Please try again.") });
    }
  };
  const message = status.kind === "done" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "auth-notice", role: "status", children: "Your password was changed. Taking you to sign in\u2026" }) : status.kind === "error" || status.kind === "dead" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "input-error code-error", id: "reset-error", role: "alert", children: status.text }) : null;
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { className: "container", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "circle-top", "aria-hidden": "true" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
      "form",
      {
        className: "form password",
        noValidate: true,
        "aria-busy": busy || void 0,
        onSubmit: (e) => {
          e.preventDefault();
          void submit();
        },
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { className: "form-title", children: "Set a New Password" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "form-subtitle", children: "Choose a strong password for your account." }),
          message,
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { htmlFor: "new-password", className: "form-label", children: "New Password" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
            PasswordInput,
            {
              id: "new-password",
              name: "newPassword",
              inputRef: passRef,
              className: "form-input password-input",
              value: password,
              onChange: setPassword,
              autoComplete: "new-password",
              placeholder: `${MIN} or more characters`,
              invalid: status.kind === "error",
              describedBy: status.kind === "error" ? "reset-error" : void 0,
              autoFocus: !!token
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { htmlFor: "confirm-password", className: "form-label", children: "Confirm Password" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
            PasswordInput,
            {
              id: "confirm-password",
              name: "confirmPassword",
              inputRef: confirmRef,
              className: "form-input password-input",
              value: confirm,
              onChange: setConfirm,
              autoComplete: "new-password",
              placeholder: "Re-enter your password"
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "submit", className: "form-submit", disabled: locked, children: busy ? "Saving\u2026" : "Save Password" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { className: "link-btn loginlink", href: "/auth/", children: "Back to sign in" })
        ]
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "circle-bottom", "aria-hidden": "true" })
  ] });
}

// client/reset/main.tsx
var import_jsx_runtime2 = __toESM(require_jsx_runtime(), 1);
(0, import_client.createRoot)(document.getElementById("root")).render(
  /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_react2.StrictMode, { children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(ResetApp, {}) })
);
//# sourceMappingURL=reset-YKJXOQ3A.js.map
