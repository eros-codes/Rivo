import {
  require_client,
  require_jsx_runtime,
  require_react
} from "./chunks/chunk-GRWXGSY5.js";
import {
  __toESM
} from "./chunks/chunk-EXRSNSHP.js";

// client/landing/main.tsx
var import_react3 = __toESM(require_react(), 1);
var import_client = __toESM(require_client(), 1);

// client/landing/LandingPage.tsx
var import_react2 = __toESM(require_react(), 1);

// client/landing/effects.ts
var import_react = __toESM(require_react(), 1);
var reducedMotion = () => window.matchMedia("(prefers-reduced-motion: reduce)").matches;
var finePointer = () => window.matchMedia("(pointer: fine)").matches;
function frameLoop(step) {
  let id = 0;
  const tick = () => {
    id = step() ? requestAnimationFrame(tick) : 0;
  };
  return {
    kick: () => {
      if (!id) id = requestAnimationFrame(tick);
    },
    stop: () => {
      cancelAnimationFrame(id);
      id = 0;
    }
  };
}
function useCustomCursor(dot, ring) {
  (0, import_react.useEffect)(() => {
    if (!finePointer() || reducedMotion() || !dot.current || !ring.current) return void 0;
    const d = dot.current;
    const r = ring.current;
    const root2 = document.documentElement;
    let mx = 0;
    let my = 0;
    let cx = 0;
    let cy = 0;
    let rx = 0;
    let ry = 0;
    let shown = false;
    const loop = frameLoop(() => {
      cx += (mx - cx) * 0.22;
      cy += (my - cy) * 0.22;
      rx += (mx - rx) * 0.12;
      ry += (my - ry) * 0.12;
      d.style.transform = `translate3d(${cx}px, ${cy}px, 0) translate(-50%, -50%)`;
      r.style.transform = `translate3d(${rx}px, ${ry}px, 0) translate(-50%, -50%)`;
      return Math.abs(mx - rx) > 0.3 || Math.abs(my - ry) > 0.3;
    });
    const onMove = (e) => {
      mx = e.clientX;
      my = e.clientY;
      if (!shown) {
        shown = true;
        cx = rx = mx;
        cy = ry = my;
        root2.classList.add("custom-cursor");
        d.classList.add("visible");
        r.classList.add("visible");
      }
      loop.kick();
    };
    const onLeave = () => {
      d.classList.remove("visible");
      r.classList.remove("visible");
      shown = false;
    };
    document.addEventListener("mousemove", onMove, { passive: true });
    document.documentElement.addEventListener("mouseleave", onLeave);
    return () => {
      loop.stop();
      document.removeEventListener("mousemove", onMove);
      document.documentElement.removeEventListener("mouseleave", onLeave);
      root2.classList.remove("custom-cursor");
    };
  }, [dot, ring]);
}
function useTilt(scene, cluster) {
  (0, import_react.useEffect)(() => {
    if (!finePointer() || reducedMotion() || !scene.current || !cluster.current) return void 0;
    const el = cluster.current;
    const MAX = 15;
    let tx = 0;
    let ty = 0;
    let x = 0;
    let y = 0;
    const clamp = (v) => Math.max(-MAX, Math.min(MAX, v));
    const loop = frameLoop(() => {
      x += (tx - x) * 0.06;
      y += (ty - y) * 0.06;
      el.style.transform = `rotateX(${clamp(x)}deg) rotateY(${clamp(y)}deg)`;
      return Math.abs(tx - x) > 0.02 || Math.abs(ty - y) > 0.02;
    });
    const onMove = (e) => {
      const rect = scene.current?.getBoundingClientRect();
      if (!rect || rect.bottom < 0 || rect.top > window.innerHeight) return;
      const dx = (e.clientX - (rect.left + rect.width / 2)) / (rect.width / 2 || window.innerWidth / 2);
      const dy = (e.clientY - (rect.top + rect.height / 2)) / (rect.height / 2 || window.innerHeight / 2);
      ty = clamp(dx * MAX);
      tx = clamp(-dy * MAX);
      loop.kick();
    };
    document.addEventListener("mousemove", onMove, { passive: true });
    return () => {
      loop.stop();
      document.removeEventListener("mousemove", onMove);
    };
  }, [scene, cluster]);
}
function useScrolledPast(y) {
  const [past, setPast] = (0, import_react.useState)(false);
  (0, import_react.useEffect)(() => {
    const check = () => setPast(window.scrollY > y);
    check();
    window.addEventListener("scroll", check, { passive: true });
    return () => window.removeEventListener("scroll", check);
  }, [y]);
  return past;
}
function useParallax(hero) {
  (0, import_react.useEffect)(() => {
    const section = hero.current;
    if (!section || reducedMotion()) return void 0;
    const blobs = [
      [section.querySelector(".blob-1"), -80],
      [section.querySelector(".blob-2"), -50]
    ];
    let frame = 0;
    const update = () => {
      frame = 0;
      const progress = Math.min(1, Math.max(0, window.scrollY / Math.max(1, section.offsetHeight)));
      for (const [el, distance] of blobs) if (el) el.style.translate = `0 ${(progress * distance).toFixed(1)}px`;
    };
    const onScroll = () => {
      if (!frame) frame = requestAnimationFrame(update);
    };
    update();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("scroll", onScroll);
    };
  }, [hero]);
}
var REVEAL_SELECTOR = ".reveal, .reveal-left, .reveal-right, .reveal-scale";
function useScrollReveal(root2) {
  (0, import_react.useEffect)(() => {
    const container = root2.current;
    if (!container || reducedMotion() || !("IntersectionObserver" in window)) return void 0;
    const limit = window.innerHeight * 0.95;
    const waiting = [...container.querySelectorAll(REVEAL_SELECTOR)].filter((el) => el.getBoundingClientRect().top > limit);
    const timers = [];
    const io = new IntersectionObserver(
      (entries) => {
        let order = 0;
        for (const entry of entries) {
          if (!entry.isIntersecting) continue;
          const el = entry.target;
          io.unobserve(el);
          el.style.transitionDelay = `${order++ * 60}ms`;
          el.classList.add("revealing");
          requestAnimationFrame(() => el.classList.remove("will-reveal"));
          timers.push(
            window.setTimeout(() => {
              el.classList.remove("revealing");
              el.style.transitionDelay = "";
            }, 1200 + order * 60)
          );
        }
      },
      { rootMargin: "0px 0px -15% 0px" }
    );
    for (const el of waiting) {
      el.classList.add("will-reveal");
      io.observe(el);
    }
    return () => {
      io.disconnect();
      timers.forEach((t) => window.clearTimeout(t));
      for (const el of waiting) el.classList.remove("will-reveal", "revealing");
    };
  }, [root2]);
}

// client/landing/LandingPage.tsx
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
var APP = "/chat/";
var DEMO = [
  {
    name: "Rivo",
    initial: "R",
    status: "Interactive Demo",
    color: "linear-gradient(135deg,#fa5f1a,#ff8c42)",
    msgs: [
      { out: false, text: "Hey \u{1F44B} Welcome to Rivo." },
      { out: false, text: "This is a live demo \u2014 everything works here." },
      { out: true, text: "Wait, I can actually interact with this?" },
      { out: false, text: "Tap \u2039 to explore chats and contacts \u2728" }
    ]
  },
  {
    name: "Alex",
    initial: "A",
    status: "Online now",
    color: "linear-gradient(135deg,#fa5f1a,#ff8c42)",
    msgs: [
      { out: false, text: "Just shipped the new feature \u{1F680}" },
      { out: true, text: "Already? That was fast." },
      { out: false, text: "Real-time everything \u2014 no delays." },
      { out: true, text: "Clean. Ship it." }
    ]
  },
  {
    name: "Maya",
    initial: "M",
    status: "Last seen recently",
    color: "linear-gradient(135deg,#9b59b6,#8e44ad)",
    msgs: [
      { out: true, text: "Did you pin those messages?" },
      { out: false, text: "Yeah, one tap and they're saved." },
      { out: true, text: "Rivo makes this so clean honestly." },
      { out: false, text: "Right? No bloat, just what you need." }
    ]
  },
  {
    name: "Jake",
    initial: "J",
    status: "Online now",
    color: "linear-gradient(135deg,#3498db,#2980b9)",
    msgs: [
      { out: false, text: "Archived the old threads, so clean now." },
      { out: true, text: "Archive is a game changer ngl." },
      { out: false, text: "And the search finds messages too \u{1F50D}" },
      { out: true, text: "This thing just keeps getting better." }
    ]
  },
  {
    name: "Sofia",
    initial: "S",
    status: "Offline",
    color: "linear-gradient(135deg,#2ecc71,#27ae60)",
    msgs: [
      { out: true, text: "Have you tried the PWA install?" },
      { out: false, text: "Yeah \u2014 feels like a native app." },
      { out: true, text: "No app store, just open and install." },
      { out: false, text: "That's the future fr \u{1F64C}" }
    ]
  }
];
function PhoneMock() {
  const [open, setOpen] = (0, import_react2.useState)(0);
  const [leaving, setLeaving] = (0, import_react2.useState)(false);
  const msgs = (0, import_react2.useRef)(null);
  const chat = DEMO[open ?? 0];
  (0, import_react2.useEffect)(() => {
    if (msgs.current) msgs.current.scrollTop = msgs.current.scrollHeight;
  }, [open]);
  (0, import_react2.useEffect)(() => {
    if (!leaving) return void 0;
    const t = window.setTimeout(() => setLeaving(false), 320);
    return () => window.clearTimeout(t);
  }, [leaving]);
  const openChat = (i) => {
    setLeaving(true);
    setOpen(i);
  };
  const mainClass = `pm-screen${open === null ? " active" : leaving ? " slide-out" : ""}`;
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "phone-mock", "aria-label": "A demo of the Rivo app", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: mainClass, "aria-hidden": open !== null, inert: open !== null, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "pm-main-header", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "pm-main-logo", children: [
          "Rivo",
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "." })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "pm-main-icons", "aria-hidden": "true", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", { cx: "11", cy: "11", r: "8" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", { x1: "21", y1: "21", x2: "16.65", y2: "16.65" })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", { cx: "9", cy: "7", r: "4" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", { x1: "19", y1: "8", x2: "19", y2: "14" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", { x1: "22", y1: "11", x2: "16", y2: "11" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "pm-section-label", children: "ACTIVE CHATS" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pm-active-list", children: [
        { i: 1, msg: "Clean. Ship it.", time: "09:27", badge: 3 },
        { i: 2, msg: "Right? No bloat, just what you need.", time: "10:15", badge: 2 }
      ].map(({ i, msg, time, badge }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", { type: "button", className: "pm-active-card", onClick: () => openChat(i), children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pm-ac-avatar", style: { background: DEMO[i].color }, children: DEMO[i].initial }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { className: "pm-ac-info", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pm-ac-name", children: DEMO[i].name }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pm-ac-msg", children: msg })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { className: "pm-ac-meta", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pm-ac-time", children: time }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pm-ac-badge", children: badge })
        ] })
      ] }, i)) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "pm-section-label", children: "CONTACTS" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pm-contacts-grid", children: [3, 4, 0].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", { type: "button", className: "pm-contact-card", onClick: () => openChat(i), children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pm-cc-avatar", style: { background: DEMO[i].color }, children: DEMO[i].initial }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pm-cc-name", children: DEMO[i].name }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "pm-cc-status", children: DEMO[i].status })
      ] }, i)) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: `pm-screen${open !== null ? " active" : ""}`, id: "pmScreenChat", "aria-hidden": open === null, inert: open === null, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "phone-header", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "pm-back-btn", "aria-label": "Back to chats", onClick: () => setOpen(null), children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", strokeLinecap: "round", strokeLinejoin: "round", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M15 18l-6-6 6-6" }) }) }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "phone-avatar", style: { background: chat.color }, children: chat.initial }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "phone-name", children: chat.name }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "phone-status", children: chat.status })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "phone-msgs", ref: msgs, children: chat.msgs.map((m, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `pm pm-${m.out ? "out" : "in"}`, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "pm-text", children: m.text }) }, `${open}-${i}`)) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "phone-input", "aria-hidden": "true", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Message\u2026" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "phone-send", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", { width: "10", height: "10", viewBox: "0 0 24 24", fill: "white", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M2.01 21L23 12 2.01 3 2 10l15 2-15 2z" }) }) })
      ] })
    ] })
  ] });
}
function Arrow() {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": "true", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M5 12h14M12 5l7 7-7 7" }) });
}
function Cursor() {
  const dot = (0, import_react2.useRef)(null);
  const ring = (0, import_react2.useRef)(null);
  useCustomCursor(dot, ring);
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cursor", ref: dot, "aria-hidden": "true" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "cursor-ring", ref: ring, "aria-hidden": "true" })
  ] });
}
var SECTIONS = [
  ["#home", "Home"],
  ["#about", "About"],
  ["#features", "Features"],
  ["#download", "Download"]
];
function Nav() {
  const scrolled = useScrolledPast(60);
  const [menu, setMenu] = (0, import_react2.useState)(false);
  (0, import_react2.useEffect)(() => {
    if (!menu) return void 0;
    document.body.style.overflow = "hidden";
    const onKey = (e) => {
      if (e.key === "Escape") setMenu(false);
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      document.removeEventListener("keydown", onKey);
    };
  }, [menu]);
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", { className: `nav${scrolled ? " scrolled" : ""}`, "aria-label": "Main", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "nav-logo", children: [
        "Rivo",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "." })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { className: "nav-links", children: SECTIONS.map(([href, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href, children: label }) }, href)) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: APP, className: "nav-cta", children: "Get the App" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", { type: "button", className: "nav-burger", "aria-label": "Menu", "aria-expanded": menu, "aria-controls": "mobileNav", onClick: () => setMenu((v) => !v), children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {}),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {})
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
      "div",
      {
        className: `nav-mobile${menu ? " open" : ""}`,
        id: "mobileNav",
        onClick: (e) => {
          if (e.target === e.currentTarget) setMenu(false);
        },
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "nav-mobile-close", "aria-label": "Close menu", onClick: () => setMenu(false), children: "\u2715" }),
          SECTIONS.map(([href, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href, className: "mobile-link", onClick: () => setMenu(false), children: label }, href)),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: APP, className: "btn-primary", style: { marginTop: "1rem" }, children: "Get the App" })
        ]
      }
    )
  ] });
}
function Hero() {
  const hero = (0, import_react2.useRef)(null);
  const scene = (0, import_react2.useRef)(null);
  const cluster = (0, import_react2.useRef)(null);
  useParallax(hero);
  useTilt(scene, cluster);
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { className: "hero", id: "home", ref: hero, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "hero-bg", "aria-hidden": "true", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "blob blob-1" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "blob blob-2" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "blob blob-3" })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hero-bg-text", "aria-hidden": "true", children: "RIVO" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "hero-content", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", { className: "hero-title", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "line", children: "Conversations," }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "line line-orange", children: "Uninterrupted." })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "hero-sub", children: "A messaging app designed with intention \u2014 fast, warm, and genuinely different. Real-time, secure, and built to feel like nothing else." }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "hero-actions", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", { href: APP, className: "btn-primary", children: [
          "Get the App",
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Arrow, {})
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", { href: "#about", className: "btn-ghost", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { width: "14", height: "14", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": "true", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", { cx: "12", cy: "12", r: "10" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 8v4m0 4h.01" })
          ] }),
          "Learn More"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "hero-visual", "aria-hidden": "true", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "chat-scene", ref: scene, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "chat-float", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "chat-cluster", ref: cluster, children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "bubble bubble-orange b1", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "bubble-text", children: "Coffee on me later \u2615" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "bubble-meta", children: [
            "09:27",
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", { width: "12", height: "12", viewBox: "0 0 24 24", fill: "currentColor", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z" }) })
          ] })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "bubble bubble-white b2", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "bubble-line", style: { width: "100%" } }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "bubble-line", style: { width: "75%" } }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "bubble-meta", style: { marginTop: ".4rem" }, children: "09:22" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "bubble bubble-orange b3", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "bubble-text", children: "Way better than the last version." }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "bubble-meta", children: "09:21" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scene-orb orb-1" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scene-orb orb-2" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scene-orb orb-3" })
      ] }) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "scene-glow" })
    ] }) })
  ] });
}
function About() {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { className: "about", id: "about", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "about-text reveal-left", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "section-label", children: "About Rivo" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", { className: "section-title", children: [
        "Built different.",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
        "Feels different."
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { className: "section-sub", children: [
        "Most chat apps treat design as an afterthought. Rivo doesn't. Every pixel, every interaction, every animation was obsessed over \u2014 from the warm cream background to the glassmorphism active-chat cards. It's not just how it looks. It's how it",
        " ",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("em", { style: { color: "var(--orange)", fontStyle: "normal" }, children: "feels" }),
        "."
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "about-stats", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "stat-card", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "stat-value", children: "0" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "stat-label", children: "Ads, Ever" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "stat-card", children: [
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "stat-value", children: "\u221E" }),
          /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "stat-label", children: "Message History" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "about-visual reveal-right", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "about-glow", "aria-hidden": "true" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "about-ring ring-1", "aria-hidden": "true" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "about-ring ring-2", "aria-hidden": "true" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PhoneMock, {})
    ] })
  ] });
}
function Feature({ className = "", icon, title, children }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: `bcard reveal-scale${className ? ` ${className}` : ""}`, children: [
    className.includes("featured") && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "bcard-accent" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "bcard-icon", "aria-hidden": "true", children: icon }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { className: "bcard-title", children: title }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "bcard-desc", children })
  ] });
}
function Features() {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { className: "features", id: "features", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "features-header reveal", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "section-label", children: "Features" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", { className: "section-title", children: [
        "Everything you need.",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
        "Nothing you don't."
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "section-sub", children: "Thoughtfully designed features that just work \u2014 no noise, no bloat." })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "bento", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        Feature,
        {
          className: "featured",
          title: "The Interface Other Apps Forgot to Build",
          icon: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", { x: "4", y: "3", width: "16", height: "6", rx: "2", stroke: "currentColor", strokeWidth: "1.5" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M6.5 6h5", stroke: "currentColor", strokeWidth: "1", strokeLinecap: "round", opacity: "0.5" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", { cx: "17.5", cy: "6", r: "1", fill: "currentColor", opacity: "0.6" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", { x: "2", y: "10.5", width: "20", height: "5", rx: "2.5", stroke: "currentColor", strokeWidth: "1.5", fill: "currentColor", fillOpacity: "0.09" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M5 13h10", stroke: "currentColor", strokeWidth: "0.9", strokeLinecap: "round", opacity: "0.38" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", { x: "4", y: "17", width: "16", height: "5", rx: "2", stroke: "currentColor", strokeWidth: "1.4", fill: "currentColor", fillOpacity: "0.04" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M6.5 19.5h7", stroke: "currentColor", strokeWidth: "0.9", strokeLinecap: "round", opacity: "0.25" })
          ] }),
          children: "Every surface was argued over. Frosted glass, layered shadows, gradients that guide before you notice them \u2014 nothing here is default. Every other app drowns you in one endless list of contacts. Rivo knows the difference between a conversation that's alive and one that went quiet \u2014 so it separates them. Active chats surface. Dormant contacts stay tucked away. Every transition has a reason. Every detail was deliberate. This isn't just a UI. It's an opinion."
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        Feature,
        {
          title: "The Full Package.",
          icon: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 2L2 7v10l10 5 10-5V7L12 2z", stroke: "currentColor", strokeWidth: "1.5", strokeLinejoin: "round" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M2 7l10 5 10-5", stroke: "currentColor", strokeWidth: "1.5", strokeLinejoin: "round" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 12v10", stroke: "currentColor", strokeWidth: "1.2", strokeLinecap: "round", opacity: "0.28" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M9 8.5l2 2.2 4.5-5", stroke: "currentColor", strokeWidth: "1.4", strokeLinecap: "round", strokeLinejoin: "round", opacity: "0.75" })
          ] }),
          children: "Search. React. Pin. Archive. Forward. Mute. Everything a serious messenger should do \u2014 running quietly in the background, so you never have to think twice about it."
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        Feature,
        {
          title: "Security First",
          icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" }) }),
          children: "Signed sessions you can see and end from any device, CSRF protection, rate limiting, and bcrypt-hashed passwords. Every layer hardened."
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        Feature,
        {
          className: "wide",
          title: "Encrypted where it's stored",
          icon: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", { x: "3", y: "11", width: "18", height: "10", rx: "2" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M7 11V7a5 5 0 0 1 10 0v4" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", { cx: "12", cy: "16", r: "1.5" })
          ] }),
          children: "Every message is encrypted with its own unique key before it is saved. The keys that protect those keys are kept apart from the database \u2014 so a copy of the database alone reveals nothing."
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        Feature,
        {
          className: "wide",
          title: "Beyond Send",
          icon: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
              "path",
              {
                d: "M4 4.5A1.5 1.5 0 015.5 3h13A1.5 1.5 0 0120 4.5v10A1.5 1.5 0 0118.5 16H9.5L6 20V16H5.5A1.5 1.5 0 014 14.5V4.5z",
                stroke: "currentColor",
                strokeWidth: "1.5",
                strokeLinejoin: "round"
              }
            ),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", { cx: "12", cy: "9", r: "3.5", stroke: "currentColor", strokeWidth: "1.3" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 7.5V9", stroke: "currentColor", strokeWidth: "1.4", strokeLinecap: "round" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M12 9l1.9 1.1", stroke: "currentColor", strokeWidth: "1.4", strokeLinecap: "round" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", { cx: "12", cy: "9", r: "0.5", fill: "currentColor" })
          ] }),
          children: "One-time messages that vanish the moment they're read. Time Capsules sealed until a date you choose, then opened right on time. Rivo gives your words a timeline \u2014 and a life \u2014 of their own."
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        Feature,
        {
          title: "Find Anything",
          icon: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", { cx: "11", cy: "11", r: "7" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "m21 21-4.35-4.35" })
          ] }),
          children: "One search box for people and conversations. Type a few letters and jump straight to the message you meant \u2014 highlighted, right where it was said."
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
        Feature,
        {
          title: "PWA Ready",
          icon: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", children: [
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", { x: "5", y: "2", width: "14", height: "20", rx: "2", ry: "2" }),
            /* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", { x1: "12", y1: "18", x2: "12.01", y2: "18" })
          ] }),
          children: "Install once, use everywhere. No app store required \u2014 just open and add to home screen."
        }
      )
    ] })
  ] });
}
function Download() {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { className: "download", id: "download", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "download-header reveal", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "section-label", children: "Get Rivo" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", { className: "section-title", children: [
        "Three steps.",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
        "That's all."
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "section-sub", children: "No app store. No download. Just open it in your browser and make it yours in seconds." })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", { className: "pwa-steps", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { className: "step reveal-scale", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "step-num", children: "1" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { className: "step-title", children: "Open in Browser" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "step-desc", children: "Visit the Rivo web app in Chrome, Safari, or any modern browser on any device." })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { className: "step reveal-scale", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "step-num", children: "2" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { className: "step-title", children: "Tap Install" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "step-desc", children: "Hit the install prompt in your browser bar or use the share menu on iOS to add to home screen." })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { className: "step reveal-scale", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "step-num", children: "3" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", { className: "step-title", children: "Start Chatting" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "step-desc", children: "Launch it from your home screen just like a native app \u2014 with notifications for new messages." })
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "download-cta-wrap reveal", children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", { href: APP, className: "btn-primary", style: { fontSize: "1rem", padding: "1rem 2.5rem" }, children: [
      "Open Rivo Web App",
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", { width: "16", height: "16", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.5", strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": "true", children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6M15 3h6v6M10 14L21 3" }) })
    ] }) })
  ] });
}
function LandingPage() {
  const root2 = (0, import_react2.useRef)(null);
  useScrollReveal(root2);
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { ref: root2, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cursor, {}),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Nav, {}),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hero, {}),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(About, {}),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Features, {}),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {})
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", { children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "foot-logo", children: [
        "Rivo",
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "." })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "foot-copy", children: "\xA9 2026 Rivo. Conversations, Uninterrupted." }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", { className: "foot-links", "aria-label": "Footer", children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#home", children: "Home" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "#about", children: "About" }),
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", { href: "/landing/privacy.html", children: "Privacy Policy" })
      ] })
    ] })
  ] });
}

// client/landing/PrivacyPage.tsx
var import_jsx_runtime2 = __toESM(require_jsx_runtime(), 1);
function PrivacyPage() {
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)(import_jsx_runtime2.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Cursor, {}),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("nav", { className: "privacy-nav", "aria-label": "Main", children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "nav-logo", children: [
        "Rivo",
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: "." })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("a", { href: "/", className: "nav-cta", children: "\u2190 Home" })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("header", { className: "privacy-hero", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("div", { className: "privacy-content", style: { paddingTop: 0 }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "privacy-hero-label", children: "Legal" }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("h1", { children: "Privacy Policy" }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { className: "updated", children: "Last updated: October 4, 2026" })
    ] }) }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("main", { className: "privacy-content", children: [
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { className: "privacy-intro", children: "Rivo is built on the belief that your conversations are yours. This page explains what we store, why, and how we protect it \u2014 in plain language, not legalese." }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("section", { className: "privacy-section", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("h2", { children: "What we collect" }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("ul", { children: [
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("li", { children: "Account information you provide \u2014 name, email address, username and, if you add them, a bio and a profile picture." }),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("li", { children: "Your messages and the details needed to deliver them (who sent what, to which chat, and when), stored encrypted." }),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("li", { children: "The devices you are signed in on: when each one signed in and was last active, and its browser's description (such as \u201CChrome on Android\u201D), so you can see them and sign them out in Settings." }),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("li", { children: "Notification addresses for the devices where you turn on notifications, used only to deliver message notifications." }),
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("li", { children: "Error reports from our servers to fix problems. They never include the content of your messages." })
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("section", { className: "privacy-section", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("h2", { children: "What stays on your device" }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { children: "Your theme, accent color and chat background are kept only in your browser, as are messages waiting to be sent while you are offline. Signing out removes the account's data from the device." })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("section", { className: "privacy-section", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("h2", { children: "How we use data" }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { children: "We use your data to run the service: to sign you in, deliver your messages and notifications, and keep your account secure. We do not sell your data, use it for advertising, or share it with third parties except where required by law." })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("section", { className: "privacy-section", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("h2", { children: "Security" }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { children: "Every message is encrypted with its own unique key before it is stored (envelope encryption: per-message keys, themselves encrypted with master keys that are kept apart from the database). The server decrypts a message only to deliver it to the people in the conversation \u2014 Rivo is not end-to-end encrypted. Accounts are protected by bcrypt-hashed passwords, signed sessions in HttpOnly cookies that you can end from any device, CSRF protection and rate limiting." })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("section", { className: "privacy-section", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("h2", { children: "This website" }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("p", { children: "The Rivo app itself loads nothing from other companies. These public pages (the home page and this one) load the Syne typeface from Google Fonts, so your browser contacts Google's servers when you open them." })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("section", { className: "privacy-section", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("h2", { children: "Your choices" }),
        /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("p", { children: [
          "You control who sees your online status, email address and profile picture in Settings: everyone, your contacts (people you added, wrote to or named yourself \u2014 not just anyone who added you) or nobody. Your email address is shown to your contacts only unless you choose otherwise. You can delete your account there at any time. Deleting it removes your profile, contacts, notification addresses and your Saved Messages; the people you talked with keep their copy of your conversations, shown as \u201CDeleted account\u201D. For questions or a copy of your data, contact us at ",
          /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("a", { href: "mailto:privacy@rivo.ir", children: "privacy@rivo.ir" }),
          "."
        ] })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { className: "privacy-disclaimer", children: "This is a plain-language summary intended for the Rivo demo site. For complete legal terms, this page should be replaced with a full privacy policy reviewed by qualified legal counsel before any production launch." }),
      /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("a", { href: "/", className: "privacy-back", children: [
        /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round", "aria-hidden": "true", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("path", { d: "M19 12H5M12 5l-7 7 7 7" }) }),
        "Back to Rivo"
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("footer", { className: "privacy-footer", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsxs)("p", { children: [
      "\xA9 2026 ",
      /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("span", { children: "Rivo" }),
      " \u2014 Conversations, Uninterrupted."
    ] }) })
  ] });
}

// client/landing/main.tsx
var import_jsx_runtime3 = __toESM(require_jsx_runtime(), 1);
var root = document.getElementById("root");
(0, import_client.hydrateRoot)(root, /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(import_react3.StrictMode, { children: root.dataset.page === "privacy" ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(PrivacyPage, {}) : /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(LandingPage, {}) }));
//# sourceMappingURL=landing-PZMKQMXU.js.map
