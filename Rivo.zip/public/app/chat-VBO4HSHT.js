import {
  ApiError,
  Icons,
  PasswordInput,
  authApi,
  contactsApi,
  conversationsApi,
  errorText,
  keys,
  messagesApi,
  pushApi,
  read,
  readJson,
  sessionsApi,
  setHeaderProvider,
  setUnauthorizedHandler,
  usersApi,
  write,
  writeJson
} from "./chunks/chunk-OXYREE6K.js";
import {
  require_client,
  require_jsx_runtime,
  require_react,
  require_react_dom
} from "./chunks/chunk-GRWXGSY5.js";
import {
  __export,
  __toESM
} from "./chunks/chunk-EXRSNSHP.js";

// client/chat/main.tsx
var import_react34 = __toESM(require_react(), 1);
var import_client = __toESM(require_client(), 1);

// client/shared/lib/theme.ts
var ACCENT_PRESETS = [
  { name: "Orange", hex: "#fa5f1a" },
  { name: "Blue", hex: "#2d6be4" },
  { name: "Crimson", hex: "#c0392b" },
  { name: "Forest", hex: "#1a7a4a" },
  { name: "Purple", hex: "#7c3aed" },
  { name: "Navy", hex: "#1b3a6b" },
  { name: "Pink", hex: "#e91e8c" }
];
var DEFAULT_ACCENT = "#fa5f1a";
var BACKGROUND = { light: "#f7f0f0", dark: "#1a1a1a" };
var HEX_RE = /^#(?:[0-9a-f]{3}|[0-9a-f]{6})$/i;
function normalizeHex(value2) {
  if (typeof value2 !== "string") return null;
  const v = value2.trim();
  if (!HEX_RE.test(v)) return null;
  const h = v.slice(1).toLowerCase();
  return h.length === 3 ? `#${h[0]}${h[0]}${h[1]}${h[1]}${h[2]}${h[2]}` : `#${h}`;
}
function rgb(hex) {
  const n = parseInt(hex.slice(1), 16);
  return [n >> 16 & 255, n >> 8 & 255, n & 255];
}
function darken(hex, percent) {
  const d = Math.round(2.55 * percent);
  return `#${rgb(hex).map((v) => Math.max(0, v - d).toString(16).padStart(2, "0")).join("")}`;
}
function alpha(hex, a) {
  const [r, g, b] = rgb(hex);
  return `rgba(${r},${g},${b},${a})`;
}
function storedTheme() {
  return read(keys.theme) === "dark" ? "dark" : "light";
}
function storedAccent() {
  return normalizeHex(read(keys.accent));
}
function currentTheme() {
  return document.documentElement.classList.contains("dark-mode") ? "dark" : "light";
}
var ACCENT_VARS = [
  "--accent",
  "--messages-outgoing",
  "--active-chat-bg-color",
  "--active-chat-bg-color-hover",
  "--bold-active-chat-bg-color",
  "--bold-active-chat-bg-color-hover",
  "--accent-gradient-top",
  "--accent-gradient-bottom",
  "--accent-glass"
];
function applyAccent(hex) {
  const style = document.documentElement.style;
  const color = normalizeHex(hex);
  if (!color) {
    for (const v of ACCENT_VARS) style.removeProperty(v);
    return;
  }
  const base = currentTheme() === "dark" ? darken(color, 8) : color;
  style.setProperty("--accent", base);
  style.setProperty("--messages-outgoing", base);
  style.setProperty("--active-chat-bg-color", base);
  style.setProperty("--active-chat-bg-color-hover", darken(base, 5));
  style.setProperty("--bold-active-chat-bg-color", darken(base, 10));
  style.setProperty("--bold-active-chat-bg-color-hover", darken(base, 15));
  style.setProperty("--accent-gradient-top", `radial-gradient(circle at top, ${darken(base, 8)}, ${base})`);
  style.setProperty("--accent-gradient-bottom", `radial-gradient(circle at right, ${darken(base, 8)}, ${base})`);
  style.setProperty("--accent-glass", `linear-gradient(to right, ${alpha(base, 0.21)}, ${alpha(base, 0.21)})`);
}
function applyTheme(theme) {
  const root = document.documentElement;
  root.classList.toggle("dark-mode", theme === "dark");
  root.style.colorScheme = theme;
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", BACKGROUND[theme]);
  applyAccent(storedAccent());
}
function saveTheme(theme) {
  write(keys.theme, theme);
  applyTheme(theme);
}
function saveAccent(hex) {
  const color = normalizeHex(hex);
  if (!color) return;
  write(keys.accent, color === DEFAULT_ACCENT ? null : color);
  applyAccent(color === DEFAULT_ACCENT ? null : color);
}
var WALLPAPER_RE = /^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/;
function storedWallpaper() {
  const v = read(keys.wallpaper);
  return v && WALLPAPER_RE.test(v) ? v : null;
}
function applyWallpaper(dataUrl) {
  const style = document.documentElement.style;
  if (dataUrl && WALLPAPER_RE.test(dataUrl)) style.setProperty("--chat-wallpaper", `url("${dataUrl}")`);
  else style.removeProperty("--chat-wallpaper");
}
function saveWallpaper(dataUrl) {
  if (dataUrl !== null && !WALLPAPER_RE.test(dataUrl)) return false;
  const ok = write(keys.wallpaper, dataUrl);
  if (ok) applyWallpaper(dataUrl);
  return ok;
}
function applyStoredAppearance() {
  applyTheme(storedTheme());
  applyWallpaper(storedWallpaper());
}

// client/shared/lib/store.ts
var import_react = __toESM(require_react(), 1);
function createStore(initial) {
  let state = initial;
  const listeners = /* @__PURE__ */ new Set();
  return {
    get: () => state,
    set(update) {
      const next = typeof update === "function" ? update(state) : update;
      if (Object.is(next, state)) return;
      state = next;
      for (const l of [...listeners]) l();
    },
    subscribe(listener) {
      listeners.add(listener);
      return () => listeners.delete(listener);
    }
  };
}
function useStore(store, selector, isEqual = Object.is) {
  const committed = (0, import_react.useRef)(null);
  const getSnapshot = (0, import_react.useMemo)(() => {
    let lastState;
    let lastValue;
    let has = false;
    return () => {
      const state = store.get();
      if (has && Object.is(state, lastState)) return lastValue;
      const value3 = selector(state);
      const prev = committed.current;
      lastState = state;
      has = true;
      lastValue = prev && isEqual(prev.value, value3) ? prev.value : value3;
      return lastValue;
    };
  }, [store, selector, isEqual]);
  const value2 = (0, import_react.useSyncExternalStore)(store.subscribe, getSnapshot, getSnapshot);
  (0, import_react.useEffect)(() => {
    committed.current = { value: value2 };
  }, [value2]);
  return value2;
}

// client/chat/state/stores.ts
var session = createStore({ me: null });
var contacts = createStore({ byConv: {}, loaded: false, failed: false });
var chats = createStore({});
var outbox = createStore({});
var typing = createStore({});
var connection = createStore({
  status: "connecting",
  everConnected: false
});
var ui = createStore({
  openConvId: null,
  focus: null,
  panel: null,
  dialog: null,
  allContactsOpen: false,
  search: { open: false, query: "" },
  selection: null,
  forwarding: null,
  menu: null
});
var EMPTY_COMPOSER = { draft: "", action: null, mode: "normal", scheduledFor: null };
var composers = createStore({});
var undoing = createStore({ messages: {}, clearedChats: {}, removedContacts: {} });
var toasts = createStore({ current: null });
var notices = createStore({ list: [] });
var vanishing = createStore({});

// client/chat/state/chatModel.ts
var MAX_CACHED = 12;
var MAX_GONE = 500;
function compareMessages(a, b) {
  if (a.createdAt !== b.createdAt) return a.createdAt < b.createdAt ? -1 : 1;
  return a.id - b.id;
}
function emptyCache() {
  return {
    messages: [],
    hasMore: false,
    cursor: null,
    status: "loading",
    loadingOlder: false,
    staleSince: null,
    pinned: null,
    gone: {},
    usedAt: Date.now()
  };
}
function getCache(convId) {
  if (convId === null || convId === void 0) return null;
  return chats.get()[convId] ?? null;
}
function updateCache(convId, fn) {
  chats.set((s) => {
    const cur = s[convId];
    const next = fn(cur ?? emptyCache());
    if (cur && next === cur) return s;
    return { ...s, [convId]: next };
  });
}
function updateExisting(convId, fn) {
  chats.set((s) => {
    const cur = s[convId];
    if (!cur) return s;
    const next = fn(cur);
    return next === cur ? s : { ...s, [convId]: next };
  });
}
function newerCopy(existing, incoming) {
  const base = incoming.updatedAt >= existing.updatedAt ? incoming : existing;
  const isSeen = existing.isSeen || incoming.isSeen;
  const unlocked = !existing.isLocked && existing.isTimeCapsule && existing.text !== null ? existing : null;
  let out = base.isSeen === isSeen ? base : { ...base, isSeen };
  if (unlocked && out.isLocked) out = { ...out, isLocked: false, text: unlocked.text, openedAt: unlocked.openedAt ?? out.openedAt };
  if (!out.clientId && (existing.clientId || incoming.clientId)) out = { ...out, clientId: existing.clientId ?? incoming.clientId };
  return out;
}
function insertionIndex(list, m) {
  let lo = 0;
  let hi = list.length;
  while (lo < hi) {
    const mid = lo + hi >> 1;
    if (compareMessages(list[mid], m) < 0) lo = mid + 1;
    else hi = mid;
  }
  return lo;
}
function mergeMessages(c, incoming) {
  if (incoming.length === 0) return c;
  let list = c.messages;
  let copied = false;
  const copy = () => {
    if (!copied) {
      list = [...list];
      copied = true;
    }
  };
  for (const m of incoming) {
    if (c.gone[m.id]) continue;
    const at = list.findIndex((x) => x.id === m.id);
    if (at >= 0) {
      const merged = newerCopy(list[at], m);
      if (merged !== list[at]) {
        copy();
        list[at] = merged;
      }
      continue;
    }
    const first = list[0];
    if (c.hasMore && first && compareMessages(m, first) < 0) continue;
    copy();
    list.splice(insertionIndex(list, m), 0, m);
  }
  return list === c.messages ? c : { ...c, messages: list };
}
function rememberGone(gone, ids) {
  const next = { ...gone };
  for (const id of ids) next[id] = true;
  const keys2 = Object.keys(next);
  if (keys2.length > MAX_GONE) for (const k of keys2.slice(0, keys2.length - MAX_GONE)) delete next[Number(k)];
  return next;
}
function removeFromCache(c, ids) {
  if (ids.length === 0) return c;
  const drop = new Set(ids);
  const messages = c.messages.some((m) => drop.has(m.id)) ? c.messages.filter((m) => !drop.has(m.id)) : c.messages;
  const pinned = c.pinned && c.pinned.some((p) => drop.has(p.id)) ? c.pinned.filter((p) => !drop.has(p.id)) : c.pinned;
  return { ...c, messages, pinned, gone: rememberGone(c.gone, ids) };
}
function clearUpTo(c, upToId) {
  const next = removeFromCache(
    c,
    c.messages.filter((m) => m.id <= upToId).map((m) => m.id)
  );
  const pinned = next.pinned && next.pinned.some((p) => p.id <= upToId) ? next.pinned.filter((p) => p.id > upToId) : next.pinned;
  return { ...next, pinned, hasMore: false };
}
function syncPinned(pinned, changed) {
  if (!pinned || changed.length === 0) return pinned;
  let next = pinned;
  for (const m of changed) {
    const has = next.some((p) => p.id === m.id);
    if (m.isPinned && !has) next = insertPinned(next, m);
    else if (!m.isPinned && has) next = next.filter((p) => p.id !== m.id);
    else if (m.isPinned && has) next = next.map((p) => p.id === m.id && p.text !== m.text ? { ...p, text: m.text } : p);
  }
  return next;
}
function applyWire(c, wire) {
  const removed = [];
  const live = [];
  for (const m of wire) {
    if (m.isDeleted) removed.push(m.id);
    else live.push(m);
  }
  let next = removeFromCache(c, removed);
  next = mergeMessages(next, live);
  const pinned = syncPinned(next.pinned, live.filter((m) => !next.gone[m.id]));
  return pinned === next.pinned ? next : { ...next, pinned };
}
function withNewestPage(c, page) {
  const live = page.messages.filter((m) => !m.isDeleted && !c.gone[m.id]);
  const newest = live[live.length - 1];
  const byId = new Map(c.messages.map((m) => [m.id, m]));
  const messages = live.map((m) => {
    const had = byId.get(m.id);
    return had ? newerCopy(had, m) : m;
  });
  const inPage = new Set(messages.map((m) => m.id));
  const later = c.messages.filter((m) => !inPage.has(m.id) && (!newest || compareMessages(m, newest) > 0));
  return {
    ...c,
    messages: later.length ? [...messages, ...later].sort(compareMessages) : messages,
    hasMore: page.hasMore,
    cursor: page.cursor,
    status: "ready",
    staleSince: null
  };
}
function withOlderPage(c, page) {
  const first = c.messages[0];
  const older = page.messages.filter(
    (m) => !m.isDeleted && !c.gone[m.id] && (!first || compareMessages(m, first) < 0)
  );
  return { ...c, messages: [...older, ...c.messages], hasMore: page.hasMore, loadingOlder: false };
}
function patchMessage(c, id, patch) {
  const at = c.messages.findIndex((m) => m.id === id);
  if (at < 0) return c;
  const messages = [...c.messages];
  messages[at] = { ...messages[at], ...patch };
  return { ...c, messages };
}
function insertPinned(list, m) {
  const item = { id: m.id, text: m.text, senderId: m.senderId, createdAt: m.createdAt };
  return [...list.filter((p) => p.id !== m.id), item].sort(compareMessages);
}
function markAllStale(since) {
  chats.set((s) => {
    let changed = false;
    const next = {};
    for (const [k, c] of Object.entries(s)) {
      if (c.staleSince || c.status !== "ready") next[Number(k)] = c;
      else {
        next[Number(k)] = { ...c, staleSince: since };
        changed = true;
      }
    }
    return changed ? next : s;
  });
}
function evictCaches(keepConvId) {
  const all = Object.entries(chats.get());
  if (all.length <= MAX_CACHED + 1) return;
  const victims = all.filter(([k]) => Number(k) !== keepConvId).sort(([, a], [, b]) => a.usedAt - b.usedAt).slice(0, all.length - MAX_CACHED - 1).map(([k]) => Number(k));
  chats.set((s) => {
    const next = { ...s };
    for (const k of victims) delete next[k];
    return next;
  });
}
function dropCache(convId) {
  chats.set((s) => {
    if (!s[convId]) return s;
    const next = { ...s };
    delete next[convId];
    return next;
  });
}

// client/chat/state/contactModel.ts
var SAVED_NAME = "Saved Messages";
var DELETED_NAME = "Deleted account";
function isDeletedAccount(row) {
  return !row.isSaved && !!row.contact?.isDeleted;
}
function displayName(row) {
  if (!row) return "";
  if (row.isSaved) return SAVED_NAME;
  if (isDeletedAccount(row)) return DELETED_NAME;
  return row.nickname || row.contact?.name || "";
}
function realName(row) {
  if (!row) return "";
  if (isDeletedAccount(row)) return DELETED_NAME;
  return row.contact?.name || row.nickname || "";
}
function isOnline(row) {
  return !row.isSaved && !isDeletedAccount(row) && !!row.contact?.isOnline;
}
var LOCKED_CAPSULE_PREVIEW = "Time capsule \u{1F512}";
var ONE_TIME_PREVIEW = "One-time message";
function previewText(m, meId2) {
  if (!m) return "";
  const mine = m.senderId === meId2;
  if (m.isTimeCapsule && !mine) {
    if (m.isLocked) return LOCKED_CAPSULE_PREVIEW;
    if (!m.text) return "Time capsule unlocked";
  }
  if (m.isOneTime && !mine) return ONE_TIME_PREVIEW;
  return (m.text || "").replace(/\s+/g, " ").trim();
}
function toPreview(m) {
  return {
    id: m.id,
    conversationId: m.conversationId,
    senderId: m.senderId,
    text: m.text,
    createdAt: m.createdAt,
    isDeleted: false,
    isEdited: m.isEdited,
    isPinned: m.isPinned,
    isSeen: m.isSeen,
    isOneTime: m.isOneTime,
    isTimeCapsule: m.isTimeCapsule,
    isLocked: m.isLocked,
    scheduledFor: m.scheduledFor,
    openedAt: m.openedAt
  };
}
function effectiveLast(row, pending3, meId2) {
  if (pending3 && (!row.lastMessage || pending3.createdAt >= row.lastMessage.createdAt)) {
    return {
      text: pending3.text.replace(/\s+/g, " ").trim(),
      at: pending3.createdAt,
      mine: true,
      seen: false,
      pending: pending3.status !== "failed",
      failed: pending3.status === "failed"
    };
  }
  const m = row.lastMessage;
  if (!m) return null;
  return {
    text: previewText(m, meId2),
    at: m.createdAt,
    mine: m.senderId === meId2,
    seen: m.isSeen,
    pending: false,
    failed: false
  };
}
function lastTime(row, pending3) {
  const at = pending3 && (!row.lastMessage || pending3.createdAt >= row.lastMessage.createdAt) ? pending3.createdAt : row.lastMessage?.createdAt;
  const t = at ? Date.parse(at) : NaN;
  return Number.isFinite(t) ? t : 0;
}
function sectionOf(row, openConvId, meId2, pending3) {
  if (row.isArchived && !row.isSaved) return "archived";
  if (row.isSaved || row.isPinned || row.conversationId === openConvId || row.unreadCount > 0) return "active";
  if (pending3) return "active";
  const m = row.lastMessage;
  if (m && m.senderId === meId2 && !m.isSeen) return "active";
  return "contacts";
}
var nameKey = (row) => displayName(row).toLocaleLowerCase();
function sortActive(rows, newestPending) {
  const rank = (r) => r.isSaved ? 0 : r.isPinned ? 1 : 2;
  return [...rows].sort((a, b) => {
    const ra = rank(a);
    const rb = rank(b);
    if (ra !== rb) return ra - rb;
    if (ra === 1) {
      const pa = a.pinOrder ?? Number.MAX_SAFE_INTEGER;
      const pb = b.pinOrder ?? Number.MAX_SAFE_INTEGER;
      if (pa !== pb) return pa - pb;
    }
    const t = lastTime(b, newestPending[b.conversationId]) - lastTime(a, newestPending[a.conversationId]);
    if (t !== 0) return t;
    return nameKey(a).localeCompare(nameKey(b));
  });
}
function sortContacts(rows) {
  const group = (r) => r.isBlocked ? 2 : r.lastMessage ? 0 : 1;
  return [...rows].sort((a, b) => {
    const ga = group(a);
    const gb = group(b);
    if (ga !== gb) return ga - gb;
    const am = a.lastMessage ? 1 : 0;
    const bm = b.lastMessage ? 1 : 0;
    if (am !== bm) return bm - am;
    if (am) {
      const t = lastTime(b) - lastTime(a);
      if (t !== 0) return t;
    }
    return b.id - a.id;
  });
}
function getRow(conversationId) {
  if (conversationId === null || conversationId === void 0) return null;
  return contacts.get().byConv[conversationId] ?? null;
}
var rev = 0;
var changedAt = /* @__PURE__ */ new Map();
function touch(conversationId) {
  changedAt.set(conversationId, ++rev);
}
function contactsRev() {
  return rev;
}
function setAllRows(rows, askedAt = rev) {
  const newer = (convId) => (changedAt.get(convId) ?? 0) > askedAt;
  contacts.set((s) => {
    const byConv = {};
    for (const r of rows) {
      if (!newer(r.conversationId)) byConv[r.conversationId] = r;
      else if (s.byConv[r.conversationId]) byConv[r.conversationId] = s.byConv[r.conversationId];
    }
    for (const [k, local] of Object.entries(s.byConv)) {
      const convId = Number(k);
      if (!byConv[convId] && newer(convId)) byConv[convId] = local;
    }
    return { ...s, byConv, loaded: true, failed: false };
  });
}
function upsertRow(row) {
  touch(row.conversationId);
  contacts.set((s) => ({ ...s, byConv: { ...s.byConv, [row.conversationId]: row } }));
}
function patchRow(conversationId, patch) {
  touch(conversationId);
  contacts.set((s) => {
    const row = s.byConv[conversationId];
    if (!row) return s;
    const p = typeof patch === "function" ? patch(row) : patch;
    return { ...s, byConv: { ...s.byConv, [conversationId]: { ...row, ...p } } };
  });
}
function patchPerson(userId, patch) {
  contacts.set((s) => {
    let changed = false;
    const byConv = { ...s.byConv };
    for (const [k, r] of Object.entries(byConv)) {
      if (r.isSaved || r.contactId !== userId || !r.contact) continue;
      touch(Number(k));
      byConv[Number(k)] = { ...r, contact: { ...r.contact, ...patch } };
      changed = true;
    }
    return changed ? { ...s, byConv } : s;
  });
}
function removeRow(conversationId) {
  touch(conversationId);
  contacts.set((s) => {
    if (!s.byConv[conversationId]) return s;
    const byConv = { ...s.byConv };
    delete byConv[conversationId];
    return { ...s, byConv };
  });
}

// client/chat/services/clock.ts
var offsetMs = 0;
function noteServerTime(iso) {
  const t = Date.parse(iso);
  if (Number.isFinite(t)) offsetMs = t - Date.now();
}
function serverNow(deltaMs = 0) {
  return new Date(Date.now() + offsetMs + deltaMs).toISOString();
}

// client/chat/state/composerModel.ts
function getComposer(convId) {
  return composers.get()[convId] ?? EMPTY_COMPOSER;
}
function patchComposer(convId, patch) {
  composers.set((s) => ({ ...s, [convId]: { ...s[convId] ?? EMPTY_COMPOSER, ...patch } }));
}
function resetComposer(convId, { draft = false } = {}) {
  composers.set((s) => {
    const cur = s[convId];
    if (!cur) return s;
    return { ...s, [convId]: { ...EMPTY_COMPOSER, draft: draft ? "" : cur.draft } };
  });
}
function dropComposer(convId) {
  composers.set((s) => {
    if (!s[convId]) return s;
    const next = { ...s };
    delete next[convId];
    return next;
  });
}

// client/chat/services/feedback.ts
var TOAST_MS = 3e3;
var toastSeq = 0;
var toastTimer = null;
function showToast(text, opts = {}) {
  const id = ++toastSeq;
  toasts.set({ current: { id, text, icon: opts.icon ?? null, action: opts.action ?? null } });
  if (toastTimer !== null) window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => {
    toastTimer = null;
    toasts.set((s) => s.current?.id === id ? { current: null } : s);
  }, opts.ms ?? TOAST_MS);
}
function hideToast() {
  if (toastTimer !== null) window.clearTimeout(toastTimer);
  toastTimer = null;
  toasts.set({ current: null });
}
var MAX_QUEUED = 5;
var noticeSeq = 0;
function notify(n) {
  const notice = { ...n, id: ++noticeSeq };
  notices.set((s) => {
    const at = s.list.findIndex((x) => x.conversationId === n.conversationId);
    if (at >= 0) {
      const list2 = [...s.list];
      list2[at] = { ...notice, id: s.list[at].id };
      return { list: list2 };
    }
    const list = [...s.list, notice];
    return { list: list.length > MAX_QUEUED ? list.slice(list.length - MAX_QUEUED) : list };
  });
}
function dismissNotice(id) {
  notices.set((s) => ({ list: s.list.filter((x) => x.id !== id) }));
}
function clearNotices(conversationId) {
  notices.set((s) => ({ list: conversationId === void 0 ? [] : s.list.filter((x) => x.conversationId !== conversationId) }));
}

// client/chat/services/backStack.ts
var stack = [];
var queue = [];
var waitingForOwnPop = false;
var safety = null;
var started = false;
function pump() {
  while (!waitingForOwnPop && queue.length > 0) {
    const op = queue.shift();
    if (op === "push") {
      history.pushState({ rivoLayer: true }, "", location.href);
      continue;
    }
    let n = op;
    while (typeof queue[0] === "number") n += queue.shift();
    waitingForOwnPop = true;
    history.go(-n);
    safety = window.setTimeout(() => {
      waitingForOwnPop = false;
      pump();
    }, 1e3);
  }
}
function start() {
  if (started) return;
  started = true;
  if (history.state && typeof history.state === "object" && "rivoLayer" in history.state) {
    history.replaceState(null, "", location.href);
  }
  window.addEventListener("popstate", () => {
    if (waitingForOwnPop) {
      waitingForOwnPop = false;
      if (safety !== null) window.clearTimeout(safety);
      safety = null;
      pump();
      return;
    }
    stack.pop()?.close();
  });
}
function pushLayer(key2, close) {
  start();
  const existing = stack.find((l) => l.key === key2);
  if (existing) {
    existing.close = close;
    return;
  }
  stack.push({ key: key2, close });
  queue.push("push");
  pump();
}
function popLayer(key2) {
  const at = stack.findIndex((l) => l.key === key2);
  if (at < 0) return;
  const above = stack.splice(at + 1);
  stack.pop();
  queue.push(above.length + 1);
  pump();
  for (const layer of above.reverse()) layer.close();
}

// node_modules/engine.io-parser/build/esm/commons.js
var PACKET_TYPES = /* @__PURE__ */ Object.create(null);
PACKET_TYPES["open"] = "0";
PACKET_TYPES["close"] = "1";
PACKET_TYPES["ping"] = "2";
PACKET_TYPES["pong"] = "3";
PACKET_TYPES["message"] = "4";
PACKET_TYPES["upgrade"] = "5";
PACKET_TYPES["noop"] = "6";
var PACKET_TYPES_REVERSE = /* @__PURE__ */ Object.create(null);
Object.keys(PACKET_TYPES).forEach((key2) => {
  PACKET_TYPES_REVERSE[PACKET_TYPES[key2]] = key2;
});
var ERROR_PACKET = { type: "error", data: "parser error" };

// node_modules/engine.io-parser/build/esm/encodePacket.browser.js
var withNativeBlob = typeof Blob === "function" || typeof Blob !== "undefined" && Object.prototype.toString.call(Blob) === "[object BlobConstructor]";
var withNativeArrayBuffer = typeof ArrayBuffer === "function";
var isView = (obj) => {
  return typeof ArrayBuffer.isView === "function" ? ArrayBuffer.isView(obj) : obj && obj.buffer instanceof ArrayBuffer;
};
var encodePacket = ({ type, data }, supportsBinary, callback) => {
  if (withNativeBlob && data instanceof Blob) {
    if (supportsBinary) {
      return callback(data);
    } else {
      return encodeBlobAsBase64(data, callback);
    }
  } else if (withNativeArrayBuffer && (data instanceof ArrayBuffer || isView(data))) {
    if (supportsBinary) {
      return callback(data);
    } else {
      return encodeBlobAsBase64(new Blob([data]), callback);
    }
  }
  return callback(PACKET_TYPES[type] + (data || ""));
};
var encodeBlobAsBase64 = (data, callback) => {
  const fileReader = new FileReader();
  fileReader.onload = function() {
    const content = fileReader.result.split(",")[1];
    callback("b" + (content || ""));
  };
  return fileReader.readAsDataURL(data);
};
function toArray(data) {
  if (data instanceof Uint8Array) {
    return data;
  } else if (data instanceof ArrayBuffer) {
    return new Uint8Array(data);
  } else {
    return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
  }
}
var TEXT_ENCODER;
function encodePacketToBinary(packet, callback) {
  if (withNativeBlob && packet.data instanceof Blob) {
    return packet.data.arrayBuffer().then(toArray).then(callback);
  } else if (withNativeArrayBuffer && (packet.data instanceof ArrayBuffer || isView(packet.data))) {
    return callback(toArray(packet.data));
  }
  encodePacket(packet, false, (encoded) => {
    if (!TEXT_ENCODER) {
      TEXT_ENCODER = new TextEncoder();
    }
    callback(TEXT_ENCODER.encode(encoded));
  });
}

// node_modules/engine.io-parser/build/esm/contrib/base64-arraybuffer.js
var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
var lookup = typeof Uint8Array === "undefined" ? [] : new Uint8Array(256);
for (let i = 0; i < chars.length; i++) {
  lookup[chars.charCodeAt(i)] = i;
}
var decode = (base64) => {
  let bufferLength = base64.length * 0.75, len = base64.length, i, p = 0, encoded1, encoded2, encoded3, encoded4;
  if (base64[base64.length - 1] === "=") {
    bufferLength--;
    if (base64[base64.length - 2] === "=") {
      bufferLength--;
    }
  }
  const arraybuffer = new ArrayBuffer(bufferLength), bytes = new Uint8Array(arraybuffer);
  for (i = 0; i < len; i += 4) {
    encoded1 = lookup[base64.charCodeAt(i)];
    encoded2 = lookup[base64.charCodeAt(i + 1)];
    encoded3 = lookup[base64.charCodeAt(i + 2)];
    encoded4 = lookup[base64.charCodeAt(i + 3)];
    bytes[p++] = encoded1 << 2 | encoded2 >> 4;
    bytes[p++] = (encoded2 & 15) << 4 | encoded3 >> 2;
    bytes[p++] = (encoded3 & 3) << 6 | encoded4 & 63;
  }
  return arraybuffer;
};

// node_modules/engine.io-parser/build/esm/decodePacket.browser.js
var withNativeArrayBuffer2 = typeof ArrayBuffer === "function";
var decodePacket = (encodedPacket, binaryType) => {
  if (typeof encodedPacket !== "string") {
    return {
      type: "message",
      data: mapBinary(encodedPacket, binaryType)
    };
  }
  const type = encodedPacket.charAt(0);
  if (type === "b") {
    return {
      type: "message",
      data: decodeBase64Packet(encodedPacket.substring(1), binaryType)
    };
  }
  const packetType = PACKET_TYPES_REVERSE[type];
  if (!packetType) {
    return ERROR_PACKET;
  }
  return encodedPacket.length > 1 ? {
    type: PACKET_TYPES_REVERSE[type],
    data: encodedPacket.substring(1)
  } : {
    type: PACKET_TYPES_REVERSE[type]
  };
};
var decodeBase64Packet = (data, binaryType) => {
  if (withNativeArrayBuffer2) {
    const decoded = decode(data);
    return mapBinary(decoded, binaryType);
  } else {
    return { base64: true, data };
  }
};
var mapBinary = (data, binaryType) => {
  switch (binaryType) {
    case "blob":
      if (data instanceof Blob) {
        return data;
      } else {
        return new Blob([data]);
      }
    case "arraybuffer":
    default:
      if (data instanceof ArrayBuffer) {
        return data;
      } else {
        return data.buffer;
      }
  }
};

// node_modules/engine.io-parser/build/esm/index.js
var SEPARATOR = String.fromCharCode(30);
var encodePayload = (packets, callback) => {
  const length = packets.length;
  const encodedPackets = new Array(length);
  let count2 = 0;
  packets.forEach((packet, i) => {
    encodePacket(packet, false, (encodedPacket) => {
      encodedPackets[i] = encodedPacket;
      if (++count2 === length) {
        callback(encodedPackets.join(SEPARATOR));
      }
    });
  });
};
var decodePayload = (encodedPayload, binaryType) => {
  const encodedPackets = encodedPayload.split(SEPARATOR);
  const packets = [];
  for (let i = 0; i < encodedPackets.length; i++) {
    const decodedPacket = decodePacket(encodedPackets[i], binaryType);
    packets.push(decodedPacket);
    if (decodedPacket.type === "error") {
      break;
    }
  }
  return packets;
};
function createPacketEncoderStream() {
  return new TransformStream({
    transform(packet, controller) {
      encodePacketToBinary(packet, (encodedPacket) => {
        const payloadLength = encodedPacket.length;
        let header;
        if (payloadLength < 126) {
          header = new Uint8Array(1);
          new DataView(header.buffer).setUint8(0, payloadLength);
        } else if (payloadLength < 65536) {
          header = new Uint8Array(3);
          const view = new DataView(header.buffer);
          view.setUint8(0, 126);
          view.setUint16(1, payloadLength);
        } else {
          header = new Uint8Array(9);
          const view = new DataView(header.buffer);
          view.setUint8(0, 127);
          view.setBigUint64(1, BigInt(payloadLength));
        }
        if (packet.data && typeof packet.data !== "string") {
          header[0] |= 128;
        }
        controller.enqueue(header);
        controller.enqueue(encodedPacket);
      });
    }
  });
}
var TEXT_DECODER;
function totalLength(chunks) {
  return chunks.reduce((acc, chunk) => acc + chunk.length, 0);
}
function concatChunks(chunks, size) {
  if (chunks[0].length === size) {
    return chunks.shift();
  }
  const buffer = new Uint8Array(size);
  let j = 0;
  for (let i = 0; i < size; i++) {
    buffer[i] = chunks[0][j++];
    if (j === chunks[0].length) {
      chunks.shift();
      j = 0;
    }
  }
  if (chunks.length && j < chunks[0].length) {
    chunks[0] = chunks[0].slice(j);
  }
  return buffer;
}
function createPacketDecoderStream(maxPayload, binaryType) {
  if (!TEXT_DECODER) {
    TEXT_DECODER = new TextDecoder();
  }
  const chunks = [];
  let state = 0;
  let expectedLength = -1;
  let isBinary2 = false;
  return new TransformStream({
    transform(chunk, controller) {
      chunks.push(chunk);
      while (true) {
        if (state === 0) {
          if (totalLength(chunks) < 1) {
            break;
          }
          const header = concatChunks(chunks, 1);
          isBinary2 = (header[0] & 128) === 128;
          expectedLength = header[0] & 127;
          if (expectedLength < 126) {
            state = 3;
          } else if (expectedLength === 126) {
            state = 1;
          } else {
            state = 2;
          }
        } else if (state === 1) {
          if (totalLength(chunks) < 2) {
            break;
          }
          const headerArray = concatChunks(chunks, 2);
          expectedLength = new DataView(headerArray.buffer, headerArray.byteOffset, headerArray.length).getUint16(0);
          state = 3;
        } else if (state === 2) {
          if (totalLength(chunks) < 8) {
            break;
          }
          const headerArray = concatChunks(chunks, 8);
          const view = new DataView(headerArray.buffer, headerArray.byteOffset, headerArray.length);
          const n = view.getUint32(0);
          if (n > Math.pow(2, 53 - 32) - 1) {
            controller.enqueue(ERROR_PACKET);
            break;
          }
          expectedLength = n * Math.pow(2, 32) + view.getUint32(4);
          state = 3;
        } else {
          if (totalLength(chunks) < expectedLength) {
            break;
          }
          const data = concatChunks(chunks, expectedLength);
          controller.enqueue(decodePacket(isBinary2 ? data : TEXT_DECODER.decode(data), binaryType));
          state = 0;
        }
        if (expectedLength === 0 || expectedLength > maxPayload) {
          controller.enqueue(ERROR_PACKET);
          break;
        }
      }
    }
  });
}
var protocol = 4;

// node_modules/@socket.io/component-emitter/lib/esm/index.js
function Emitter(obj) {
  if (obj) return mixin(obj);
}
function mixin(obj) {
  for (var key2 in Emitter.prototype) {
    obj[key2] = Emitter.prototype[key2];
  }
  return obj;
}
Emitter.prototype.on = Emitter.prototype.addEventListener = function(event, fn) {
  this._callbacks = this._callbacks || {};
  (this._callbacks["$" + event] = this._callbacks["$" + event] || []).push(fn);
  return this;
};
Emitter.prototype.once = function(event, fn) {
  function on3() {
    this.off(event, on3);
    fn.apply(this, arguments);
  }
  on3.fn = fn;
  this.on(event, on3);
  return this;
};
Emitter.prototype.off = Emitter.prototype.removeListener = Emitter.prototype.removeAllListeners = Emitter.prototype.removeEventListener = function(event, fn) {
  this._callbacks = this._callbacks || {};
  if (0 == arguments.length) {
    this._callbacks = {};
    return this;
  }
  var callbacks = this._callbacks["$" + event];
  if (!callbacks) return this;
  if (1 == arguments.length) {
    delete this._callbacks["$" + event];
    return this;
  }
  var cb;
  for (var i = 0; i < callbacks.length; i++) {
    cb = callbacks[i];
    if (cb === fn || cb.fn === fn) {
      callbacks.splice(i, 1);
      break;
    }
  }
  if (callbacks.length === 0) {
    delete this._callbacks["$" + event];
  }
  return this;
};
Emitter.prototype.emit = function(event) {
  this._callbacks = this._callbacks || {};
  var args = new Array(arguments.length - 1), callbacks = this._callbacks["$" + event];
  for (var i = 1; i < arguments.length; i++) {
    args[i - 1] = arguments[i];
  }
  if (callbacks) {
    callbacks = callbacks.slice(0);
    for (var i = 0, len = callbacks.length; i < len; ++i) {
      callbacks[i].apply(this, args);
    }
  }
  return this;
};
Emitter.prototype.emitReserved = Emitter.prototype.emit;
Emitter.prototype.listeners = function(event) {
  this._callbacks = this._callbacks || {};
  return this._callbacks["$" + event] || [];
};
Emitter.prototype.hasListeners = function(event) {
  return !!this.listeners(event).length;
};

// node_modules/engine.io-client/build/esm/globals.js
var nextTick = (() => {
  const isPromiseAvailable = typeof Promise === "function" && typeof Promise.resolve === "function";
  if (isPromiseAvailable) {
    return (cb) => Promise.resolve().then(cb);
  } else {
    return (cb, setTimeoutFn) => setTimeoutFn(cb, 0);
  }
})();
var globalThisShim = (() => {
  if (typeof self !== "undefined") {
    return self;
  } else if (typeof window !== "undefined") {
    return window;
  } else {
    return Function("return this")();
  }
})();
var defaultBinaryType = "arraybuffer";
function createCookieJar() {
}

// node_modules/engine.io-client/build/esm/util.js
function pick(obj, ...attr) {
  return attr.reduce((acc, k) => {
    if (obj.hasOwnProperty(k)) {
      acc[k] = obj[k];
    }
    return acc;
  }, {});
}
var NATIVE_SET_TIMEOUT = globalThisShim.setTimeout;
var NATIVE_CLEAR_TIMEOUT = globalThisShim.clearTimeout;
function installTimerFunctions(obj, opts) {
  if (opts.useNativeTimers) {
    obj.setTimeoutFn = NATIVE_SET_TIMEOUT.bind(globalThisShim);
    obj.clearTimeoutFn = NATIVE_CLEAR_TIMEOUT.bind(globalThisShim);
  } else {
    obj.setTimeoutFn = globalThisShim.setTimeout.bind(globalThisShim);
    obj.clearTimeoutFn = globalThisShim.clearTimeout.bind(globalThisShim);
  }
}
var BASE64_OVERHEAD = 1.33;
function byteLength(obj) {
  if (typeof obj === "string") {
    return utf8Length(obj);
  }
  return Math.ceil((obj.byteLength || obj.size) * BASE64_OVERHEAD);
}
function utf8Length(str) {
  let c = 0, length = 0;
  for (let i = 0, l = str.length; i < l; i++) {
    c = str.charCodeAt(i);
    if (c < 128) {
      length += 1;
    } else if (c < 2048) {
      length += 2;
    } else if (c < 55296 || c >= 57344) {
      length += 3;
    } else {
      i++;
      length += 4;
    }
  }
  return length;
}
function randomString() {
  return Date.now().toString(36).substring(3) + Math.random().toString(36).substring(2, 5);
}

// node_modules/engine.io-client/build/esm/contrib/parseqs.js
function encode(obj) {
  let str = "";
  for (let i in obj) {
    if (obj.hasOwnProperty(i)) {
      if (str.length)
        str += "&";
      str += encodeURIComponent(i) + "=" + encodeURIComponent(obj[i]);
    }
  }
  return str;
}
function decode2(qs) {
  let qry = {};
  let pairs = qs.split("&");
  for (let i = 0, l = pairs.length; i < l; i++) {
    let pair = pairs[i].split("=");
    qry[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1]);
  }
  return qry;
}

// node_modules/engine.io-client/build/esm/transport.js
var TransportError = class extends Error {
  constructor(reason, description, context) {
    super(reason);
    this.description = description;
    this.context = context;
    this.type = "TransportError";
  }
};
var Transport = class extends Emitter {
  /**
   * Transport abstract constructor.
   *
   * @param {Object} opts - options
   * @protected
   */
  constructor(opts) {
    super();
    this.writable = false;
    installTimerFunctions(this, opts);
    this.opts = opts;
    this.query = opts.query;
    this.socket = opts.socket;
    this.supportsBinary = !opts.forceBase64;
  }
  /**
   * Emits an error.
   *
   * @param {String} reason
   * @param description
   * @param context - the error context
   * @return {Transport} for chaining
   * @protected
   */
  onError(reason, description, context) {
    super.emitReserved("error", new TransportError(reason, description, context));
    return this;
  }
  /**
   * Opens the transport.
   */
  open() {
    this.readyState = "opening";
    this.doOpen();
    return this;
  }
  /**
   * Closes the transport.
   */
  close() {
    if (this.readyState === "opening" || this.readyState === "open") {
      this.doClose();
      this.onClose();
    }
    return this;
  }
  /**
   * Sends multiple packets.
   *
   * @param {Array} packets
   */
  send(packets) {
    if (this.readyState === "open") {
      this.write(packets);
    } else {
    }
  }
  /**
   * Called upon open
   *
   * @protected
   */
  onOpen() {
    this.readyState = "open";
    this.writable = true;
    super.emitReserved("open");
  }
  /**
   * Called with data.
   *
   * @param {String} data
   * @protected
   */
  onData(data) {
    const packet = decodePacket(data, this.socket.binaryType);
    this.onPacket(packet);
  }
  /**
   * Called with a decoded packet.
   *
   * @protected
   */
  onPacket(packet) {
    super.emitReserved("packet", packet);
  }
  /**
   * Called upon close.
   *
   * @protected
   */
  onClose(details) {
    this.readyState = "closed";
    super.emitReserved("close", details);
  }
  /**
   * Pauses the transport, in order not to lose packets during an upgrade.
   *
   * @param onPause
   */
  pause(onPause) {
  }
  createUri(schema, query = {}) {
    return schema + "://" + this._hostname() + this._port() + this.opts.path + this._query(query);
  }
  _hostname() {
    const hostname = this.opts.hostname;
    return hostname.indexOf(":") === -1 ? hostname : "[" + hostname + "]";
  }
  _port() {
    if (this.opts.port && (this.opts.secure && Number(this.opts.port) !== 443 || !this.opts.secure && Number(this.opts.port) !== 80)) {
      return ":" + this.opts.port;
    } else {
      return "";
    }
  }
  _query(query) {
    const encodedQuery = encode(query);
    return encodedQuery.length ? "?" + encodedQuery : "";
  }
};

// node_modules/engine.io-client/build/esm/transports/polling.js
var Polling = class extends Transport {
  constructor() {
    super(...arguments);
    this._polling = false;
  }
  get name() {
    return "polling";
  }
  /**
   * Opens the socket (triggers polling). We write a PING message to determine
   * when the transport is open.
   *
   * @protected
   */
  doOpen() {
    this._poll();
  }
  /**
   * Pauses polling.
   *
   * @param {Function} onPause - callback upon buffers are flushed and transport is paused
   * @package
   */
  pause(onPause) {
    this.readyState = "pausing";
    const pause = () => {
      this.readyState = "paused";
      onPause();
    };
    if (this._polling || !this.writable) {
      let total = 0;
      if (this._polling) {
        total++;
        this.once("pollComplete", function() {
          --total || pause();
        });
      }
      if (!this.writable) {
        total++;
        this.once("drain", function() {
          --total || pause();
        });
      }
    } else {
      pause();
    }
  }
  /**
   * Starts polling cycle.
   *
   * @private
   */
  _poll() {
    this._polling = true;
    this.doPoll();
    this.emitReserved("poll");
  }
  /**
   * Overloads onData to detect payloads.
   *
   * @protected
   */
  onData(data) {
    const callback = (packet) => {
      if ("opening" === this.readyState && packet.type === "open") {
        this.onOpen();
      }
      if ("close" === packet.type) {
        this.onClose({ description: "transport closed by the server" });
        return false;
      }
      this.onPacket(packet);
    };
    decodePayload(data, this.socket.binaryType).forEach(callback);
    if ("closed" !== this.readyState) {
      this._polling = false;
      this.emitReserved("pollComplete");
      if ("open" === this.readyState) {
        this._poll();
      } else {
      }
    }
  }
  /**
   * For polling, send a close packet.
   *
   * @protected
   */
  doClose() {
    const close = () => {
      this.write([{ type: "close" }]);
    };
    if ("open" === this.readyState) {
      close();
    } else {
      this.once("open", close);
    }
  }
  /**
   * Writes a packets payload.
   *
   * @param {Array} packets - data packets
   * @protected
   */
  write(packets) {
    this.writable = false;
    encodePayload(packets, (data) => {
      this.doWrite(data, () => {
        this.writable = true;
        this.emitReserved("drain");
      });
    });
  }
  /**
   * Generates uri for connection.
   *
   * @private
   */
  uri() {
    const schema = this.opts.secure ? "https" : "http";
    const query = this.query || {};
    if (false !== this.opts.timestampRequests) {
      query[this.opts.timestampParam] = randomString();
    }
    if (!this.supportsBinary && !query.sid) {
      query.b64 = 1;
    }
    return this.createUri(schema, query);
  }
};

// node_modules/engine.io-client/build/esm/contrib/has-cors.js
var value = false;
try {
  value = typeof XMLHttpRequest !== "undefined" && "withCredentials" in new XMLHttpRequest();
} catch (err) {
}
var hasCORS = value;

// node_modules/engine.io-client/build/esm/transports/polling-xhr.js
function empty() {
}
var BaseXHR = class extends Polling {
  /**
   * XHR Polling constructor.
   *
   * @param {Object} opts
   * @package
   */
  constructor(opts) {
    super(opts);
    if (typeof location !== "undefined") {
      const isSSL = "https:" === location.protocol;
      let port = location.port;
      if (!port) {
        port = isSSL ? "443" : "80";
      }
      this.xd = typeof location !== "undefined" && opts.hostname !== location.hostname || port !== opts.port;
    }
  }
  /**
   * Sends data.
   *
   * @param {String} data - data to send.
   * @param {Function} fn - called upon flush.
   * @private
   */
  doWrite(data, fn) {
    const req = this.request({
      method: "POST",
      data
    });
    req.on("success", fn);
    req.on("error", (xhrStatus, context) => {
      this.onError("xhr post error", xhrStatus, context);
    });
  }
  /**
   * Starts a poll cycle.
   *
   * @private
   */
  doPoll() {
    const req = this.request();
    req.on("data", this.onData.bind(this));
    req.on("error", (xhrStatus, context) => {
      this.onError("xhr poll error", xhrStatus, context);
    });
    this.pollXhr = req;
  }
};
var Request = class _Request extends Emitter {
  /**
   * Request constructor
   *
   * @param {Object} options
   * @package
   */
  constructor(createRequest, uri, opts) {
    super();
    this.createRequest = createRequest;
    installTimerFunctions(this, opts);
    this._opts = opts;
    this._method = opts.method || "GET";
    this._uri = uri;
    this._data = void 0 !== opts.data ? opts.data : null;
    this._create();
  }
  /**
   * Creates the XHR object and sends the request.
   *
   * @private
   */
  _create() {
    var _a;
    const opts = pick(this._opts, "agent", "pfx", "key", "passphrase", "cert", "ca", "ciphers", "rejectUnauthorized", "autoUnref");
    opts.xdomain = !!this._opts.xd;
    const xhr = this._xhr = this.createRequest(opts);
    try {
      xhr.open(this._method, this._uri, true);
      try {
        if (this._opts.extraHeaders) {
          xhr.setDisableHeaderCheck && xhr.setDisableHeaderCheck(true);
          for (let i in this._opts.extraHeaders) {
            if (this._opts.extraHeaders.hasOwnProperty(i)) {
              xhr.setRequestHeader(i, this._opts.extraHeaders[i]);
            }
          }
        }
      } catch (e) {
      }
      if ("POST" === this._method) {
        try {
          xhr.setRequestHeader("Content-type", "text/plain;charset=UTF-8");
        } catch (e) {
        }
      }
      try {
        xhr.setRequestHeader("Accept", "*/*");
      } catch (e) {
      }
      (_a = this._opts.cookieJar) === null || _a === void 0 ? void 0 : _a.addCookies(xhr);
      if ("withCredentials" in xhr) {
        xhr.withCredentials = this._opts.withCredentials;
      }
      if (this._opts.requestTimeout) {
        xhr.timeout = this._opts.requestTimeout;
      }
      xhr.onreadystatechange = () => {
        var _a2;
        if (xhr.readyState === 3) {
          (_a2 = this._opts.cookieJar) === null || _a2 === void 0 ? void 0 : _a2.parseCookies(
            // @ts-ignore
            xhr.getResponseHeader("set-cookie")
          );
        }
        if (4 !== xhr.readyState)
          return;
        if (200 === xhr.status || 1223 === xhr.status) {
          this._onLoad();
        } else {
          this.setTimeoutFn(() => {
            this._onError(typeof xhr.status === "number" ? xhr.status : 0);
          }, 0);
        }
      };
      xhr.send(this._data);
    } catch (e) {
      this.setTimeoutFn(() => {
        this._onError(e);
      }, 0);
      return;
    }
    if (typeof document !== "undefined") {
      this._index = _Request.requestsCount++;
      _Request.requests[this._index] = this;
    }
  }
  /**
   * Called upon error.
   *
   * @private
   */
  _onError(err) {
    this.emitReserved("error", err, this._xhr);
    this._cleanup(true);
  }
  /**
   * Cleans up house.
   *
   * @private
   */
  _cleanup(fromError) {
    if ("undefined" === typeof this._xhr || null === this._xhr) {
      return;
    }
    this._xhr.onreadystatechange = empty;
    if (fromError) {
      try {
        this._xhr.abort();
      } catch (e) {
      }
    }
    if (typeof document !== "undefined") {
      delete _Request.requests[this._index];
    }
    this._xhr = null;
  }
  /**
   * Called upon load.
   *
   * @private
   */
  _onLoad() {
    const data = this._xhr.responseText;
    if (data !== null) {
      this.emitReserved("data", data);
      this.emitReserved("success");
      this._cleanup();
    }
  }
  /**
   * Aborts the request.
   *
   * @package
   */
  abort() {
    this._cleanup();
  }
};
Request.requestsCount = 0;
Request.requests = {};
if (typeof document !== "undefined") {
  if (typeof attachEvent === "function") {
    attachEvent("onunload", unloadHandler);
  } else if (typeof addEventListener === "function") {
    const terminationEvent = "onpagehide" in globalThisShim ? "pagehide" : "unload";
    addEventListener(terminationEvent, unloadHandler, false);
  }
}
function unloadHandler() {
  for (let i in Request.requests) {
    if (Request.requests.hasOwnProperty(i)) {
      Request.requests[i].abort();
    }
  }
}
var hasXHR2 = (function() {
  const xhr = newRequest({
    xdomain: false
  });
  return xhr && xhr.responseType !== null;
})();
var XHR = class extends BaseXHR {
  constructor(opts) {
    super(opts);
    const forceBase64 = opts && opts.forceBase64;
    this.supportsBinary = hasXHR2 && !forceBase64;
  }
  request(opts = {}) {
    Object.assign(opts, { xd: this.xd }, this.opts);
    return new Request(newRequest, this.uri(), opts);
  }
};
function newRequest(opts) {
  const xdomain = opts.xdomain;
  try {
    if ("undefined" !== typeof XMLHttpRequest && (!xdomain || hasCORS)) {
      return new XMLHttpRequest();
    }
  } catch (e) {
  }
  if (!xdomain) {
    try {
      return new globalThisShim[["Active"].concat("Object").join("X")]("Microsoft.XMLHTTP");
    } catch (e) {
    }
  }
}

// node_modules/engine.io-client/build/esm/transports/websocket.js
var isReactNative = typeof navigator !== "undefined" && typeof navigator.product === "string" && navigator.product.toLowerCase() === "reactnative";
var BaseWS = class extends Transport {
  get name() {
    return "websocket";
  }
  doOpen() {
    const uri = this.uri();
    const protocols = this.opts.protocols;
    const opts = isReactNative ? {} : pick(this.opts, "agent", "perMessageDeflate", "pfx", "key", "passphrase", "cert", "ca", "ciphers", "rejectUnauthorized", "localAddress", "protocolVersion", "origin", "maxPayload", "family", "checkServerIdentity");
    if (this.opts.extraHeaders) {
      opts.headers = this.opts.extraHeaders;
    }
    try {
      this.ws = this.createSocket(uri, protocols, opts);
    } catch (err) {
      return this.emitReserved("error", err);
    }
    this.ws.binaryType = this.socket.binaryType;
    this.addEventListeners();
  }
  /**
   * Adds event listeners to the socket
   *
   * @private
   */
  addEventListeners() {
    this.ws.onopen = () => {
      if (this.opts.autoUnref) {
        this.ws._socket.unref();
      }
      this.onOpen();
    };
    this.ws.onclose = (closeEvent) => this.onClose({
      description: "websocket connection closed",
      context: closeEvent
    });
    this.ws.onmessage = (ev) => this.onData(ev.data);
    this.ws.onerror = (e) => this.onError("websocket error", e);
  }
  write(packets) {
    this.writable = false;
    for (let i = 0; i < packets.length; i++) {
      const packet = packets[i];
      const lastPacket = i === packets.length - 1;
      encodePacket(packet, this.supportsBinary, (data) => {
        try {
          this.doWrite(packet, data);
        } catch (e) {
        }
        if (lastPacket) {
          nextTick(() => {
            this.writable = true;
            this.emitReserved("drain");
          }, this.setTimeoutFn);
        }
      });
    }
  }
  doClose() {
    if (typeof this.ws !== "undefined") {
      this.ws.onerror = () => {
      };
      this.ws.close();
      this.ws = null;
    }
  }
  /**
   * Generates uri for connection.
   *
   * @private
   */
  uri() {
    const schema = this.opts.secure ? "wss" : "ws";
    const query = this.query || {};
    if (this.opts.timestampRequests) {
      query[this.opts.timestampParam] = randomString();
    }
    if (!this.supportsBinary) {
      query.b64 = 1;
    }
    return this.createUri(schema, query);
  }
};
var WebSocketCtor = globalThisShim.WebSocket || globalThisShim.MozWebSocket;
var WS = class extends BaseWS {
  createSocket(uri, protocols, opts) {
    return !isReactNative ? protocols ? new WebSocketCtor(uri, protocols) : new WebSocketCtor(uri) : new WebSocketCtor(uri, protocols, opts);
  }
  doWrite(_packet, data) {
    this.ws.send(data);
  }
};

// node_modules/engine.io-client/build/esm/transports/webtransport.js
var WT = class extends Transport {
  get name() {
    return "webtransport";
  }
  doOpen() {
    try {
      this._transport = new WebTransport(this.createUri("https"), this.opts.transportOptions[this.name]);
    } catch (err) {
      return this.emitReserved("error", err);
    }
    this._transport.closed.then(() => {
      this.onClose();
    }).catch((err) => {
      this.onError("webtransport error", err);
    });
    this._transport.ready.then(() => {
      this._transport.createBidirectionalStream().then((stream) => {
        const decoderStream = createPacketDecoderStream(Number.MAX_SAFE_INTEGER, this.socket.binaryType);
        const reader = stream.readable.pipeThrough(decoderStream).getReader();
        const encoderStream = createPacketEncoderStream();
        encoderStream.readable.pipeTo(stream.writable);
        this._writer = encoderStream.writable.getWriter();
        const read2 = () => {
          reader.read().then(({ done, value: value2 }) => {
            if (done) {
              return;
            }
            this.onPacket(value2);
            read2();
          }).catch((err) => {
          });
        };
        read2();
        const packet = { type: "open" };
        if (this.query.sid) {
          packet.data = `{"sid":"${this.query.sid}"}`;
        }
        this._writer.write(packet).then(() => this.onOpen());
      });
    });
  }
  write(packets) {
    this.writable = false;
    for (let i = 0; i < packets.length; i++) {
      const packet = packets[i];
      const lastPacket = i === packets.length - 1;
      this._writer.write(packet).then(() => {
        if (lastPacket) {
          nextTick(() => {
            this.writable = true;
            this.emitReserved("drain");
          }, this.setTimeoutFn);
        }
      });
    }
  }
  doClose() {
    var _a;
    (_a = this._transport) === null || _a === void 0 ? void 0 : _a.close();
  }
};

// node_modules/engine.io-client/build/esm/transports/index.js
var transports = {
  websocket: WS,
  webtransport: WT,
  polling: XHR
};

// node_modules/engine.io-client/build/esm/contrib/parseuri.js
var re = /^(?:(?![^:@\/?#]+:[^:@\/]*@)(http|https|ws|wss):\/\/)?((?:(([^:@\/?#]*)(?::([^:@\/?#]*))?)?@)?((?:[a-f0-9]{0,4}:){2,7}[a-f0-9]{0,4}|[^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/;
var parts = [
  "source",
  "protocol",
  "authority",
  "userInfo",
  "user",
  "password",
  "host",
  "port",
  "relative",
  "path",
  "directory",
  "file",
  "query",
  "anchor"
];
function parse(str) {
  if (str.length > 8e3) {
    throw "URI too long";
  }
  const src = str, b = str.indexOf("["), e = str.indexOf("]");
  if (b != -1 && e != -1) {
    str = str.substring(0, b) + str.substring(b, e).replace(/:/g, ";") + str.substring(e, str.length);
  }
  let m = re.exec(str || ""), uri = {}, i = 14;
  while (i--) {
    uri[parts[i]] = m[i] || "";
  }
  if (b != -1 && e != -1) {
    uri.source = src;
    uri.host = uri.host.substring(1, uri.host.length - 1).replace(/;/g, ":");
    uri.authority = uri.authority.replace("[", "").replace("]", "").replace(/;/g, ":");
    uri.ipv6uri = true;
  }
  uri.pathNames = pathNames(uri, uri["path"]);
  uri.queryKey = queryKey(uri, uri["query"]);
  return uri;
}
function pathNames(obj, path) {
  const regx = /\/{2,9}/g, names = path.replace(regx, "/").split("/");
  if (path.slice(0, 1) == "/" || path.length === 0) {
    names.splice(0, 1);
  }
  if (path.slice(-1) == "/") {
    names.splice(names.length - 1, 1);
  }
  return names;
}
function queryKey(uri, query) {
  const data = {};
  query.replace(/(?:^|&)([^&=]*)=?([^&]*)/g, function($0, $1, $2) {
    if ($1) {
      data[$1] = $2;
    }
  });
  return data;
}

// node_modules/engine.io-client/build/esm/socket.js
var withEventListeners = typeof addEventListener === "function" && typeof removeEventListener === "function";
var OFFLINE_EVENT_LISTENERS = [];
if (withEventListeners) {
  addEventListener("offline", () => {
    OFFLINE_EVENT_LISTENERS.forEach((listener) => listener());
  }, false);
}
var SocketWithoutUpgrade = class _SocketWithoutUpgrade extends Emitter {
  /**
   * Socket constructor.
   *
   * @param {String|Object} uri - uri or options
   * @param {Object} opts - options
   */
  constructor(uri, opts) {
    super();
    this.binaryType = defaultBinaryType;
    this.writeBuffer = [];
    this._prevBufferLen = 0;
    this._pingInterval = -1;
    this._pingTimeout = -1;
    this._maxPayload = -1;
    this._pingTimeoutTime = Infinity;
    if (uri && "object" === typeof uri) {
      opts = uri;
      uri = null;
    }
    if (uri) {
      const parsedUri = parse(uri);
      opts.hostname = parsedUri.host;
      opts.secure = parsedUri.protocol === "https" || parsedUri.protocol === "wss";
      opts.port = parsedUri.port;
      if (parsedUri.query)
        opts.query = parsedUri.query;
    } else if (opts.host) {
      opts.hostname = parse(opts.host).host;
    }
    installTimerFunctions(this, opts);
    this.secure = null != opts.secure ? opts.secure : typeof location !== "undefined" && "https:" === location.protocol;
    if (opts.hostname && !opts.port) {
      opts.port = this.secure ? "443" : "80";
    }
    this.hostname = opts.hostname || (typeof location !== "undefined" ? location.hostname : "localhost");
    this.port = opts.port || (typeof location !== "undefined" && location.port ? location.port : this.secure ? "443" : "80");
    this.transports = [];
    this._transportsByName = {};
    opts.transports.forEach((t) => {
      const transportName = t.prototype.name;
      this.transports.push(transportName);
      this._transportsByName[transportName] = t;
    });
    this.opts = Object.assign({
      path: "/engine.io",
      agent: false,
      withCredentials: false,
      upgrade: true,
      timestampParam: "t",
      rememberUpgrade: false,
      addTrailingSlash: true,
      rejectUnauthorized: true,
      perMessageDeflate: {
        threshold: 1024
      },
      transportOptions: {},
      closeOnBeforeunload: false
    }, opts);
    this.opts.path = this.opts.path.replace(/\/$/, "") + (this.opts.addTrailingSlash ? "/" : "");
    if (typeof this.opts.query === "string") {
      this.opts.query = decode2(this.opts.query);
    }
    if (withEventListeners) {
      if (this.opts.closeOnBeforeunload) {
        this._beforeunloadEventListener = () => {
          if (this.transport) {
            this.transport.removeAllListeners();
            this.transport.close();
          }
        };
        addEventListener("beforeunload", this._beforeunloadEventListener, false);
      }
      if (this.hostname !== "localhost") {
        this._offlineEventListener = () => {
          this._onClose("transport close", {
            description: "network connection lost"
          });
        };
        OFFLINE_EVENT_LISTENERS.push(this._offlineEventListener);
      }
    }
    if (this.opts.withCredentials) {
      this._cookieJar = createCookieJar();
    }
    this._open();
  }
  /**
   * Creates transport of the given type.
   *
   * @param {String} name - transport name
   * @return {Transport}
   * @private
   */
  createTransport(name) {
    const query = Object.assign({}, this.opts.query);
    query.EIO = protocol;
    query.transport = name;
    if (this.id)
      query.sid = this.id;
    const opts = Object.assign({}, this.opts, {
      query,
      socket: this,
      hostname: this.hostname,
      secure: this.secure,
      port: this.port
    }, this.opts.transportOptions[name]);
    return new this._transportsByName[name](opts);
  }
  /**
   * Initializes transport to use and starts probe.
   *
   * @private
   */
  _open() {
    if (this.transports.length === 0) {
      this.setTimeoutFn(() => {
        this.emitReserved("error", "No transports available");
      }, 0);
      return;
    }
    const transportName = this.opts.rememberUpgrade && _SocketWithoutUpgrade.priorWebsocketSuccess && this.transports.indexOf("websocket") !== -1 ? "websocket" : this.transports[0];
    this.readyState = "opening";
    const transport = this.createTransport(transportName);
    transport.open();
    this.setTransport(transport);
  }
  /**
   * Sets the current transport. Disables the existing one (if any).
   *
   * @private
   */
  setTransport(transport) {
    if (this.transport) {
      this.transport.removeAllListeners();
    }
    this.transport = transport;
    transport.on("drain", this._onDrain.bind(this)).on("packet", this._onPacket.bind(this)).on("error", this._onError.bind(this)).on("close", (reason) => this._onClose("transport close", reason));
  }
  /**
   * Called when connection is deemed open.
   *
   * @private
   */
  onOpen() {
    this.readyState = "open";
    _SocketWithoutUpgrade.priorWebsocketSuccess = "websocket" === this.transport.name;
    this.emitReserved("open");
    this.flush();
  }
  /**
   * Handles a packet.
   *
   * @private
   */
  _onPacket(packet) {
    if ("opening" === this.readyState || "open" === this.readyState || "closing" === this.readyState) {
      this.emitReserved("packet", packet);
      this.emitReserved("heartbeat");
      switch (packet.type) {
        case "open":
          this.onHandshake(JSON.parse(packet.data));
          break;
        case "ping":
          this._sendPacket("pong");
          this.emitReserved("ping");
          this.emitReserved("pong");
          this._resetPingTimeout();
          break;
        case "error":
          const err = new Error("server error");
          err.code = packet.data;
          this._onError(err);
          break;
        case "message":
          this.emitReserved("data", packet.data);
          this.emitReserved("message", packet.data);
          break;
      }
    } else {
    }
  }
  /**
   * Called upon handshake completion.
   *
   * @param {Object} data - handshake obj
   * @private
   */
  onHandshake(data) {
    this.emitReserved("handshake", data);
    this.id = data.sid;
    this.transport.query.sid = data.sid;
    this._pingInterval = data.pingInterval;
    this._pingTimeout = data.pingTimeout;
    this._maxPayload = data.maxPayload;
    this.onOpen();
    if ("closed" === this.readyState)
      return;
    this._resetPingTimeout();
  }
  /**
   * Sets and resets ping timeout timer based on server pings.
   *
   * @private
   */
  _resetPingTimeout() {
    this.clearTimeoutFn(this._pingTimeoutTimer);
    const delay = this._pingInterval + this._pingTimeout;
    this._pingTimeoutTime = Date.now() + delay;
    this._pingTimeoutTimer = this.setTimeoutFn(() => {
      this._onClose("ping timeout");
    }, delay);
    if (this.opts.autoUnref) {
      this._pingTimeoutTimer.unref();
    }
  }
  /**
   * Called on `drain` event
   *
   * @private
   */
  _onDrain() {
    this.writeBuffer.splice(0, this._prevBufferLen);
    this._prevBufferLen = 0;
    if (0 === this.writeBuffer.length) {
      this.emitReserved("drain");
    } else {
      this.flush();
    }
  }
  /**
   * Flush write buffers.
   *
   * @private
   */
  flush() {
    if ("closed" !== this.readyState && this.transport.writable && !this.upgrading && this.writeBuffer.length) {
      const packets = this._getWritablePackets();
      this.transport.send(packets);
      this._prevBufferLen = packets.length;
      this.emitReserved("flush");
    }
  }
  /**
   * Ensure the encoded size of the writeBuffer is below the maxPayload value sent by the server (only for HTTP
   * long-polling)
   *
   * @private
   */
  _getWritablePackets() {
    const shouldCheckPayloadSize = this._maxPayload && this.transport.name === "polling" && this.writeBuffer.length > 1;
    if (!shouldCheckPayloadSize) {
      return this.writeBuffer;
    }
    let payloadSize = 1;
    for (let i = 0; i < this.writeBuffer.length; i++) {
      const data = this.writeBuffer[i].data;
      if (data) {
        payloadSize += byteLength(data);
      }
      if (i > 0 && payloadSize > this._maxPayload) {
        return this.writeBuffer.slice(0, i);
      }
      payloadSize += 2;
    }
    return this.writeBuffer;
  }
  /**
   * Checks whether the heartbeat timer has expired but the socket has not yet been notified.
   *
   * Note: this method is private for now because it does not really fit the WebSocket API, but if we put it in the
   * `write()` method then the message would not be buffered by the Socket.IO client.
   *
   * @return {boolean}
   * @private
   */
  /* private */
  _hasPingExpired() {
    if (!this._pingTimeoutTime)
      return true;
    const hasExpired = Date.now() > this._pingTimeoutTime;
    if (hasExpired) {
      this._pingTimeoutTime = 0;
      nextTick(() => {
        this._onClose("ping timeout");
      }, this.setTimeoutFn);
    }
    return hasExpired;
  }
  /**
   * Sends a message.
   *
   * @param {String} msg - message.
   * @param {Object} options.
   * @param {Function} fn - callback function.
   * @return {Socket} for chaining.
   */
  write(msg, options, fn) {
    this._sendPacket("message", msg, options, fn);
    return this;
  }
  /**
   * Sends a message. Alias of {@link Socket#write}.
   *
   * @param {String} msg - message.
   * @param {Object} options.
   * @param {Function} fn - callback function.
   * @return {Socket} for chaining.
   */
  send(msg, options, fn) {
    this._sendPacket("message", msg, options, fn);
    return this;
  }
  /**
   * Sends a packet.
   *
   * @param {String} type - packet type.
   * @param {String} data.
   * @param {Object} options.
   * @param {Function} fn - callback function.
   * @private
   */
  _sendPacket(type, data, options, fn) {
    if ("function" === typeof data) {
      fn = data;
      data = void 0;
    }
    if ("function" === typeof options) {
      fn = options;
      options = null;
    }
    if ("closing" === this.readyState || "closed" === this.readyState) {
      return;
    }
    options = options || {};
    options.compress = false !== options.compress;
    const packet = {
      type,
      data,
      options
    };
    this.emitReserved("packetCreate", packet);
    this.writeBuffer.push(packet);
    if (fn)
      this.once("flush", fn);
    this.flush();
  }
  /**
   * Closes the connection.
   */
  close() {
    const close = () => {
      this._onClose("forced close");
      this.transport.close();
    };
    const cleanupAndClose = () => {
      this.off("upgrade", cleanupAndClose);
      this.off("upgradeError", cleanupAndClose);
      close();
    };
    const waitForUpgrade = () => {
      this.once("upgrade", cleanupAndClose);
      this.once("upgradeError", cleanupAndClose);
    };
    if ("opening" === this.readyState || "open" === this.readyState) {
      this.readyState = "closing";
      if (this.writeBuffer.length) {
        this.once("drain", () => {
          if (this.upgrading) {
            waitForUpgrade();
          } else {
            close();
          }
        });
      } else if (this.upgrading) {
        waitForUpgrade();
      } else {
        close();
      }
    }
    return this;
  }
  /**
   * Called upon transport error
   *
   * @private
   */
  _onError(err) {
    _SocketWithoutUpgrade.priorWebsocketSuccess = false;
    if (this.opts.tryAllTransports && this.transports.length > 1 && this.readyState === "opening") {
      this.transports.shift();
      return this._open();
    }
    this.emitReserved("error", err);
    this._onClose("transport error", err);
  }
  /**
   * Called upon transport close.
   *
   * @private
   */
  _onClose(reason, description) {
    if ("opening" === this.readyState || "open" === this.readyState || "closing" === this.readyState) {
      this.clearTimeoutFn(this._pingTimeoutTimer);
      this.transport.removeAllListeners("close");
      this.transport.close();
      this.transport.removeAllListeners();
      if (withEventListeners) {
        if (this._beforeunloadEventListener) {
          removeEventListener("beforeunload", this._beforeunloadEventListener, false);
        }
        if (this._offlineEventListener) {
          const i = OFFLINE_EVENT_LISTENERS.indexOf(this._offlineEventListener);
          if (i !== -1) {
            OFFLINE_EVENT_LISTENERS.splice(i, 1);
          }
        }
      }
      this.readyState = "closed";
      this.id = null;
      this.emitReserved("close", reason, description);
      this.writeBuffer = [];
      this._prevBufferLen = 0;
    }
  }
};
SocketWithoutUpgrade.protocol = protocol;
var SocketWithUpgrade = class extends SocketWithoutUpgrade {
  constructor() {
    super(...arguments);
    this._upgrades = [];
  }
  onOpen() {
    super.onOpen();
    if ("open" === this.readyState && this.opts.upgrade) {
      for (let i = 0; i < this._upgrades.length; i++) {
        this._probe(this._upgrades[i]);
      }
    }
  }
  /**
   * Probes a transport.
   *
   * @param {String} name - transport name
   * @private
   */
  _probe(name) {
    let transport = this.createTransport(name);
    let failed = false;
    SocketWithoutUpgrade.priorWebsocketSuccess = false;
    const onTransportOpen = () => {
      if (failed)
        return;
      transport.send([{ type: "ping", data: "probe" }]);
      transport.once("packet", (msg) => {
        if (failed)
          return;
        if ("pong" === msg.type && "probe" === msg.data) {
          this.upgrading = true;
          this.emitReserved("upgrading", transport);
          if (!transport)
            return;
          SocketWithoutUpgrade.priorWebsocketSuccess = "websocket" === transport.name;
          this.transport.pause(() => {
            if (failed)
              return;
            if ("closed" === this.readyState)
              return;
            cleanup();
            this.setTransport(transport);
            transport.send([{ type: "upgrade" }]);
            this.emitReserved("upgrade", transport);
            transport = null;
            this.upgrading = false;
            this.flush();
          });
        } else {
          const err = new Error("probe error");
          err.transport = transport.name;
          this.emitReserved("upgradeError", err);
        }
      });
    };
    function freezeTransport() {
      if (failed)
        return;
      failed = true;
      cleanup();
      transport.close();
      transport = null;
    }
    const onerror = (err) => {
      const error = new Error("probe error: " + err);
      error.transport = transport.name;
      freezeTransport();
      this.emitReserved("upgradeError", error);
    };
    function onTransportClose() {
      onerror("transport closed");
    }
    function onclose() {
      onerror("socket closed");
    }
    function onupgrade(to) {
      if (transport && to.name !== transport.name) {
        freezeTransport();
      }
    }
    const cleanup = () => {
      transport.removeListener("open", onTransportOpen);
      transport.removeListener("error", onerror);
      transport.removeListener("close", onTransportClose);
      this.off("close", onclose);
      this.off("upgrading", onupgrade);
    };
    transport.once("open", onTransportOpen);
    transport.once("error", onerror);
    transport.once("close", onTransportClose);
    this.once("close", onclose);
    this.once("upgrading", onupgrade);
    if (this._upgrades.indexOf("webtransport") !== -1 && name !== "webtransport") {
      this.setTimeoutFn(() => {
        if (!failed) {
          transport.open();
        }
      }, 200);
    } else {
      transport.open();
    }
  }
  onHandshake(data) {
    this._upgrades = this._filterUpgrades(data.upgrades);
    super.onHandshake(data);
  }
  /**
   * Filters upgrades, returning only those matching client transports.
   *
   * @param {Array} upgrades - server upgrades
   * @private
   */
  _filterUpgrades(upgrades) {
    const filteredUpgrades = [];
    for (let i = 0; i < upgrades.length; i++) {
      if (~this.transports.indexOf(upgrades[i]))
        filteredUpgrades.push(upgrades[i]);
    }
    return filteredUpgrades;
  }
};
var Socket = class extends SocketWithUpgrade {
  constructor(uri, opts = {}) {
    const o = typeof uri === "object" ? uri : opts;
    if (!o.transports || o.transports && typeof o.transports[0] === "string") {
      o.transports = (o.transports || ["polling", "websocket", "webtransport"]).map((transportName) => transports[transportName]).filter((t) => !!t);
    }
    super(uri, o);
  }
};

// node_modules/engine.io-client/build/esm/index.js
var protocol2 = Socket.protocol;

// node_modules/socket.io-client/build/esm/url.js
function url(uri, path = "", loc) {
  let obj = uri;
  loc = loc || typeof location !== "undefined" && location;
  if (null == uri)
    uri = loc.protocol + "//" + loc.host;
  if (typeof uri === "string") {
    if ("/" === uri.charAt(0)) {
      if ("/" === uri.charAt(1)) {
        uri = loc.protocol + uri;
      } else {
        uri = loc.host + uri;
      }
    }
    if (!/^(https?|wss?):\/\//.test(uri)) {
      if ("undefined" !== typeof loc) {
        uri = loc.protocol + "//" + uri;
      } else {
        uri = "https://" + uri;
      }
    }
    obj = parse(uri);
  }
  if (!obj.port) {
    if (/^(http|ws)$/.test(obj.protocol)) {
      obj.port = "80";
    } else if (/^(http|ws)s$/.test(obj.protocol)) {
      obj.port = "443";
    }
  }
  obj.path = obj.path || "/";
  const ipv6 = obj.host.indexOf(":") !== -1;
  const host = ipv6 ? "[" + obj.host + "]" : obj.host;
  obj.id = obj.protocol + "://" + host + ":" + obj.port + path;
  obj.href = obj.protocol + "://" + host + (loc && loc.port === obj.port ? "" : ":" + obj.port);
  return obj;
}

// node_modules/socket.io-parser/build/esm/index.js
var esm_exports = {};
__export(esm_exports, {
  Decoder: () => Decoder,
  Encoder: () => Encoder,
  PacketType: () => PacketType,
  isPacketValid: () => isPacketValid,
  protocol: () => protocol3
});

// node_modules/socket.io-parser/build/esm/is-binary.js
var withNativeArrayBuffer3 = typeof ArrayBuffer === "function";
var isView2 = (obj) => {
  return typeof ArrayBuffer.isView === "function" ? ArrayBuffer.isView(obj) : obj.buffer instanceof ArrayBuffer;
};
var toString = Object.prototype.toString;
var withNativeBlob2 = typeof Blob === "function" || typeof Blob !== "undefined" && toString.call(Blob) === "[object BlobConstructor]";
var withNativeFile = typeof File === "function" || typeof File !== "undefined" && toString.call(File) === "[object FileConstructor]";
function isBinary(obj) {
  return withNativeArrayBuffer3 && (obj instanceof ArrayBuffer || isView2(obj)) || withNativeBlob2 && obj instanceof Blob || withNativeFile && obj instanceof File;
}
function hasBinary(obj, toJSON) {
  if (!obj || typeof obj !== "object") {
    return false;
  }
  if (Array.isArray(obj)) {
    for (let i = 0, l = obj.length; i < l; i++) {
      if (hasBinary(obj[i])) {
        return true;
      }
    }
    return false;
  }
  if (isBinary(obj)) {
    return true;
  }
  if (obj.toJSON && typeof obj.toJSON === "function" && arguments.length === 1) {
    return hasBinary(obj.toJSON(), true);
  }
  for (const key2 in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key2) && hasBinary(obj[key2])) {
      return true;
    }
  }
  return false;
}

// node_modules/socket.io-parser/build/esm/binary.js
function deconstructPacket(packet) {
  const buffers = [];
  const packetData = packet.data;
  const pack = packet;
  pack.data = _deconstructPacket(packetData, buffers);
  pack.attachments = buffers.length;
  return { packet: pack, buffers };
}
function _deconstructPacket(data, buffers) {
  if (!data)
    return data;
  if (isBinary(data)) {
    const placeholder = { _placeholder: true, num: buffers.length };
    buffers.push(data);
    return placeholder;
  } else if (Array.isArray(data)) {
    const newData = new Array(data.length);
    for (let i = 0; i < data.length; i++) {
      newData[i] = _deconstructPacket(data[i], buffers);
    }
    return newData;
  } else if (typeof data === "object" && !(data instanceof Date)) {
    const newData = {};
    for (const key2 in data) {
      if (Object.prototype.hasOwnProperty.call(data, key2)) {
        newData[key2] = _deconstructPacket(data[key2], buffers);
      }
    }
    return newData;
  }
  return data;
}
function reconstructPacket(packet, buffers) {
  packet.data = _reconstructPacket(packet.data, buffers);
  delete packet.attachments;
  return packet;
}
function _reconstructPacket(data, buffers) {
  if (!data)
    return data;
  if (data && data._placeholder === true) {
    const isIndexValid = typeof data.num === "number" && data.num >= 0 && data.num < buffers.length;
    if (isIndexValid) {
      return buffers[data.num];
    } else {
      throw new Error("illegal attachments");
    }
  } else if (Array.isArray(data)) {
    for (let i = 0; i < data.length; i++) {
      data[i] = _reconstructPacket(data[i], buffers);
    }
  } else if (typeof data === "object") {
    for (const key2 in data) {
      if (Object.prototype.hasOwnProperty.call(data, key2)) {
        data[key2] = _reconstructPacket(data[key2], buffers);
      }
    }
  }
  return data;
}

// node_modules/socket.io-parser/build/esm/index.js
var RESERVED_EVENTS = [
  "connect",
  // used on the client side
  "connect_error",
  // used on the client side
  "disconnect",
  // used on both sides
  "disconnecting",
  // used on the server side
  "newListener",
  // used by the Node.js EventEmitter
  "removeListener"
  // used by the Node.js EventEmitter
];
var protocol3 = 5;
var PacketType;
(function(PacketType2) {
  PacketType2[PacketType2["CONNECT"] = 0] = "CONNECT";
  PacketType2[PacketType2["DISCONNECT"] = 1] = "DISCONNECT";
  PacketType2[PacketType2["EVENT"] = 2] = "EVENT";
  PacketType2[PacketType2["ACK"] = 3] = "ACK";
  PacketType2[PacketType2["CONNECT_ERROR"] = 4] = "CONNECT_ERROR";
  PacketType2[PacketType2["BINARY_EVENT"] = 5] = "BINARY_EVENT";
  PacketType2[PacketType2["BINARY_ACK"] = 6] = "BINARY_ACK";
})(PacketType || (PacketType = {}));
var Encoder = class {
  /**
   * Encoder constructor
   *
   * @param {function} replacer - custom replacer to pass down to JSON.parse
   */
  constructor(replacer) {
    this.replacer = replacer;
  }
  /**
   * Encode a packet as a single string if non-binary, or as a
   * buffer sequence, depending on packet type.
   *
   * @param {Object} obj - packet object
   */
  encode(obj) {
    if (obj.type === PacketType.EVENT || obj.type === PacketType.ACK) {
      if (hasBinary(obj)) {
        return this.encodeAsBinary({
          type: obj.type === PacketType.EVENT ? PacketType.BINARY_EVENT : PacketType.BINARY_ACK,
          nsp: obj.nsp,
          data: obj.data,
          id: obj.id
        });
      }
    }
    return [this.encodeAsString(obj)];
  }
  /**
   * Encode packet as string.
   */
  encodeAsString(obj) {
    let str = "" + obj.type;
    if (obj.type === PacketType.BINARY_EVENT || obj.type === PacketType.BINARY_ACK) {
      str += obj.attachments + "-";
    }
    if (obj.nsp && "/" !== obj.nsp) {
      str += obj.nsp + ",";
    }
    if (null != obj.id) {
      str += obj.id;
    }
    if (null != obj.data) {
      str += JSON.stringify(obj.data, this.replacer);
    }
    return str;
  }
  /**
   * Encode packet as 'buffer sequence' by removing blobs, and
   * deconstructing packet into object with placeholders and
   * a list of buffers.
   */
  encodeAsBinary(obj) {
    const deconstruction = deconstructPacket(obj);
    const pack = this.encodeAsString(deconstruction.packet);
    const buffers = deconstruction.buffers;
    buffers.unshift(pack);
    return buffers;
  }
};
var Decoder = class _Decoder extends Emitter {
  /**
   * Decoder constructor
   */
  constructor(opts) {
    super();
    this.opts = Object.assign({
      reviver: void 0,
      maxAttachments: 10
    }, typeof opts === "function" ? { reviver: opts } : opts);
  }
  /**
   * Decodes an encoded packet string into packet JSON.
   *
   * @param {String} obj - encoded packet
   */
  add(obj) {
    let packet;
    if (typeof obj === "string") {
      if (this.reconstructor) {
        throw new Error("got plaintext data when reconstructing a packet");
      }
      packet = this.decodeString(obj);
      const isBinaryEvent = packet.type === PacketType.BINARY_EVENT;
      if (isBinaryEvent || packet.type === PacketType.BINARY_ACK) {
        packet.type = isBinaryEvent ? PacketType.EVENT : PacketType.ACK;
        this.reconstructor = new BinaryReconstructor(packet);
        if (packet.attachments === 0) {
          super.emitReserved("decoded", packet);
        }
      } else {
        super.emitReserved("decoded", packet);
      }
    } else if (isBinary(obj) || obj.base64) {
      if (!this.reconstructor) {
        throw new Error("got binary data when not reconstructing a packet");
      } else {
        packet = this.reconstructor.takeBinaryData(obj);
        if (packet) {
          this.reconstructor = null;
          super.emitReserved("decoded", packet);
        }
      }
    } else {
      throw new Error("Unknown type: " + obj);
    }
  }
  /**
   * Decode a packet String (JSON data)
   *
   * @param {String} str
   * @return {Object} packet
   */
  decodeString(str) {
    let i = 0;
    const p = {
      type: Number(str.charAt(0))
    };
    if (PacketType[p.type] === void 0) {
      throw new Error("unknown packet type " + p.type);
    }
    if (p.type === PacketType.BINARY_EVENT || p.type === PacketType.BINARY_ACK) {
      const start3 = i + 1;
      while (str.charAt(++i) !== "-" && i != str.length) {
      }
      const buf = str.substring(start3, i);
      if (buf != Number(buf) || str.charAt(i) !== "-") {
        throw new Error("Illegal attachments");
      }
      const n = Number(buf);
      if (!isInteger(n) || n < 0) {
        throw new Error("Illegal attachments");
      } else if (n > this.opts.maxAttachments) {
        throw new Error("too many attachments");
      }
      p.attachments = n;
    }
    if ("/" === str.charAt(i + 1)) {
      const start3 = i + 1;
      while (++i) {
        const c = str.charAt(i);
        if ("," === c)
          break;
        if (i === str.length)
          break;
      }
      p.nsp = str.substring(start3, i);
    } else {
      p.nsp = "/";
    }
    const next = str.charAt(i + 1);
    if ("" !== next && Number(next) == next) {
      const start3 = i + 1;
      while (++i) {
        const c = str.charAt(i);
        if (null == c || Number(c) != c) {
          --i;
          break;
        }
        if (i === str.length)
          break;
      }
      p.id = Number(str.substring(start3, i + 1));
    }
    if (str.charAt(++i)) {
      const payload = this.tryParse(str.substr(i));
      if (_Decoder.isPayloadValid(p.type, payload)) {
        p.data = payload;
      } else {
        throw new Error("invalid payload");
      }
    }
    return p;
  }
  tryParse(str) {
    try {
      return JSON.parse(str, this.opts.reviver);
    } catch (e) {
      return false;
    }
  }
  static isPayloadValid(type, payload) {
    switch (type) {
      case PacketType.CONNECT:
        return isObject(payload);
      case PacketType.DISCONNECT:
        return payload === void 0;
      case PacketType.CONNECT_ERROR:
        return typeof payload === "string" || isObject(payload);
      case PacketType.EVENT:
      case PacketType.BINARY_EVENT:
        return Array.isArray(payload) && (typeof payload[0] === "number" || typeof payload[0] === "string" && RESERVED_EVENTS.indexOf(payload[0]) === -1);
      case PacketType.ACK:
      case PacketType.BINARY_ACK:
        return Array.isArray(payload);
    }
  }
  /**
   * Deallocates a parser's resources
   */
  destroy() {
    if (this.reconstructor) {
      this.reconstructor.finishedReconstruction();
      this.reconstructor = null;
    }
  }
};
var BinaryReconstructor = class {
  constructor(packet) {
    this.packet = packet;
    this.buffers = [];
    this.reconPack = packet;
  }
  /**
   * Method to be called when binary data received from connection
   * after a BINARY_EVENT packet.
   *
   * @param {Buffer | ArrayBuffer} binData - the raw binary data received
   * @return {null | Object} returns null if more binary data is expected or
   *   a reconstructed packet object if all buffers have been received.
   */
  takeBinaryData(binData) {
    this.buffers.push(binData);
    if (this.buffers.length === this.reconPack.attachments) {
      const packet = reconstructPacket(this.reconPack, this.buffers);
      this.finishedReconstruction();
      return packet;
    }
    return null;
  }
  /**
   * Cleans up binary packet reconstruction variables.
   */
  finishedReconstruction() {
    this.reconPack = null;
    this.buffers = [];
  }
};
function isNamespaceValid(nsp) {
  return typeof nsp === "string";
}
var isInteger = Number.isInteger || function(value2) {
  return typeof value2 === "number" && isFinite(value2) && Math.floor(value2) === value2;
};
function isAckIdValid(id) {
  return id === void 0 || isInteger(id);
}
function isObject(value2) {
  return Object.prototype.toString.call(value2) === "[object Object]";
}
function isDataValid(type, payload) {
  switch (type) {
    case PacketType.CONNECT:
      return payload === void 0 || isObject(payload);
    case PacketType.DISCONNECT:
      return payload === void 0;
    case PacketType.EVENT:
      return Array.isArray(payload) && (typeof payload[0] === "number" || typeof payload[0] === "string" && RESERVED_EVENTS.indexOf(payload[0]) === -1);
    case PacketType.ACK:
      return Array.isArray(payload);
    case PacketType.CONNECT_ERROR:
      return typeof payload === "string" || isObject(payload);
    default:
      return false;
  }
}
function isPacketValid(packet) {
  return isNamespaceValid(packet.nsp) && isAckIdValid(packet.id) && isDataValid(packet.type, packet.data);
}

// node_modules/socket.io-client/build/esm/on.js
function on(obj, ev, fn) {
  obj.on(ev, fn);
  return function subDestroy() {
    obj.off(ev, fn);
  };
}

// node_modules/socket.io-client/build/esm/socket.js
var RESERVED_EVENTS2 = Object.freeze({
  connect: 1,
  connect_error: 1,
  disconnect: 1,
  disconnecting: 1,
  // EventEmitter reserved events: https://nodejs.org/api/events.html#events_event_newlistener
  newListener: 1,
  removeListener: 1
});
var Socket2 = class extends Emitter {
  /**
   * `Socket` constructor.
   */
  constructor(io, nsp, opts) {
    super();
    this.connected = false;
    this.recovered = false;
    this.receiveBuffer = [];
    this.sendBuffer = [];
    this._queue = [];
    this._queueSeq = 0;
    this.ids = 0;
    this.acks = {};
    this.flags = {};
    this.io = io;
    this.nsp = nsp;
    if (opts && opts.auth) {
      this.auth = opts.auth;
    }
    this._opts = Object.assign({}, opts);
    if (this.io._autoConnect)
      this.open();
  }
  /**
   * Whether the socket is currently disconnected
   *
   * @example
   * const socket = io();
   *
   * socket.on("connect", () => {
   *   console.log(socket.disconnected); // false
   * });
   *
   * socket.on("disconnect", () => {
   *   console.log(socket.disconnected); // true
   * });
   */
  get disconnected() {
    return !this.connected;
  }
  /**
   * Subscribe to open, close and packet events
   *
   * @private
   */
  subEvents() {
    if (this.subs)
      return;
    const io = this.io;
    this.subs = [
      on(io, "open", this.onopen.bind(this)),
      on(io, "packet", this.onpacket.bind(this)),
      on(io, "error", this.onerror.bind(this)),
      on(io, "close", this.onclose.bind(this))
    ];
  }
  /**
   * Whether the Socket will try to reconnect when its Manager connects or reconnects.
   *
   * @example
   * const socket = io();
   *
   * console.log(socket.active); // true
   *
   * socket.on("disconnect", (reason) => {
   *   if (reason === "io server disconnect") {
   *     // the disconnection was initiated by the server, you need to manually reconnect
   *     console.log(socket.active); // false
   *   }
   *   // else the socket will automatically try to reconnect
   *   console.log(socket.active); // true
   * });
   */
  get active() {
    return !!this.subs;
  }
  /**
   * "Opens" the socket.
   *
   * @example
   * const socket = io({
   *   autoConnect: false
   * });
   *
   * socket.connect();
   */
  connect() {
    if (this.connected)
      return this;
    this.subEvents();
    if (!this.io["_reconnecting"])
      this.io.open();
    if ("open" === this.io._readyState)
      this.onopen();
    return this;
  }
  /**
   * Alias for {@link connect()}.
   */
  open() {
    return this.connect();
  }
  /**
   * Sends a `message` event.
   *
   * This method mimics the WebSocket.send() method.
   *
   * @see https://developer.mozilla.org/en-US/docs/Web/API/WebSocket/send
   *
   * @example
   * socket.send("hello");
   *
   * // this is equivalent to
   * socket.emit("message", "hello");
   *
   * @return self
   */
  send(...args) {
    args.unshift("message");
    this.emit.apply(this, args);
    return this;
  }
  /**
   * Override `emit`.
   * If the event is in `events`, it's emitted normally.
   *
   * @example
   * socket.emit("hello", "world");
   *
   * // all serializable datastructures are supported (no need to call JSON.stringify)
   * socket.emit("hello", 1, "2", { 3: ["4"], 5: Uint8Array.from([6]) });
   *
   * // with an acknowledgement from the server
   * socket.emit("hello", "world", (val) => {
   *   // ...
   * });
   *
   * @return self
   */
  emit(ev, ...args) {
    var _a, _b, _c;
    if (RESERVED_EVENTS2.hasOwnProperty(ev)) {
      throw new Error('"' + ev.toString() + '" is a reserved event name');
    }
    args.unshift(ev);
    if (this._opts.retries && !this.flags.fromQueue && !this.flags.volatile) {
      this._addToQueue(args);
      return this;
    }
    const packet = {
      type: PacketType.EVENT,
      data: args
    };
    packet.options = {};
    packet.options.compress = this.flags.compress !== false;
    if ("function" === typeof args[args.length - 1]) {
      const id = this.ids++;
      const ack = args.pop();
      this._registerAckCallback(id, ack);
      packet.id = id;
    }
    const isTransportWritable = (_b = (_a = this.io.engine) === null || _a === void 0 ? void 0 : _a.transport) === null || _b === void 0 ? void 0 : _b.writable;
    const isConnected2 = this.connected && !((_c = this.io.engine) === null || _c === void 0 ? void 0 : _c._hasPingExpired());
    const discardPacket = this.flags.volatile && !isTransportWritable;
    if (discardPacket) {
    } else if (isConnected2) {
      this.notifyOutgoingListeners(packet);
      this.packet(packet);
    } else {
      this.sendBuffer.push(packet);
    }
    this.flags = {};
    return this;
  }
  /**
   * @private
   */
  _registerAckCallback(id, ack) {
    var _a;
    const timeout = (_a = this.flags.timeout) !== null && _a !== void 0 ? _a : this._opts.ackTimeout;
    if (timeout === void 0) {
      this.acks[id] = ack;
      return;
    }
    const timer3 = this.io.setTimeoutFn(() => {
      delete this.acks[id];
      for (let i = 0; i < this.sendBuffer.length; i++) {
        if (this.sendBuffer[i].id === id) {
          this.sendBuffer.splice(i, 1);
        }
      }
      ack.call(this, new Error("operation has timed out"));
    }, timeout);
    const fn = (...args) => {
      this.io.clearTimeoutFn(timer3);
      ack.apply(this, args);
    };
    fn.withError = true;
    this.acks[id] = fn;
  }
  /**
   * Emits an event and waits for an acknowledgement
   *
   * @example
   * // without timeout
   * const response = await socket.emitWithAck("hello", "world");
   *
   * // with a specific timeout
   * try {
   *   const response = await socket.timeout(1000).emitWithAck("hello", "world");
   * } catch (err) {
   *   // the server did not acknowledge the event in the given delay
   * }
   *
   * @return a Promise that will be fulfilled when the server acknowledges the event
   */
  emitWithAck(ev, ...args) {
    return new Promise((resolve, reject) => {
      const fn = (arg1, arg2) => {
        return arg1 ? reject(arg1) : resolve(arg2);
      };
      fn.withError = true;
      args.push(fn);
      this.emit(ev, ...args);
    });
  }
  /**
   * Add the packet to the queue.
   * @param args
   * @private
   */
  _addToQueue(args) {
    let ack;
    if (typeof args[args.length - 1] === "function") {
      ack = args.pop();
    }
    const packet = {
      id: this._queueSeq++,
      tryCount: 0,
      pending: false,
      args,
      flags: Object.assign({ fromQueue: true }, this.flags)
    };
    args.push((err, ...responseArgs) => {
      if (packet !== this._queue[0]) {
      }
      const hasError = err !== null;
      if (hasError) {
        if (packet.tryCount > this._opts.retries) {
          this._queue.shift();
          if (ack) {
            ack(err);
          }
        }
      } else {
        this._queue.shift();
        if (ack) {
          ack(null, ...responseArgs);
        }
      }
      packet.pending = false;
      return this._drainQueue();
    });
    this._queue.push(packet);
    this._drainQueue();
  }
  /**
   * Send the first packet of the queue, and wait for an acknowledgement from the server.
   * @param force - whether to resend a packet that has not been acknowledged yet
   *
   * @private
   */
  _drainQueue(force = false) {
    if (!this.connected || this._queue.length === 0) {
      return;
    }
    const packet = this._queue[0];
    if (packet.pending && !force) {
      return;
    }
    packet.pending = true;
    packet.tryCount++;
    this.flags = packet.flags;
    this.emit.apply(this, packet.args);
  }
  /**
   * Sends a packet.
   *
   * @param packet
   * @private
   */
  packet(packet) {
    packet.nsp = this.nsp;
    this.io._packet(packet);
  }
  /**
   * Called upon engine `open`.
   *
   * @private
   */
  onopen() {
    if (typeof this.auth == "function") {
      this.auth((data) => {
        this._sendConnectPacket(data);
      });
    } else {
      this._sendConnectPacket(this.auth);
    }
  }
  /**
   * Sends a CONNECT packet to initiate the Socket.IO session.
   *
   * @param data
   * @private
   */
  _sendConnectPacket(data) {
    this.packet({
      type: PacketType.CONNECT,
      data: this._pid ? Object.assign({ pid: this._pid, offset: this._lastOffset }, data) : data
    });
  }
  /**
   * Called upon engine or manager `error`.
   *
   * @param err
   * @private
   */
  onerror(err) {
    if (!this.connected) {
      this.emitReserved("connect_error", err);
    }
  }
  /**
   * Called upon engine `close`.
   *
   * @param reason
   * @param description
   * @private
   */
  onclose(reason, description) {
    this.connected = false;
    delete this.id;
    this.emitReserved("disconnect", reason, description);
    this._clearAcks();
  }
  /**
   * Clears the acknowledgement handlers upon disconnection, since the client will never receive an acknowledgement from
   * the server.
   *
   * @private
   */
  _clearAcks() {
    Object.keys(this.acks).forEach((id) => {
      const isBuffered = this.sendBuffer.some((packet) => String(packet.id) === id);
      if (!isBuffered) {
        const ack = this.acks[id];
        delete this.acks[id];
        if (ack.withError) {
          ack.call(this, new Error("socket has been disconnected"));
        }
      }
    });
  }
  /**
   * Called with socket packet.
   *
   * @param packet
   * @private
   */
  onpacket(packet) {
    const sameNamespace = packet.nsp === this.nsp;
    if (!sameNamespace)
      return;
    switch (packet.type) {
      case PacketType.CONNECT:
        if (packet.data && packet.data.sid) {
          this.onconnect(packet.data.sid, packet.data.pid);
        } else {
          this.emitReserved("connect_error", new Error("It seems you are trying to reach a Socket.IO server in v2.x with a v3.x client, but they are not compatible (more information here: https://socket.io/docs/v3/migrating-from-2-x-to-3-0/)"));
        }
        break;
      case PacketType.EVENT:
      case PacketType.BINARY_EVENT:
        this.onevent(packet);
        break;
      case PacketType.ACK:
      case PacketType.BINARY_ACK:
        this.onack(packet);
        break;
      case PacketType.DISCONNECT:
        this.ondisconnect();
        break;
      case PacketType.CONNECT_ERROR:
        this.destroy();
        const err = new Error(packet.data.message);
        err.data = packet.data.data;
        this.emitReserved("connect_error", err);
        break;
    }
  }
  /**
   * Called upon a server event.
   *
   * @param packet
   * @private
   */
  onevent(packet) {
    const args = packet.data || [];
    if (null != packet.id) {
      args.push(this.ack(packet.id));
    }
    if (this.connected) {
      this.emitEvent(args);
    } else {
      this.receiveBuffer.push(Object.freeze(args));
    }
  }
  emitEvent(args) {
    if (this._anyListeners && this._anyListeners.length) {
      const listeners = this._anyListeners.slice();
      for (const listener of listeners) {
        listener.apply(this, args);
      }
    }
    super.emit.apply(this, args);
    if (this._pid && args.length && typeof args[args.length - 1] === "string") {
      this._lastOffset = args[args.length - 1];
    }
  }
  /**
   * Produces an ack callback to emit with an event.
   *
   * @private
   */
  ack(id) {
    const self2 = this;
    let sent = false;
    return function(...args) {
      if (sent)
        return;
      sent = true;
      self2.packet({
        type: PacketType.ACK,
        id,
        data: args
      });
    };
  }
  /**
   * Called upon a server acknowledgement.
   *
   * @param packet
   * @private
   */
  onack(packet) {
    const ack = this.acks[packet.id];
    if (typeof ack !== "function") {
      return;
    }
    delete this.acks[packet.id];
    if (ack.withError) {
      packet.data.unshift(null);
    }
    ack.apply(this, packet.data);
  }
  /**
   * Called upon server connect.
   *
   * @private
   */
  onconnect(id, pid) {
    this.id = id;
    this.recovered = pid && this._pid === pid;
    this._pid = pid;
    this.connected = true;
    this.emitBuffered();
    this._drainQueue(true);
    this.emitReserved("connect");
  }
  /**
   * Emit buffered events (received and emitted).
   *
   * @private
   */
  emitBuffered() {
    this.receiveBuffer.forEach((args) => this.emitEvent(args));
    this.receiveBuffer = [];
    this.sendBuffer.forEach((packet) => {
      this.notifyOutgoingListeners(packet);
      this.packet(packet);
    });
    this.sendBuffer = [];
  }
  /**
   * Called upon server disconnect.
   *
   * @private
   */
  ondisconnect() {
    this.destroy();
    this.onclose("io server disconnect");
  }
  /**
   * Called upon forced client/server side disconnections,
   * this method ensures the manager stops tracking us and
   * that reconnections don't get triggered for this.
   *
   * @private
   */
  destroy() {
    if (this.subs) {
      this.subs.forEach((subDestroy) => subDestroy());
      this.subs = void 0;
    }
    this.io["_destroy"](this);
  }
  /**
   * Disconnects the socket manually. In that case, the socket will not try to reconnect.
   *
   * If this is the last active Socket instance of the {@link Manager}, the low-level connection will be closed.
   *
   * @example
   * const socket = io();
   *
   * socket.on("disconnect", (reason) => {
   *   // console.log(reason); prints "io client disconnect"
   * });
   *
   * socket.disconnect();
   *
   * @return self
   */
  disconnect() {
    if (this.connected) {
      this.packet({ type: PacketType.DISCONNECT });
    }
    this.destroy();
    if (this.connected) {
      this.onclose("io client disconnect");
    }
    return this;
  }
  /**
   * Alias for {@link disconnect()}.
   *
   * @return self
   */
  close() {
    return this.disconnect();
  }
  /**
   * Sets the compress flag.
   *
   * @example
   * socket.compress(false).emit("hello");
   *
   * @param compress - if `true`, compresses the sending data
   * @return self
   */
  compress(compress) {
    this.flags.compress = compress;
    return this;
  }
  /**
   * Sets a modifier for a subsequent event emission that the event message will be dropped when this socket is not
   * ready to send messages.
   *
   * @example
   * socket.volatile.emit("hello"); // the server may or may not receive it
   *
   * @returns self
   */
  get volatile() {
    this.flags.volatile = true;
    return this;
  }
  /**
   * Sets a modifier for a subsequent event emission that the callback will be called with an error when the
   * given number of milliseconds have elapsed without an acknowledgement from the server:
   *
   * @example
   * socket.timeout(5000).emit("my-event", (err) => {
   *   if (err) {
   *     // the server did not acknowledge the event in the given delay
   *   }
   * });
   *
   * @returns self
   */
  timeout(timeout) {
    this.flags.timeout = timeout;
    return this;
  }
  /**
   * Adds a listener that will be fired when any event is emitted. The event name is passed as the first argument to the
   * callback.
   *
   * @example
   * socket.onAny((event, ...args) => {
   *   console.log(`got ${event}`);
   * });
   *
   * @param listener
   */
  onAny(listener) {
    this._anyListeners = this._anyListeners || [];
    this._anyListeners.push(listener);
    return this;
  }
  /**
   * Adds a listener that will be fired when any event is emitted. The event name is passed as the first argument to the
   * callback. The listener is added to the beginning of the listeners array.
   *
   * @example
   * socket.prependAny((event, ...args) => {
   *   console.log(`got event ${event}`);
   * });
   *
   * @param listener
   */
  prependAny(listener) {
    this._anyListeners = this._anyListeners || [];
    this._anyListeners.unshift(listener);
    return this;
  }
  /**
   * Removes the listener that will be fired when any event is emitted.
   *
   * @example
   * const catchAllListener = (event, ...args) => {
   *   console.log(`got event ${event}`);
   * }
   *
   * socket.onAny(catchAllListener);
   *
   * // remove a specific listener
   * socket.offAny(catchAllListener);
   *
   * // or remove all listeners
   * socket.offAny();
   *
   * @param listener
   */
  offAny(listener) {
    if (!this._anyListeners) {
      return this;
    }
    if (listener) {
      const listeners = this._anyListeners;
      for (let i = 0; i < listeners.length; i++) {
        if (listener === listeners[i]) {
          listeners.splice(i, 1);
          return this;
        }
      }
    } else {
      this._anyListeners = [];
    }
    return this;
  }
  /**
   * Returns an array of listeners that are listening for any event that is specified. This array can be manipulated,
   * e.g. to remove listeners.
   */
  listenersAny() {
    return this._anyListeners || [];
  }
  /**
   * Adds a listener that will be fired when any event is emitted. The event name is passed as the first argument to the
   * callback.
   *
   * Note: acknowledgements sent to the server are not included.
   *
   * @example
   * socket.onAnyOutgoing((event, ...args) => {
   *   console.log(`sent event ${event}`);
   * });
   *
   * @param listener
   */
  onAnyOutgoing(listener) {
    this._anyOutgoingListeners = this._anyOutgoingListeners || [];
    this._anyOutgoingListeners.push(listener);
    return this;
  }
  /**
   * Adds a listener that will be fired when any event is emitted. The event name is passed as the first argument to the
   * callback. The listener is added to the beginning of the listeners array.
   *
   * Note: acknowledgements sent to the server are not included.
   *
   * @example
   * socket.prependAnyOutgoing((event, ...args) => {
   *   console.log(`sent event ${event}`);
   * });
   *
   * @param listener
   */
  prependAnyOutgoing(listener) {
    this._anyOutgoingListeners = this._anyOutgoingListeners || [];
    this._anyOutgoingListeners.unshift(listener);
    return this;
  }
  /**
   * Removes the listener that will be fired when any event is emitted.
   *
   * @example
   * const catchAllListener = (event, ...args) => {
   *   console.log(`sent event ${event}`);
   * }
   *
   * socket.onAnyOutgoing(catchAllListener);
   *
   * // remove a specific listener
   * socket.offAnyOutgoing(catchAllListener);
   *
   * // or remove all listeners
   * socket.offAnyOutgoing();
   *
   * @param [listener] - the catch-all listener (optional)
   */
  offAnyOutgoing(listener) {
    if (!this._anyOutgoingListeners) {
      return this;
    }
    if (listener) {
      const listeners = this._anyOutgoingListeners;
      for (let i = 0; i < listeners.length; i++) {
        if (listener === listeners[i]) {
          listeners.splice(i, 1);
          return this;
        }
      }
    } else {
      this._anyOutgoingListeners = [];
    }
    return this;
  }
  /**
   * Returns an array of listeners that are listening for any event that is specified. This array can be manipulated,
   * e.g. to remove listeners.
   */
  listenersAnyOutgoing() {
    return this._anyOutgoingListeners || [];
  }
  /**
   * Notify the listeners for each packet sent
   *
   * @param packet
   *
   * @private
   */
  notifyOutgoingListeners(packet) {
    if (this._anyOutgoingListeners && this._anyOutgoingListeners.length) {
      const listeners = this._anyOutgoingListeners.slice();
      for (const listener of listeners) {
        listener.apply(this, packet.data);
      }
    }
  }
};

// node_modules/socket.io-client/build/esm/contrib/backo2.js
function Backoff(opts) {
  opts = opts || {};
  this.ms = opts.min || 100;
  this.max = opts.max || 1e4;
  this.factor = opts.factor || 2;
  this.jitter = opts.jitter > 0 && opts.jitter <= 1 ? opts.jitter : 0;
  this.attempts = 0;
}
Backoff.prototype.duration = function() {
  var ms = this.ms * Math.pow(this.factor, this.attempts++);
  if (this.jitter) {
    var rand = Math.random();
    var deviation = Math.floor(rand * this.jitter * ms);
    ms = (Math.floor(rand * 10) & 1) == 0 ? ms - deviation : ms + deviation;
  }
  return Math.min(ms, this.max) | 0;
};
Backoff.prototype.reset = function() {
  this.attempts = 0;
};
Backoff.prototype.setMin = function(min) {
  this.ms = min;
};
Backoff.prototype.setMax = function(max) {
  this.max = max;
};
Backoff.prototype.setJitter = function(jitter) {
  this.jitter = jitter;
};

// node_modules/socket.io-client/build/esm/manager.js
var Manager = class extends Emitter {
  constructor(uri, opts) {
    var _a;
    super();
    this.nsps = {};
    this.subs = [];
    if (uri && "object" === typeof uri) {
      opts = uri;
      uri = void 0;
    }
    opts = opts || {};
    opts.path = opts.path || "/socket.io";
    this.opts = opts;
    installTimerFunctions(this, opts);
    this.reconnection(opts.reconnection !== false);
    this.reconnectionAttempts(opts.reconnectionAttempts || Infinity);
    this.reconnectionDelay(opts.reconnectionDelay || 1e3);
    this.reconnectionDelayMax(opts.reconnectionDelayMax || 5e3);
    this.randomizationFactor((_a = opts.randomizationFactor) !== null && _a !== void 0 ? _a : 0.5);
    this.backoff = new Backoff({
      min: this.reconnectionDelay(),
      max: this.reconnectionDelayMax(),
      jitter: this.randomizationFactor()
    });
    this.timeout(null == opts.timeout ? 2e4 : opts.timeout);
    this._readyState = "closed";
    this.uri = uri;
    const _parser = opts.parser || esm_exports;
    this.encoder = new _parser.Encoder();
    this.decoder = new _parser.Decoder();
    this._autoConnect = opts.autoConnect !== false;
    if (this._autoConnect)
      this.open();
  }
  reconnection(v) {
    if (!arguments.length)
      return this._reconnection;
    this._reconnection = !!v;
    if (!v) {
      this.skipReconnect = true;
    }
    return this;
  }
  reconnectionAttempts(v) {
    if (v === void 0)
      return this._reconnectionAttempts;
    this._reconnectionAttempts = v;
    return this;
  }
  reconnectionDelay(v) {
    var _a;
    if (v === void 0)
      return this._reconnectionDelay;
    this._reconnectionDelay = v;
    (_a = this.backoff) === null || _a === void 0 ? void 0 : _a.setMin(v);
    return this;
  }
  randomizationFactor(v) {
    var _a;
    if (v === void 0)
      return this._randomizationFactor;
    this._randomizationFactor = v;
    (_a = this.backoff) === null || _a === void 0 ? void 0 : _a.setJitter(v);
    return this;
  }
  reconnectionDelayMax(v) {
    var _a;
    if (v === void 0)
      return this._reconnectionDelayMax;
    this._reconnectionDelayMax = v;
    (_a = this.backoff) === null || _a === void 0 ? void 0 : _a.setMax(v);
    return this;
  }
  timeout(v) {
    if (!arguments.length)
      return this._timeout;
    this._timeout = v;
    return this;
  }
  /**
   * Starts trying to reconnect if reconnection is enabled and we have not
   * started reconnecting yet
   *
   * @private
   */
  maybeReconnectOnOpen() {
    if (!this._reconnecting && this._reconnection && this.backoff.attempts === 0) {
      this.reconnect();
    }
  }
  /**
   * Sets the current transport `socket`.
   *
   * @param {Function} fn - optional, callback
   * @return self
   * @public
   */
  open(fn) {
    if (~this._readyState.indexOf("open"))
      return this;
    this.engine = new Socket(this.uri, this.opts);
    const socket2 = this.engine;
    const self2 = this;
    this._readyState = "opening";
    this.skipReconnect = false;
    const openSubDestroy = on(socket2, "open", function() {
      self2.onopen();
      fn && fn();
    });
    const onError = (err) => {
      this.cleanup();
      this._readyState = "closed";
      this.emitReserved("error", err);
      if (fn) {
        fn(err);
      } else {
        this.maybeReconnectOnOpen();
      }
    };
    const errorSub = on(socket2, "error", onError);
    if (false !== this._timeout) {
      const timeout = this._timeout;
      const timer3 = this.setTimeoutFn(() => {
        openSubDestroy();
        onError(new Error("timeout"));
        socket2.close();
      }, timeout);
      if (this.opts.autoUnref) {
        timer3.unref();
      }
      this.subs.push(() => {
        this.clearTimeoutFn(timer3);
      });
    }
    this.subs.push(openSubDestroy);
    this.subs.push(errorSub);
    return this;
  }
  /**
   * Alias for open()
   *
   * @return self
   * @public
   */
  connect(fn) {
    return this.open(fn);
  }
  /**
   * Called upon transport open.
   *
   * @private
   */
  onopen() {
    this.cleanup();
    this._readyState = "open";
    this.emitReserved("open");
    const socket2 = this.engine;
    this.subs.push(
      on(socket2, "ping", this.onping.bind(this)),
      on(socket2, "data", this.ondata.bind(this)),
      on(socket2, "error", this.onerror.bind(this)),
      on(socket2, "close", this.onclose.bind(this)),
      // @ts-ignore
      on(this.decoder, "decoded", this.ondecoded.bind(this))
    );
  }
  /**
   * Called upon a ping.
   *
   * @private
   */
  onping() {
    this.emitReserved("ping");
  }
  /**
   * Called with data.
   *
   * @private
   */
  ondata(data) {
    try {
      this.decoder.add(data);
    } catch (e) {
      this.onclose("parse error", e);
    }
  }
  /**
   * Called when parser fully decodes a packet.
   *
   * @private
   */
  ondecoded(packet) {
    nextTick(() => {
      this.emitReserved("packet", packet);
    }, this.setTimeoutFn);
  }
  /**
   * Called upon socket error.
   *
   * @private
   */
  onerror(err) {
    this.emitReserved("error", err);
  }
  /**
   * Creates a new socket for the given `nsp`.
   *
   * @return {Socket}
   * @public
   */
  socket(nsp, opts) {
    let socket2 = this.nsps[nsp];
    if (!socket2) {
      socket2 = new Socket2(this, nsp, opts);
      this.nsps[nsp] = socket2;
    } else if (this._autoConnect && !socket2.active) {
      socket2.connect();
    }
    return socket2;
  }
  /**
   * Called upon a socket close.
   *
   * @param socket
   * @private
   */
  _destroy(socket2) {
    const nsps = Object.keys(this.nsps);
    for (const nsp of nsps) {
      const socket3 = this.nsps[nsp];
      if (socket3.active) {
        return;
      }
    }
    this._close();
  }
  /**
   * Writes a packet.
   *
   * @param packet
   * @private
   */
  _packet(packet) {
    const encodedPackets = this.encoder.encode(packet);
    for (let i = 0; i < encodedPackets.length; i++) {
      this.engine.write(encodedPackets[i], packet.options);
    }
  }
  /**
   * Clean up transport subscriptions and packet buffer.
   *
   * @private
   */
  cleanup() {
    this.subs.forEach((subDestroy) => subDestroy());
    this.subs.length = 0;
    this.decoder.destroy();
  }
  /**
   * Close the current socket.
   *
   * @private
   */
  _close() {
    this.skipReconnect = true;
    this._reconnecting = false;
    this.onclose("forced close");
  }
  /**
   * Alias for close()
   *
   * @private
   */
  disconnect() {
    return this._close();
  }
  /**
   * Called when:
   *
   * - the low-level engine is closed
   * - the parser encountered a badly formatted packet
   * - all sockets are disconnected
   *
   * @private
   */
  onclose(reason, description) {
    var _a;
    this.cleanup();
    (_a = this.engine) === null || _a === void 0 ? void 0 : _a.close();
    this.backoff.reset();
    this._readyState = "closed";
    this.emitReserved("close", reason, description);
    if (this._reconnection && !this.skipReconnect) {
      this.reconnect();
    }
  }
  /**
   * Attempt a reconnection.
   *
   * @private
   */
  reconnect() {
    if (this._reconnecting || this.skipReconnect)
      return this;
    const self2 = this;
    if (this.backoff.attempts >= this._reconnectionAttempts) {
      this.backoff.reset();
      this.emitReserved("reconnect_failed");
      this._reconnecting = false;
    } else {
      const delay = this.backoff.duration();
      this._reconnecting = true;
      const timer3 = this.setTimeoutFn(() => {
        if (self2.skipReconnect)
          return;
        this.emitReserved("reconnect_attempt", self2.backoff.attempts);
        if (self2.skipReconnect)
          return;
        self2.open((err) => {
          if (err) {
            self2._reconnecting = false;
            self2.reconnect();
            this.emitReserved("reconnect_error", err);
          } else {
            self2.onreconnect();
          }
        });
      }, delay);
      if (this.opts.autoUnref) {
        timer3.unref();
      }
      this.subs.push(() => {
        this.clearTimeoutFn(timer3);
      });
    }
  }
  /**
   * Called upon successful reconnect.
   *
   * @private
   */
  onreconnect() {
    const attempt = this.backoff.attempts;
    this._reconnecting = false;
    this.backoff.reset();
    this.emitReserved("reconnect", attempt);
  }
};

// node_modules/socket.io-client/build/esm/index.js
var cache = {};
function lookup2(uri, opts) {
  if (typeof uri === "object") {
    opts = uri;
    uri = void 0;
  }
  opts = opts || {};
  const parsed = url(uri, opts.path || "/socket.io");
  const source = parsed.source;
  const id = parsed.id;
  const path = parsed.path;
  const sameNamespace = cache[id] && path in cache[id]["nsps"];
  const newConnection = opts.forceNew || opts["force new connection"] || false === opts.multiplex || sameNamespace;
  let io;
  if (newConnection) {
    io = new Manager(source, opts);
  } else {
    if (!cache[id]) {
      cache[id] = new Manager(source, opts);
    }
    io = cache[id];
  }
  if (parsed.query && !opts.query) {
    opts.query = parsed.queryKey;
  }
  return io.socket(parsed.path, opts);
}
Object.assign(lookup2, {
  Manager,
  Socket: Socket2,
  io: lookup2,
  connect: lookup2
});

// client/chat/services/realtime.ts
var socket = null;
var handlers = /* @__PURE__ */ new Map();
var lifecycle = null;
var retryTimer = null;
var retryDelay = 1e3;
var connectedOnce = false;
var ended = false;
var heardAt = 0;
var heard = () => {
  heardAt = Date.now();
};
var visible = () => document.visibilityState !== "hidden";
function on2(event, handler) {
  let set = handlers.get(event);
  if (!set) {
    set = /* @__PURE__ */ new Set();
    handlers.set(event, set);
    listen(event);
  }
  set.add(handler);
  return () => set.delete(handler);
}
function listen(event) {
  socket?.on(event, (payload) => dispatch(event, payload));
}
function dispatch(event, payload) {
  for (const h of [...handlers.get(event) ?? []]) {
    try {
      h(payload);
    } catch (e) {
      console.error(`handler for ${event} failed`, e);
    }
  }
}
function socketId() {
  return socket?.connected ? socket.id ?? null : null;
}
function isConnected() {
  return !!socket?.connected;
}
function silentForMs() {
  return heardAt ? Math.max(0, Date.now() - heardAt) : 0;
}
function send(event, ...args) {
  if (!socket?.connected) return;
  socket.emit(event, ...args);
}
var inflight = /* @__PURE__ */ new Set();
var OfflineError = class extends Error {
  constructor(message = "No connection") {
    super(message);
    this.name = "OfflineError";
  }
};
function request(event, payload, timeoutMs = 1e4) {
  return new Promise((resolve, reject) => {
    if (!socket?.connected) {
      reject(new OfflineError());
      return;
    }
    let done = false;
    const fail = (why) => {
      if (done) return;
      done = true;
      window.clearTimeout(timer3);
      inflight.delete(lost);
      reject(new OfflineError(why));
    };
    const lost = () => fail("Connection lost");
    const timer3 = window.setTimeout(
      () => fail("The server did not answer"),
      timeoutMs
    );
    inflight.add(lost);
    socket.emit(event, payload, (ack) => {
      if (done) return;
      done = true;
      window.clearTimeout(timer3);
      inflight.delete(lost);
      resolve(ack);
    });
  });
}
function scheduleRetry() {
  if (ended || retryTimer !== null) return;
  const delay = retryDelay;
  retryDelay = Math.min(retryDelay * 2, 3e4);
  retryTimer = window.setTimeout(
    () => {
      retryTimer = null;
      if (!ended && socket && !socket.connected) socket.connect();
    },
    delay + Math.random() * 500
  );
}
function connect(callbacks) {
  if (socket) return;
  lifecycle = callbacks;
  socket = lookup2({
    withCredentials: true,
    // sent with every (re)connection: hidden tabs and phones in a pocket
    // get push notifications and never mark messages as read
    auth: (cb) => cb({ visible: visible() })
  });
  for (const event of handlers.keys()) listen(event);
  socket.onAny(heard);
  socket.io.on("ping", heard);
  socket.on("connect", () => {
    heard();
    retryDelay = 1e3;
    if (retryTimer !== null) {
      window.clearTimeout(retryTimer);
      retryTimer = null;
    }
    const first = !connectedOnce;
    connectedOnce = true;
    connection.set({ status: "online", everConnected: true });
    lifecycle?.onConnect(first);
  });
  socket.on("disconnect", (reason) => {
    for (const lost of [...inflight]) lost();
    connection.set((s) => ({ ...s, status: "offline" }));
    lifecycle?.onDisconnect();
    if (reason === "io server disconnect" && !ended) scheduleRetry();
  });
  socket.on("connect_error", (err) => {
    connection.set((s) => ({
      ...s,
      status: s.everConnected ? "offline" : "connecting"
    }));
    const msg = String(err?.message || "");
    if (msg === "Unauthorized" || msg === "Session ended") {
      lifecycle?.onSessionEnded(false);
      return;
    }
    if (!socket?.active) scheduleRetry();
  });
  socket.on("session:ended", () => {
    ended = true;
    lifecycle?.onSessionEnded(true);
  });
  socket.io.on("reconnect_attempt", () => {
    connection.set((s) => ({
      ...s,
      status: s.everConnected ? "offline" : "connecting"
    }));
  });
  document.addEventListener("visibilitychange", () => {
    if (socket?.connected)
      socket.emit("presence:visibility", { visible: visible() });
    if (visible() && socket && !socket.connected && !ended)
      socket.connect();
  });
  window.addEventListener("online", () => {
    if (socket && !socket.connected && !ended) socket.connect();
  });
  window.addEventListener("pagehide", () => socket?.disconnect());
  window.addEventListener("pageshow", (e) => {
    if (e.persisted && socket && !socket.connected && !ended)
      socket.connect();
  });
}
function retrySoon() {
  scheduleRetry();
}
function disconnect() {
  ended = true;
  if (retryTimer !== null) window.clearTimeout(retryTimer);
  socket?.disconnect();
}

// client/chat/services/sync.ts
var PAGE_SIZE = 50;
var MAX_PAGE = 100;
var CONTACTS_PAGE = 200;
var contactsInFlight = null;
var contactsAgain = false;
async function fetchAllContacts() {
  const all = [];
  const seen = /* @__PURE__ */ new Set();
  for (let skip = 0; skip < 1e5; ) {
    const page = await contactsApi.page(CONTACTS_PAGE, skip);
    let added = 0;
    for (const row of page) {
      if (seen.has(row.id)) continue;
      seen.add(row.id);
      all.push(row);
      added++;
    }
    if (page.length < CONTACTS_PAGE || added === 0) break;
    skip += page.length;
  }
  return all;
}
function refreshContacts() {
  if (contactsInFlight) {
    contactsAgain = true;
    return contactsInFlight;
  }
  contactsInFlight = (async () => {
    try {
      do {
        contactsAgain = false;
        const askedAt = contactsRev();
        setAllRows(await fetchAllContacts(), askedAt);
      } while (contactsAgain);
    } finally {
      contactsInFlight = null;
    }
  })();
  return contactsInFlight;
}
async function loadContactsUntilDone() {
  let delay = 3e3;
  let told = false;
  for (; ; ) {
    try {
      await refreshContacts();
      return;
    } catch (e) {
      if (e instanceof ApiError && e.status === 401) throw e;
      contacts.set((s) => ({ ...s, failed: true }));
      if (!told) {
        told = true;
        showToast("Couldn't load your chats. Retrying\u2026", { icon: "error" });
      }
      await new Promise((r) => window.setTimeout(r, delay));
      delay = Math.min(delay * 2, 3e4);
    }
  }
}
var rowRefresh = /* @__PURE__ */ new Map();
function refreshRowSoon(convId, delay = 400) {
  if (rowRefresh.has(convId)) return;
  rowRefresh.set(
    convId,
    window.setTimeout(async () => {
      rowRefresh.delete(convId);
      const row = getRow(convId);
      if (!row) return;
      try {
        upsertRow(await contactsApi.get(row.id));
      } catch {
      }
    }, delay)
  );
}
function settleOutbox(messages) {
  const ids = /* @__PURE__ */ new Set();
  for (const m of messages) if (m.clientId) ids.add(m.clientId);
  if (ids.size === 0) return;
  outbox.set((s) => {
    let changed = false;
    const next = { ...s };
    for (const id of ids) {
      if (next[id]) {
        delete next[id];
        changed = true;
      }
    }
    return changed ? next : s;
  });
}
var loading = /* @__PURE__ */ new Map();
function loadNewest(convId) {
  const running = loading.get(convId);
  if (running) return running;
  const unread = getRow(convId)?.unreadCount ?? 0;
  const limit = Math.min(Math.max(unread + 20, PAGE_SIZE), MAX_PAGE);
  const p = (async () => {
    updateCache(convId, (c) => c.status === "ready" ? c : { ...c, status: "loading" });
    try {
      const page = await conversationsApi.page(convId, { limit });
      noteServerTime(page.cursor);
      settleOutbox(page.messages);
      updateCache(convId, (c) => withNewestPage(c, page));
    } catch (e) {
      updateCache(convId, (c) => c.status === "ready" ? c : { ...c, status: "error" });
      throw e;
    } finally {
      loading.delete(convId);
    }
  })();
  loading.set(convId, p);
  return p;
}
async function catchUp(convId) {
  const c = getCache(convId);
  if (!c || c.status !== "ready" || !c.cursor) return loadNewest(convId);
  const since = c.staleSince && c.staleSince > c.cursor ? c.staleSince : c.cursor;
  const startedStale = c.staleSince;
  try {
    const res = await conversationsApi.changes(convId, since);
    noteServerTime(res.cursor);
    if (res.reset) {
      updateExisting(convId, (x) => ({ ...x, messages: [], hasMore: false, status: "loading" }));
      return loadNewest(convId);
    }
    settleOutbox(res.messages);
    updateExisting(convId, (x) => {
      const next = applyWire(x, res.messages);
      return { ...next, cursor: res.cursor, staleSince: x.staleSince !== startedStale ? x.staleSince : null };
    });
  } catch (e) {
    if (e instanceof ApiError && (e.status === 403 || e.status === 404)) return;
    throw e;
  }
}
async function catchUpPersistently(convId) {
  for (let delay = 2e3; ; delay = Math.min(delay * 2, 3e4)) {
    try {
      await catchUp(convId);
      return;
    } catch {
      await new Promise((r) => window.setTimeout(r, delay));
      if (ui.get().openConvId !== convId || !isConnected() || !getCache(convId)?.staleSince) return;
    }
  }
}
async function prepareChat(convId) {
  updateCache(convId, (c2) => ({ ...c2, usedAt: Date.now() }));
  evictCaches(convId);
  const c = getCache(convId);
  const work = !c || c.status !== "ready" ? loadNewest(convId) : c.staleSince ? catchUp(convId) : Promise.resolve();
  if (!c?.pinned) void loadPinned(convId);
  await work;
}
async function loadOlder(convId) {
  const c = getCache(convId);
  if (!c || c.status !== "ready" || !c.hasMore || c.loadingOlder) return false;
  const first = c.messages[0];
  if (!first) return false;
  updateExisting(convId, (x) => ({ ...x, loadingOlder: true }));
  try {
    const page = await conversationsApi.page(convId, { limit: PAGE_SIZE, before: first.createdAt, beforeId: first.id });
    updateExisting(convId, (x) => withOlderPage(x, page));
    return true;
  } catch {
    updateExisting(convId, (x) => ({ ...x, loadingOlder: false }));
    return false;
  }
}
async function loadUntil(convId, messageId, maxPages = 20) {
  for (let i = 0; i <= maxPages; i++) {
    const c = getCache(convId);
    if (!c) return null;
    const found = c.messages.find((m) => m.id === messageId);
    if (found) return found;
    if (!c.hasMore) return null;
    if (ui.get().openConvId !== convId) return null;
    const ok = await loadOlder(convId);
    if (!ok) return null;
  }
  return null;
}
async function loadPinned(convId) {
  try {
    const { pinned } = await conversationsApi.pinned(convId);
    updateExisting(convId, (c) => ({ ...c, pinned: pinned.filter((p) => !c.gone[p.id]) }));
  } catch {
  }
}

// client/chat/services/typing.ts
var SHOW_MS = 6e3;
var SEND_EVERY_MS = 800;
var IDLE_MS = 2e3;
var hideTimers = /* @__PURE__ */ new Map();
function setTyping(convId, on3) {
  const t = hideTimers.get(convId);
  if (t !== void 0) window.clearTimeout(t);
  hideTimers.delete(convId);
  if (on3) {
    typing.set((s) => ({ ...s, [convId]: Date.now() + SHOW_MS }));
    hideTimers.set(
      convId,
      window.setTimeout(() => setTyping(convId, false), SHOW_MS)
    );
  } else {
    typing.set((s) => {
      if (!(convId in s)) return s;
      const next = { ...s };
      delete next[convId];
      return next;
    });
  }
}
function clearAllTyping() {
  for (const t of hideTimers.values()) window.clearTimeout(t);
  hideTimers.clear();
  typing.set({});
}
var lastSent = 0;
var sentFor = null;
var idleTimer = null;
function userTyped(convId) {
  const now = Date.now();
  if (sentFor !== convId || now - lastSent > SEND_EVERY_MS) {
    if (sentFor !== null && sentFor !== convId) send("typing:stop", { conversationId: sentFor });
    send("typing:start", { conversationId: convId });
    lastSent = now;
    sentFor = convId;
  }
  if (idleTimer !== null) window.clearTimeout(idleTimer);
  idleTimer = window.setTimeout(() => stopTyping(), IDLE_MS);
}
function stopTyping() {
  if (idleTimer !== null) window.clearTimeout(idleTimer);
  idleTimer = null;
  if (sentFor !== null) send("typing:stop", { conversationId: sentFor });
  sentFor = null;
  lastSent = 0;
}

// client/chat/services/navigation.ts
var focusSeq = 0;
function focusMessage(conversationId, messageId) {
  ui.set((s) => ({ ...s, focus: { conversationId, messageId, seq: ++focusSeq } }));
}
function leave(convId) {
  send("conversation:leave", { conversationId: convId });
  stopTyping();
  const c = getComposer(convId);
  if (c.action || c.mode !== "normal") patchComposer(convId, { action: null, mode: "normal", scheduledFor: null });
}
function openChat(convId, opts = {}) {
  if (!getRow(convId)) return;
  const prev = ui.get().openConvId;
  if (prev !== null && prev !== convId) leave(prev);
  closeMenu();
  cancelSelection();
  closeSearch();
  closeDialog();
  closePanel();
  ui.set((s) => ({ ...s, openConvId: convId }));
  pushLayer("chat", closeChatQuietly);
  if (prev !== convId) send("conversation:join", { conversationId: convId });
  clearNotices(convId);
  prepareChat(convId).catch(() => {
    if (ui.get().openConvId === convId) showToast("Couldn't load the messages. Check your connection.", { icon: "error" });
  });
  if (opts.focusMessageId) focusMessage(convId, opts.focusMessageId);
}
function closeChatQuietly() {
  const id = ui.get().openConvId;
  if (id === null) return;
  leave(id);
  closeMenu();
  cancelSelection();
  if (ui.get().panel === "profile") closePanel();
  ui.set((s) => ({ ...s, openConvId: null, focus: null }));
}
function closeChat() {
  closeChatQuietly();
  popLayer("chat");
}
function forgetChat(convId) {
  if (ui.get().openConvId === convId) closeChat();
  dropCache(convId);
  dropComposer(convId);
  clearNotices(convId);
}
function openPanel(panel) {
  closeMenu();
  ui.set((s) => ({ ...s, panel }));
  pushLayer("panel", () => ui.set((s) => ({ ...s, panel: null })));
}
function closePanel() {
  if (ui.get().panel === null) return;
  ui.set((s) => ({ ...s, panel: null }));
  popLayer("panel");
}
function openDialog(dialog) {
  ui.set((s) => ({ ...s, dialog }));
  pushLayer("dialog", () => ui.set((s) => ({ ...s, dialog: null, forwarding: s.dialog === "forward" ? null : s.forwarding })));
}
function closeDialog() {
  if (ui.get().dialog === null) return;
  ui.set((s) => ({ ...s, dialog: null, forwarding: s.dialog === "forward" ? null : s.forwarding }));
  popLayer("dialog");
}
function openAllContacts() {
  ui.set((s) => ({ ...s, allContactsOpen: true }));
  pushLayer("allContacts", () => ui.set((s) => ({ ...s, allContactsOpen: false })));
}
function closeAllContacts() {
  if (!ui.get().allContactsOpen) return;
  ui.set((s) => ({ ...s, allContactsOpen: false }));
  popLayer("allContacts");
}
function openSearch() {
  if (ui.get().search.open) return;
  ui.set((s) => ({ ...s, search: { ...s.search, open: true } }));
  pushLayer("search", () => ui.set((s) => ({ ...s, search: { open: false, query: "" } })));
}
function setSearchQuery(query) {
  ui.set((s) => ({ ...s, search: { open: true, query } }));
}
function closeSearch() {
  const { search } = ui.get();
  if (!search.open && !search.query) return;
  ui.set((s) => ({ ...s, search: { open: false, query: "" } }));
  popLayer("search");
}
function openMenu(conversationId, messageId, x, y) {
  ui.set((s) => ({ ...s, menu: { conversationId, messageId, x, y } }));
  pushLayer("menu", () => ui.set((s) => ({ ...s, menu: null })));
}
function closeMenu() {
  if (!ui.get().menu) return;
  ui.set((s) => ({ ...s, menu: null }));
  popLayer("menu");
}
function startSelection(conversationId, messageId) {
  ui.set((s) => ({ ...s, selection: { conversationId, ids: [messageId] } }));
  pushLayer("selection", () => ui.set((s) => ({ ...s, selection: null })));
}
function toggleSelected(messageId) {
  ui.set((s) => {
    if (!s.selection) return s;
    const has = s.selection.ids.includes(messageId);
    const ids = has ? s.selection.ids.filter((id) => id !== messageId) : [...s.selection.ids, messageId];
    return { ...s, selection: { ...s.selection, ids } };
  });
  if (ui.get().selection?.ids.length === 0) cancelSelection();
}
function cancelSelection() {
  if (!ui.get().selection) return;
  ui.set((s) => ({ ...s, selection: null }));
  popLayer("selection");
}

// client/chat/services/outboxStore.ts
var key = (userId) => `rivo.outbox.${userId}`;
function isPending(v) {
  if (!v || typeof v !== "object") return false;
  const p = v;
  return typeof p.clientId === "string" && typeof p.conversationId === "number" && typeof p.text === "string" && typeof p.createdAt === "string";
}
function restoreOutbox(userId) {
  const raw = read(key(userId));
  if (!raw) return;
  try {
    const list = JSON.parse(raw);
    if (!Array.isArray(list)) return;
    const byId = {};
    for (const item of list) {
      if (!isPending(item)) continue;
      byId[item.clientId] = {
        clientId: item.clientId,
        conversationId: item.conversationId,
        text: item.text,
        createdAt: item.createdAt,
        replyTo: item.replyTo ?? null,
        forwardedFrom: item.forwardedFrom ?? null,
        forwardOf: typeof item.forwardOf === "number" ? item.forwardOf : null,
        isOneTime: !!item.isOneTime,
        isTimeCapsule: !!item.isTimeCapsule,
        scheduledFor: item.scheduledFor ?? null,
        // a refused message stays failed; one cut off by the reload is tried again
        status: item.status === "failed" && item.error ? "failed" : "queued",
        error: item.status === "failed" ? item.error ?? null : null,
        batchId: null
      };
    }
    outbox.set((s) => ({ ...byId, ...s }));
  } catch {
    write(key(userId), null);
  }
}
var timer = null;
function storedList(userId) {
  try {
    const list = JSON.parse(read(key(userId)) ?? "[]");
    return Array.isArray(list) ? list.filter(isPending) : [];
  } catch {
    return [];
  }
}
function persistOutbox(userId) {
  const settledHere = /* @__PURE__ */ new Set();
  let known = new Set(Object.keys(outbox.get()));
  const save = () => {
    timer = null;
    const mine = outbox.get();
    const theirs = storedList(userId).filter((p) => !mine[p.clientId] && !settledHere.has(p.clientId));
    const list = [...theirs, ...Object.values(mine)];
    write(key(userId), list.length ? JSON.stringify(list) : null);
  };
  const unsubscribe = outbox.subscribe(() => {
    const now = outbox.get();
    for (const id of known) if (!now[id]) settledHere.add(id);
    known = new Set(Object.keys(now));
    if (settledHere.size > 1e3) for (const id of [...settledHere].slice(0, 500)) settledHere.delete(id);
    if (timer === null) timer = window.setTimeout(save, 300);
  });
  const onHide = () => {
    if (timer !== null) {
      window.clearTimeout(timer);
      save();
    }
  };
  window.addEventListener("pagehide", onHide);
  return () => {
    unsubscribe();
    window.removeEventListener("pagehide", onHide);
  };
}
function clearPersistedOutbox(userId) {
  if (timer !== null) window.clearTimeout(timer);
  timer = null;
  write(key(userId), null);
  outbox.set({});
}

// client/chat/services/push.ts
var pushState = createStore({ state: "off" });
function supported() {
  return "serviceWorker" in navigator && "PushManager" in window && "Notification" in window && window.isSecureContext;
}
function keyBytes(base64) {
  const padded = (base64 + "=".repeat((4 - base64.length % 4) % 4)).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(padded);
  const out = new Uint8Array(new ArrayBuffer(raw.length));
  for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
  return out;
}
function sameKey(sub, key2) {
  const current = sub.options?.applicationServerKey;
  if (!current) return true;
  const a = new Uint8Array(current);
  return a.length === key2.length && a.every((v, i) => v === key2[i]);
}
var registration = null;
function registerServiceWorker() {
  if (!("serviceWorker" in navigator) || !window.isSecureContext) return Promise.resolve(null);
  registration ?? (registration = navigator.serviceWorker.register("/service-worker.js", { scope: "/" }).catch((e) => {
    console.warn("service worker registration failed", e);
    return null;
  }));
  return registration;
}
async function refreshState() {
  if (!supported()) return pushState.set({ state: "unsupported" });
  if (Notification.permission === "denied") return pushState.set({ state: "blocked" });
  const reg = await registerServiceWorker();
  const sub = reg ? await reg.pushManager.getSubscription().catch(() => null) : null;
  pushState.set({ state: sub && Notification.permission === "granted" ? "on" : "off" });
}
async function enablePush(ask) {
  if (!supported()) {
    pushState.set({ state: "unsupported" });
    return "unsupported";
  }
  if (Notification.permission === "denied") {
    pushState.set({ state: "blocked" });
    return "blocked";
  }
  if (Notification.permission === "default") {
    if (!ask) {
      pushState.set({ state: "off" });
      return "off";
    }
    const answer = await Notification.requestPermission().catch(() => "default");
    if (answer !== "granted") {
      const s = answer === "denied" ? "blocked" : "off";
      pushState.set({ state: s });
      return s;
    }
  }
  pushState.set({ state: "working" });
  try {
    const reg = await registerServiceWorker();
    if (!reg) throw new Error("no service worker");
    await navigator.serviceWorker.ready;
    const { publicKey } = await pushApi.publicKey();
    const key2 = keyBytes(publicKey);
    let sub = await reg.pushManager.getSubscription();
    if (sub && !sameKey(sub, key2)) {
      await sub.unsubscribe().catch(() => false);
      sub = null;
    }
    sub ?? (sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: key2 }));
    await pushApi.subscribe(sub.toJSON());
    pushState.set({ state: "on" });
    return "on";
  } catch (e) {
    console.warn("push subscription failed", e);
    await refreshState().catch(() => pushState.set({ state: "off" }));
    return pushState.get().state;
  }
}
async function currentEndpoint() {
  if (!supported()) return null;
  try {
    const reg = await navigator.serviceWorker.getRegistration();
    const sub = await reg?.pushManager.getSubscription();
    return sub?.endpoint ?? null;
  } catch {
    return null;
  }
}
async function disablePush(notifyServer = true) {
  if (!supported()) return;
  try {
    const reg = await navigator.serviceWorker.getRegistration();
    const sub = await reg?.pushManager.getSubscription();
    if (sub) {
      if (notifyServer) await pushApi.unsubscribe(sub.endpoint).catch(() => void 0);
      await sub.unsubscribe().catch(() => false);
    }
  } finally {
    await refreshState().catch(() => void 0);
  }
}
function withTimeout(p, ms, fallback) {
  return Promise.race([p, new Promise((r) => window.setTimeout(() => r(fallback), ms))]);
}
function initPush() {
  void refreshState().then(() => {
    if (supported() && Notification.permission === "granted") void enablePush(false);
  });
}

// client/chat/services/session.ts
var SIGN_IN_PAGE = "/auth/";
function isMe(v) {
  return !!v && typeof v === "object" && typeof v.id === "number" && typeof v.username === "string";
}
function cachedMe() {
  const me = readJson(keys.user, isMe);
  if (!me) return null;
  return {
    id: me.id,
    name: me.name || "",
    username: me.username,
    email: me.email || "",
    bio: me.bio || "",
    profilePics: Array.isArray(me.profilePics) ? me.profilePics : [],
    privacyOnline: me.privacyOnline || "everyone",
    privacyEmail: me.privacyEmail || "everyone",
    privacyProfile: me.privacyProfile || "everyone"
  };
}
function setMe(me) {
  session.set({ me });
  writeJson(keys.user, {
    id: me.id,
    name: me.name,
    username: me.username,
    // (the email is not kept on the device)
    bio: me.bio,
    profilePics: me.profilePics,
    privacyOnline: me.privacyOnline,
    privacyEmail: me.privacyEmail,
    privacyProfile: me.privacyProfile
  });
}
function patchMe(patch) {
  const me = session.get().me;
  if (me) setMe({ ...me, ...patch });
}
function meId() {
  return session.get().me?.id ?? null;
}
function leave2() {
  const uid = meId();
  write(keys.user, null);
  if (uid !== null) clearPersistedOutbox(uid);
  window.location.replace(SIGN_IN_PAGE);
}
var ending = false;
async function sessionEnded(certain) {
  if (ending) return;
  if (!certain) {
    try {
      await usersApi.me();
      retrySoon();
      return;
    } catch (e) {
      if (!(e instanceof ApiError) || e.status !== 401) {
        retrySoon();
        return;
      }
    }
  }
  if (ending) return;
  ending = true;
  disconnect();
  await withTimeout(disablePush(false), 2e3, void 0);
  leave2();
}
var loggingOut = false;
async function logout() {
  if (loggingOut) return;
  loggingOut = true;
  try {
    const endpoint = await withTimeout(currentEndpoint(), 1500, null);
    await authApi.logout(endpoint);
  } catch (e) {
    loggingOut = false;
    throw e;
  }
  ending = true;
  disconnect();
  await withTimeout(disablePush(false), 2e3, void 0);
  leave2();
}
async function accountDeleted() {
  ending = true;
  disconnect();
  await withTimeout(disablePush(false), 2e3, void 0);
  leave2();
}

// client/chat/services/events.ts
var pageVisible = () => document.visibilityState === "visible";
var isViewing = (convId) => ui.get().openConvId === convId && pageVisible();
function previewWith(convId, m) {
  patchRow(convId, (r) => {
    const last = r.lastMessage;
    const newer = !last || last.id === m.id || m.createdAt > last.createdAt || m.createdAt === last.createdAt && m.id > last.id;
    if (!newer) return {};
    const at = r.conversation?.lastMessageAt;
    return {
      lastMessage: toPreview(m),
      conversation: r.conversation ? { ...r.conversation, lastMessageAt: !at || m.createdAt > at ? m.createdAt : at } : r.conversation
    };
  });
}
function previewAfterRemoval(convId, removed) {
  const row = getRow(convId);
  if (!row?.lastMessage || !removed.has(row.lastMessage.id)) return;
  const c = getCache(convId);
  if (c && c.status === "ready" && !c.staleSince) {
    const last = c.messages[c.messages.length - 1];
    if (last) {
      patchRow(convId, { lastMessage: toPreview(last) });
      return;
    }
    if (!c.hasMore) {
      patchRow(convId, { lastMessage: null });
      return;
    }
  }
  refreshRowSoon(convId);
}
function forgetMessages(convId, ids) {
  ui.set((s) => {
    let next = s;
    if (s.menu && s.menu.conversationId === convId && ids.has(s.menu.messageId)) next = { ...next, menu: null };
    if (s.selection && s.selection.conversationId === convId && s.selection.ids.some((id) => ids.has(id))) {
      const left = s.selection.ids.filter((id) => !ids.has(id));
      next = { ...next, selection: { ...s.selection, ids: left } };
    }
    return next;
  });
  const action = getComposer(convId).action;
  if (action && (action.kind === "reply" || action.kind === "edit") && ids.has(action.message.id)) resetComposer(convId);
  undoing.set((s) => {
    if (!Object.keys(s.messages).some((k) => ids.has(Number(k)))) return s;
    const messages = { ...s.messages };
    for (const id of ids) delete messages[id];
    return { ...s, messages };
  });
}
function removeMessages(convId, ids) {
  const set = new Set(ids);
  const drop = () => {
    updateExisting(convId, (c) => removeFromCache(c, ids));
    vanishing.set((s) => {
      if (!ids.some((id) => s[id])) return s;
      const next = { ...s };
      for (const id of ids) delete next[id];
      return next;
    });
    forgetMessages(convId, set);
    previewAfterRemoval(convId, set);
  };
  const shown = ui.get().openConvId === convId && getCache(convId)?.messages.some((m) => set.has(m.id));
  if (!shown || !pageVisible()) return drop();
  vanishing.set((s) => {
    const next = { ...s };
    for (const id of ids) next[id] = true;
    return next;
  });
  window.setTimeout(drop, 300);
}
function patchIfNewer(convId, messageId, updatedAt, patch) {
  updateExisting(convId, (c) => {
    const at = c.messages.findIndex((m) => m.id === messageId);
    if (at < 0) return c;
    const cur = c.messages[at];
    if (updatedAt && cur.updatedAt > updatedAt) return c;
    const messages = [...c.messages];
    messages[at] = { ...cur, ...patch, ...updatedAt ? { updatedAt } : {} };
    return { ...c, messages };
  });
}
var unknownRefresh = null;
function refreshForUnknownChat() {
  if (unknownRefresh !== null) return;
  unknownRefresh = window.setTimeout(() => {
    unknownRefresh = null;
    refreshContacts().catch(() => void 0);
  }, 300);
}
function onNew(m) {
  const convId = m.conversationId;
  const row = getRow(convId);
  if (!row) {
    refreshForUnknownChat();
    return;
  }
  const me = meId();
  const mine = m.senderId === me;
  const counted = !!row.lastMessage && row.lastMessage.id >= m.id;
  updateExisting(convId, (c) => applyWire(c, [m]));
  if (mine) settleOutbox([m]);
  else setTyping(convId, false);
  previewWith(convId, m);
  if (!mine && !counted && !isViewing(convId)) patchRow(convId, (r) => ({ unreadCount: r.unreadCount + 1 }));
  if (!mine && pageVisible() && ui.get().openConvId !== convId && !row.isMuted && !row.isSaved) {
    notify({ conversationId: convId, title: displayName(row), text: previewText(m, me), messageId: m.id });
  }
}
function onEdited(d) {
  patchIfNewer(d.conversationId, d.messageId, d.updatedAt, { text: d.text, isEdited: true });
  updateExisting(
    d.conversationId,
    (c) => c.pinned?.some((p) => p.id === d.messageId) ? { ...c, pinned: c.pinned.map((p) => p.id === d.messageId ? { ...p, text: d.text } : p) } : c
  );
  patchRow(
    d.conversationId,
    (r) => r.lastMessage?.id === d.messageId ? { lastMessage: { ...r.lastMessage, text: d.text, isEdited: true } } : {}
  );
}
function onDeleted(d) {
  const row = getRow(d.conversationId);
  const known = getCache(d.conversationId)?.messages.find((m) => m.id === d.messageId);
  const fromOther = d.senderId !== meId();
  const wasUnseen = known ? !known.isSeen : !d.isSeen;
  if (row && fromOther && wasUnseen && row.unreadCount > 0) patchRow(d.conversationId, (r) => ({ unreadCount: Math.max(0, r.unreadCount - 1) }));
  removeMessages(d.conversationId, [d.messageId]);
}
function onBulkDeleted(d) {
  const convId = d.conversationId;
  const ids = (getCache(convId)?.messages ?? []).filter((m) => m.id <= d.upToId).map((m) => m.id);
  removeMessages(convId, ids);
  updateExisting(convId, (c) => ({ ...c, hasMore: false, pinned: c.pinned ? c.pinned.filter((p) => p.id > d.upToId) : c.pinned }));
  const last = getRow(convId)?.lastMessage;
  if (!last || last.id <= d.upToId) patchRow(convId, { lastMessage: null, unreadCount: 0 });
  else refreshRowSoon(convId);
  undoing.set((s) => {
    if (!s.clearedChats[d.conversationId]) return s;
    const clearedChats = { ...s.clearedChats };
    delete clearedChats[d.conversationId];
    return { ...s, clearedChats };
  });
}
function onOneTimeDeleted(d) {
  removeMessages(d.conversationId, d.messageIds);
}
function onPinned(d) {
  patchIfNewer(d.conversationId, d.messageId, d.updatedAt, { isPinned: d.isPinned });
  const c = getCache(d.conversationId);
  if (!c?.pinned) return;
  if (!d.isPinned) {
    updateExisting(d.conversationId, (x) => x.pinned ? { ...x, pinned: x.pinned.filter((p) => p.id !== d.messageId) } : x);
    return;
  }
  const m = c.messages.find((x) => x.id === d.messageId);
  if (m) updateExisting(d.conversationId, (x) => x.pinned ? { ...x, pinned: insertPinned(x.pinned, m) } : x);
  else void loadPinned(d.conversationId);
}
function onReaction(d) {
  patchIfNewer(d.conversationId, d.messageId, d.updatedAt, { reactions: d.reactions });
  const me = meId();
  if (d.action !== "added" && d.action !== "changed" || d.actorId === me) return;
  const row = getRow(d.conversationId);
  const m = getCache(d.conversationId)?.messages.find((x) => x.id === d.messageId);
  if (!row || row.isMuted || !m || m.senderId !== me) return;
  if (ui.get().openConvId === d.conversationId || !pageVisible()) return;
  notify({
    conversationId: d.conversationId,
    title: displayName(row),
    text: `${displayName(row) || "Someone"} reacted ${d.emoji} to your message`,
    messageId: d.messageId
  });
}
function onSeen(d) {
  const me = meId();
  const ids = new Set(d.messageIds);
  const byMe = d.seenBy === me;
  updateExisting(d.conversationId, (c) => {
    if (!c.messages.some((m) => ids.has(m.id) && !m.isSeen)) return c;
    return { ...c, messages: c.messages.map((m) => ids.has(m.id) && !m.isSeen ? { ...m, isSeen: true } : m) };
  });
  patchRow(d.conversationId, (r) => ({
    lastMessage: r.lastMessage && ids.has(r.lastMessage.id) ? { ...r.lastMessage, isSeen: true } : r.lastMessage,
    // read on another device of this user
    unreadCount: byMe ? Math.max(0, r.unreadCount - d.messageIds.length) : r.unreadCount
  }));
}
function onCapsuleOpened(d) {
  const m = d.message;
  if (!m) return;
  updateExisting(d.conversationId, (c) => applyWire(c, [m]));
  if (!m.isDeleted) patchRow(d.conversationId, (r) => r.lastMessage?.id === m.id ? { lastMessage: toPreview(m) } : {});
}
function onUserUpdated(u) {
  if (u.id === meId()) {
    patchMe({ name: u.name, username: u.username, bio: u.bio, profilePics: u.profilePics, ...u.email ? { email: u.email } : {} });
    return;
  }
  patchPerson(u.id, {
    name: u.name,
    username: u.username,
    bio: u.bio,
    profilePics: u.profilePics,
    email: u.email,
    isDeleted: u.isDeleted,
    ...u.isDeleted ? { isOnline: false, lastSeen: null } : {}
  });
}
function onContactUpsert(row) {
  upsertRow(row);
}
function onContactRemoved(d) {
  forgetChat(d.conversationId);
  removeRow(d.conversationId);
}
function installEventHandlers() {
  on2("message:new", onNew);
  on2("message:edited", onEdited);
  on2("message:deleted", onDeleted);
  on2("messages:bulk-deleted", onBulkDeleted);
  on2("message:onetime-deleted", onOneTimeDeleted);
  on2("message:pinned", onPinned);
  on2("reaction:updated", onReaction);
  on2("message:seen", onSeen);
  on2("message:capsule:opened", onCapsuleOpened);
  on2("typing:start", (d) => setTyping(d.conversationId, true));
  on2("typing:stop", (d) => setTyping(d.conversationId, false));
  on2("user:online", (d) => patchPerson(d.userId, { isOnline: true }));
  on2("user:offline", (d) => patchPerson(d.userId, { isOnline: false, lastSeen: d.lastSeen }));
  on2("user:updated", onUserUpdated);
  on2("contact:upsert", onContactUpsert);
  on2("contact:removed", onContactRemoved);
}

// client/shared/lib/ids.ts
var ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";
function randomId(length = 22) {
  const bytes = new Uint8Array(length);
  crypto.getRandomValues(bytes);
  let out = "";
  for (const b of bytes) out += ALPHABET[b & 63];
  return out;
}

// client/chat/services/outbox.ts
var MAX_LENGTH = 1500;
var TRANSIENT = /* @__PURE__ */ new Set(["Server error", "Rate limit exceeded"]);
function setPending(clientId, patch) {
  outbox.set((s) => s[clientId] ? { ...s, [clientId]: { ...s[clientId], ...patch } } : s);
}
function removePending(clientIds) {
  outbox.set((s) => {
    if (!clientIds.some((id) => s[id])) return s;
    const next = { ...s };
    for (const id of clientIds) delete next[id];
    return next;
  });
}
function delivered(m, clientId = m.clientId ?? null) {
  if (clientId) removePending([clientId]);
  updateExisting(m.conversationId, (c) => applyWire(c, [m]));
  if (m.isDeleted) return;
  patchRow(m.conversationId, (r) => {
    const last = r.lastMessage;
    if (last && last.id !== m.id && (last.createdAt > m.createdAt || last.createdAt === m.createdAt && last.id > m.id)) return {};
    return {
      lastMessage: toPreview(m),
      conversation: r.conversation ? { ...r.conversation, lastMessageAt: m.createdAt } : r.conversation
    };
  });
}
function payloadOf(p) {
  const out = { conversationId: p.conversationId, text: p.text, clientId: p.clientId };
  if (p.replyTo) out.replyToId = p.replyTo.id;
  if (p.forwardOf !== null) out.forwardOf = p.forwardOf;
  if (p.isOneTime) out.isOneTime = true;
  if (p.isTimeCapsule && p.scheduledFor) {
    out.isTimeCapsule = true;
    out.scheduledFor = p.scheduledFor;
  }
  return out;
}
var sleep = (ms) => new Promise((r) => window.setTimeout(r, ms));
async function sendOne(p) {
  setPending(p.clientId, { status: "sending" });
  try {
    const ack = await request("message:send", payloadOf(p), 1e4);
    if (ack.error === void 0) {
      delivered(ack.message, p.clientId);
      return "ok";
    }
    if (ack.error === "Rate limit exceeded") {
      setPending(p.clientId, { status: "queued" });
      return "slow";
    }
    setPending(p.clientId, { status: "failed", error: TRANSIENT.has(ack.error) ? null : ack.error });
    return "ok";
  } catch {
    if (outbox.get()[p.clientId]?.status !== "sending") return isConnected() ? "ok" : "stop";
    setPending(p.clientId, isConnected() ? { status: "failed", error: null } : { status: "queued" });
    return isConnected() ? "ok" : "stop";
  }
}
async function sendBatch(items) {
  const first = items[0];
  for (const p of items) setPending(p.clientId, { status: "sending" });
  try {
    const ack = await request(
      "messages:forward",
      {
        conversationId: first.conversationId,
        items: items.filter((p) => p.forwardOf !== null).map((p) => ({ forwardOf: p.forwardOf, clientId: p.clientId }))
      },
      15e3
    );
    const sent = "messages" in ack && Array.isArray(ack.messages) ? ack.messages : [];
    for (const m of sent) delivered(m);
    const done = new Set(sent.map((m) => m.clientId));
    const rest = items.filter((p) => !done.has(p.clientId));
    if (ack.error === "Rate limit exceeded" && sent.length === 0) {
      for (const p of rest) setPending(p.clientId, { status: "queued" });
      return "slow";
    }
    for (const p of rest) {
      setPending(p.clientId, { status: "failed", error: ack.error && !TRANSIENT.has(ack.error) ? ack.error : null, batchId: null });
    }
    return "ok";
  } catch {
    const box = outbox.get();
    for (const p of items) {
      if (box[p.clientId]?.status !== "sending") continue;
      setPending(p.clientId, isConnected() ? { status: "failed", error: null, batchId: null } : { status: "queued" });
    }
    return isConnected() ? "ok" : "stop";
  }
}
var pumping = false;
var gate = Promise.resolve();
function holdSends(until) {
  gate = until;
}
async function pump2() {
  if (pumping) return;
  pumping = true;
  try {
    await gate;
    while (isConnected()) {
      const queued = Object.values(outbox.get()).filter((p) => p.status === "queued").sort((a, b) => a.createdAt < b.createdAt ? -1 : a.createdAt > b.createdAt ? 1 : 0);
      const next = queued[0];
      if (!next) break;
      const result = next.batchId ? await sendBatch(queued.filter((p) => p.batchId === next.batchId)) : await sendOne(next);
      if (result === "stop") break;
      if (result === "slow") await sleep(3e3);
    }
  } finally {
    pumping = false;
  }
  if (isConnected() && Object.values(outbox.get()).some((p) => p.status === "queued")) void pump2();
}
function requeueAfterReconnect() {
  outbox.set((s) => {
    let changed = false;
    const next = { ...s };
    for (const [id, p] of Object.entries(s)) {
      if (p.status === "sending" || p.status === "failed" && p.error === null) {
        next[id] = { ...p, status: "queued" };
        changed = true;
      }
    }
    return changed ? next : s;
  });
  void pump2();
}
function unarchive(convId) {
  const row = getRow(convId);
  if (!row?.isArchived) return;
  patchRow(convId, { isArchived: false });
  contactsApi.update(row.id, { isArchived: false }).catch(() => patchRow(convId, { isArchived: true }));
}
function stamp(offsetMs2 = 0) {
  return serverNow(offsetMs2);
}
function sendText(convId, rawText, opts = {}) {
  const text = rawText.trim();
  if (!text) return false;
  if (text.length > MAX_LENGTH) {
    showToast(`Messages can be at most ${MAX_LENGTH} characters.`, { icon: "error" });
    return false;
  }
  const me = session.get().me;
  const row = getRow(convId);
  let replyTo = null;
  if (opts.replyTo && opts.replyTo.text !== null) {
    const q = opts.replyTo;
    replyTo = {
      id: q.id,
      senderId: q.senderId,
      text: q.text ?? "",
      name: q.senderId === me?.id ? me?.name ?? "" : realName(row)
    };
  }
  const p = {
    clientId: randomId(),
    conversationId: convId,
    text,
    createdAt: stamp(),
    replyTo,
    forwardedFrom: null,
    forwardOf: null,
    isOneTime: !!opts.isOneTime,
    isTimeCapsule: !!opts.scheduledFor,
    scheduledFor: opts.scheduledFor ?? null,
    status: "queued",
    error: null,
    batchId: null
  };
  outbox.set((s) => ({ ...s, [p.clientId]: p }));
  stopTyping();
  unarchive(convId);
  void pump2();
  return true;
}
function forwardTo(convId, items, extraText = "") {
  if (items.length === 0) return;
  const batchId = items.length > 1 ? randomId(10) : null;
  const added = {};
  items.forEach((item, i) => {
    const p = {
      clientId: randomId(),
      conversationId: convId,
      text: item.text,
      createdAt: stamp(i),
      replyTo: null,
      forwardedFrom: item.forwardedFrom,
      forwardOf: item.sourceId,
      isOneTime: false,
      isTimeCapsule: false,
      scheduledFor: null,
      status: "queued",
      error: null,
      batchId
    };
    added[p.clientId] = p;
  });
  outbox.set((s) => ({ ...s, ...added }));
  unarchive(convId);
  if (extraText.trim()) {
    const p = {
      clientId: randomId(),
      conversationId: convId,
      text: extraText.trim().slice(0, MAX_LENGTH),
      createdAt: stamp(items.length),
      replyTo: null,
      forwardedFrom: null,
      forwardOf: null,
      isOneTime: false,
      isTimeCapsule: false,
      scheduledFor: null,
      status: "queued",
      error: null,
      batchId: null
    };
    outbox.set((s) => ({ ...s, [p.clientId]: p }));
  }
  stopTyping();
  void pump2();
}
function retry(clientId) {
  setPending(clientId, { status: "queued", error: null, batchId: null });
  void pump2();
}
function discard(clientId) {
  const p = outbox.get()[clientId];
  if (!p || p.status === "sending") return;
  removePending([clientId]);
}

// client/chat/services/undo.ts
var UNDO_MS = 3e3;
var pending = /* @__PURE__ */ new Map();
function withUndo(opts) {
  if (pending.has(opts.key)) return;
  opts.apply();
  const entry = {
    commit: async () => {
      try {
        await opts.commit();
      } catch {
        opts.revert();
        showToast(opts.failedText ?? "Couldn't complete that. Try again.", { icon: "error" });
      }
    },
    revert: opts.revert,
    commitOnExit: opts.commitOnExit,
    timer: window.setTimeout(() => {
      pending.delete(opts.key);
      void entry.commit();
    }, UNDO_MS)
  };
  pending.set(opts.key, entry);
  showToast(opts.text, {
    icon: opts.icon,
    action: {
      label: "Undo",
      run: () => {
        const p = pending.get(opts.key);
        if (!p) return;
        window.clearTimeout(p.timer);
        pending.delete(opts.key);
        opts.revert();
      }
    }
  });
}
function cancelUndo(key2) {
  const p = pending.get(key2);
  if (!p) return false;
  window.clearTimeout(p.timer);
  pending.delete(key2);
  p.revert();
  hideToast();
  return true;
}
function flushOnExit() {
  for (const [key2, p] of pending) {
    window.clearTimeout(p.timer);
    pending.delete(key2);
    try {
      p.commitOnExit();
    } catch {
    }
  }
}
var installed = false;
function installExitFlush() {
  if (installed) return;
  installed = true;
  window.addEventListener("pagehide", flushOnExit);
}

// client/shared/lib/hooks.ts
var import_react2 = __toESM(require_react(), 1);
function useEvent(fn) {
  const ref = (0, import_react2.useRef)(fn);
  (0, import_react2.useLayoutEffect)(() => {
    ref.current = fn;
  });
  return (0, import_react2.useCallback)((...args) => ref.current(...args), []);
}
function useMediaQuery(query) {
  const subscribe = (0, import_react2.useCallback)(
    (cb) => {
      const mql = window.matchMedia(query);
      mql.addEventListener("change", cb);
      return () => mql.removeEventListener("change", cb);
    },
    [query]
  );
  return (0, import_react2.useSyncExternalStore)(
    subscribe,
    () => window.matchMedia(query).matches,
    () => false
  );
}
var PHONE_QUERY = "(max-width: 700px)";
var useIsPhone = () => useMediaQuery(PHONE_QUERY);
function prefersReducedMotion() {
  return typeof window !== "undefined" && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}
function usePresence(open2, ms = 300) {
  const [mounted, setMounted] = (0, import_react2.useState)(open2);
  const [state, setState] = (0, import_react2.useState)(open2 ? "shown" : "exit");
  const first = (0, import_react2.useRef)(true);
  (0, import_react2.useEffect)(() => {
    const instant = prefersReducedMotion() ? 0 : ms;
    if (first.current) {
      first.current = false;
      if (open2) return void 0;
    }
    if (open2) {
      setMounted(true);
      setState("enter");
      const t2 = window.setTimeout(() => setState("shown"), instant);
      return () => window.clearTimeout(t2);
    }
    setState("exit");
    const t = window.setTimeout(() => setMounted(false), instant);
    return () => window.clearTimeout(t);
  }, [open2, ms]);
  return { mounted: mounted || open2, state: open2 && state === "exit" ? "enter" : state };
}
function visibleNow() {
  return typeof document === "undefined" || document.visibilityState === "visible";
}
function usePageVisible() {
  return (0, import_react2.useSyncExternalStore)(
    (cb) => {
      document.addEventListener("visibilitychange", cb);
      return () => document.removeEventListener("visibilitychange", cb);
    },
    visibleNow,
    () => true
  );
}
function useNow(ms = 3e4) {
  const [now, setNow] = (0, import_react2.useState)(() => Date.now());
  (0, import_react2.useEffect)(() => {
    const t = window.setInterval(() => setNow(Date.now()), ms);
    return () => window.clearInterval(t);
  }, [ms]);
  return now;
}
function useOutsidePointer(refs, fn, active = true) {
  const handler = useEvent(fn);
  (0, import_react2.useEffect)(() => {
    if (!active) return void 0;
    const onDown = (e) => {
      const t = e.target;
      if (!t) return;
      if (refs.some((r) => r.current?.contains(t))) return;
      handler();
    };
    document.addEventListener("pointerdown", onDown, true);
    return () => document.removeEventListener("pointerdown", onDown, true);
  }, [active, handler]);
}
function useEscape(fn, active = true) {
  const handler = useEvent(fn);
  (0, import_react2.useEffect)(() => {
    if (!active) return void 0;
    const onKey = (e) => {
      if (e.key === "Escape" && !e.defaultPrevented) handler();
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, [active, handler]);
}
function subscribeTheme(cb) {
  const mo = new MutationObserver(cb);
  mo.observe(document.documentElement, { attributes: true, attributeFilter: ["class"] });
  return () => mo.disconnect();
}
function useIsDark() {
  return (0, import_react2.useSyncExternalStore)(
    subscribeTheme,
    () => document.documentElement.classList.contains("dark-mode"),
    () => false
  );
}
function useClickSuppressor(ms = 600) {
  const until = (0, import_react2.useRef)(0);
  const [api] = (0, import_react2.useState)(() => ({
    arm: () => {
      until.current = performance.now() + ms;
    },
    consume: () => {
      if (performance.now() >= until.current) return false;
      until.current = 0;
      return true;
    },
    armed: () => performance.now() < until.current
  }));
  return api;
}

// client/chat/ui/chat/ForwardDialog.tsx
var import_react5 = __toESM(require_react(), 1);

// client/shared/ui/Avatar.tsx
var import_react3 = __toESM(require_react(), 1);

// client/shared/lib/text.ts
var LINK_RE = /^(?:https?:\/\/[^\s]+|www\.[a-z0-9-]+(?:\.[a-z0-9-]+)*\.[a-z]{2,}(?:[/?#][^\s]*)?)$/i;
var TRAILING_RE = /[.,!?;:'"»”’)\]}>]+$/;
var LEADING_RE = /^[(\[{<«“‘"']+/;
var count = (s, ch) => s.split(ch).length - 1;
function linkify(text) {
  const parts2 = [];
  const push = (kind, t) => {
    if (!t) return;
    const last = parts2[parts2.length - 1];
    if (last && last.kind === "text") last.text += t;
    else parts2.push({ kind, text: t });
  };
  for (const word of text.split(/(\s+)/)) {
    if (!word) continue;
    const lead = LEADING_RE.exec(word)?.[0] ?? "";
    let core = word.slice(lead.length);
    let tail = "";
    const trail = TRAILING_RE.exec(core);
    if (trail) {
      core = core.slice(0, core.length - trail[0].length);
      tail = trail[0];
    }
    while (tail.startsWith(")") && count(core, "(") > count(core, ")")) {
      core += ")";
      tail = tail.slice(1);
    }
    if (core && LINK_RE.test(core)) {
      const href = /^https?:\/\//i.test(core) ? core : `https://${core}`;
      let safe = null;
      try {
        const u = new URL(href);
        if (u.protocol === "http:" || u.protocol === "https:") safe = u.href;
      } catch {
        safe = null;
      }
      if (safe) {
        push("text", lead);
        parts2.push({ kind: "link", text: core, href: safe });
        push("text", tail);
        continue;
      }
    }
    push("text", word);
  }
  return parts2;
}
var RTL_CHAR = /[֐-׿؀-ۿ܀-ݏݐ-ݿࢠ-ࣿיִ-﷿ﹰ-﻿]/;
var LTR_CHAR = /[A-Za-zÀ-ɏͰ-ϿЀ-ӿ]/;
function textDirection(text) {
  for (const ch of text) {
    if (RTL_CHAR.test(ch)) return "rtl";
    if (LTR_CHAR.test(ch)) return "ltr";
  }
  return "ltr";
}
function isArabicScript(ch) {
  return /[؀-ۿݐ-ݿࢠ-ࣿﭐ-﷿ﹰ-﻿]/.test(ch);
}
var segmenter;
function firstGrapheme(text) {
  const s = text.trim();
  if (!s) return "";
  if (segmenter === void 0) {
    const Ctor = Intl.Segmenter;
    segmenter = Ctor ? new Ctor(void 0, { granularity: "grapheme" }) : null;
  }
  if (segmenter) {
    for (const { segment } of segmenter.segment(s)) return segment;
  }
  return Array.from(s)[0] ?? "";
}
function normalizeForSearch(text) {
  return text.toLocaleLowerCase().normalize("NFKD").replace(/[̀-ًͯ-ٰٟ]/g, "").replace(/[يى]/g, "\u06CC").replace(/ك/g, "\u06A9").replace(/[أإآ]/g, "\u0627").replace(/‌/g, " ");
}
function oneLine(text, max = 200) {
  const s = text.replace(/\s+/g, " ").trim();
  return s.length > max ? `${s.slice(0, max - 1)}\u2026` : s;
}

// client/shared/ui/Avatar.tsx
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
var ACCENTS = 8;
function accentOf(name) {
  let seed = 0;
  for (let i = 0; i < name.length; i++) seed += name.charCodeAt(i);
  return seed % ACCENTS;
}
function safePicture(url2) {
  if (!url2) return null;
  const u = url2.trim();
  if (/\/profile(?:-light|-dark)?\.(?:jpe?g|png|webp)(?:[#?].*)?$/i.test(u)) return null;
  if (/^data:image\/(?:png|jpe?g|gif|webp);/i.test(u)) return u;
  if (/^https:\/\//i.test(u) || u.startsWith("/") && !u.startsWith("//")) return u;
  return null;
}
var INITIAL_WEIGHT = 600;
var shifts = /* @__PURE__ */ new Map();
var canvas = null;
function fontSpec(px) {
  const family = typeof document !== "undefined" && document.body && getComputedStyle(document.body).fontFamily || "Poppins, Vazirmatn, sans-serif";
  return `${INITIAL_WEIGHT} ${px}px ${family}`;
}
function measureShift(ch) {
  if (shifts.has(ch)) return shifts.get(ch) ?? null;
  let shift = null;
  try {
    canvas ?? (canvas = document.createElement("canvas"));
    const ctx = canvas.getContext("2d");
    if (ctx) {
      const size = 100;
      ctx.font = fontSpec(size);
      const glyph = ctx.measureText(ch);
      const ref = ctx.measureText("H");
      const v = [glyph.actualBoundingBoxAscent, glyph.actualBoundingBoxDescent, ref.fontBoundingBoxAscent, ref.fontBoundingBoxDescent];
      if (v.every(Number.isFinite)) {
        const baselineBelowMiddle = (ref.fontBoundingBoxAscent - ref.fontBoundingBoxDescent) / 2;
        const inkMiddleBelowBaseline = (glyph.actualBoundingBoxDescent - glyph.actualBoundingBoxAscent) / 2;
        const s = Math.round(-(baselineBelowMiddle + inkMiddleBelowBaseline) / size * 1e3) / 1e3;
        shift = Math.abs(s) > 0.5 ? null : s;
      }
    }
  } catch {
    shift = null;
  }
  shifts.set(ch, shift);
  return shift;
}
function useInitialShift(ch) {
  const needs = !!ch && !/^[A-Z0-9?]$/.test(ch);
  const [shift, setShift] = (0, import_react3.useState)(() => {
    if (!needs || typeof document === "undefined") return null;
    const fonts = document.fonts;
    try {
      if (fonts && !fonts.check(fontSpec(100), ch)) return null;
    } catch {
    }
    return measureShift(ch);
  });
  (0, import_react3.useEffect)(() => {
    if (!needs) return void 0;
    const fonts = document.fonts;
    let alive = true;
    fonts?.load(fontSpec(100), ch).catch(() => void 0).then(() => {
      if (!alive) return;
      shifts.delete(ch);
      setShift(measureShift(ch));
    });
    return () => {
      alive = false;
    };
  }, [ch, needs]);
  return needs ? shift : null;
}
function Initial({ ch }) {
  const shift = useInitialShift(ch);
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
    "span",
    {
      className: `initial-avatar-char${isArabicScript(ch) ? " initial-avatar-char--arabic" : ""}`,
      style: shift ? { transform: `translateY(${shift}em)` } : void 0,
      children: ch
    }
  );
}
var Avatar = (0, import_react3.memo)(function Avatar2({ name, picture, className, online = false, onlineClass = "online-contact", deleted = false }) {
  const src = deleted ? null : safePicture(picture);
  const [broken, setBroken] = (0, import_react3.useState)(null);
  const onlineCls = online ? ` ${onlineClass}` : "";
  if (src && broken !== src) {
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", { className: className + onlineCls, src, alt: "", draggable: false, decoding: "async", onError: () => setBroken(src) });
  }
  const display = name.trim();
  const ch = deleted ? "" : (firstGrapheme(display) || "?").toUpperCase();
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: `${className} initial-avatar initial-accent-${accentOf(display)}${deleted ? " deleted-account-avatar" : ""}${onlineCls}`, "aria-hidden": "true", children: ch ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Initial, { ch }) : null });
});

// client/shared/ui/Dialog.tsx
var import_react4 = __toESM(require_react(), 1);
var import_jsx_runtime2 = __toESM(require_jsx_runtime(), 1);
var openDialogs = createStore([]);
var forget = (d) => openDialogs.set((list) => list.includes(d) ? list.filter((x) => x !== d) : list);
var remember = (d) => openDialogs.set((list) => [...list.filter((x) => x !== d), d]);
function open(d) {
  try {
    d.showModal();
  } catch {
    d.setAttribute("open", "");
  }
  remember(d);
}
var own = (e) => e.target === e.currentTarget;
function Dialog({ className, onClose, children, closeOnBackdrop = true, labelledBy, label }) {
  const ref = (0, import_react4.useRef)(null);
  const down = (0, import_react4.useRef)(null);
  const unmounting = (0, import_react4.useRef)(false);
  const onCloseRef = (0, import_react4.useRef)(onClose);
  onCloseRef.current = onClose;
  (0, import_react4.useLayoutEffect)(() => {
    const d = ref.current;
    unmounting.current = false;
    if (d && !d.open) open(d);
    return () => {
      unmounting.current = true;
      if (!d) return;
      forget(d);
      if (d.open) d.close();
    };
  }, []);
  return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
    "dialog",
    {
      ref,
      className,
      "aria-labelledby": labelledBy,
      "aria-label": label,
      onCancel: (e) => {
        if (!own(e)) return;
        e.preventDefault();
        e.stopPropagation();
        onCloseRef.current();
      },
      onClose: (e) => {
        if (!own(e)) return;
        e.stopPropagation();
        const d = ref.current;
        if (unmounting.current || !d || d.open) return;
        forget(d);
        onCloseRef.current();
        requestAnimationFrame(() => {
          if (!unmounting.current && ref.current === d && d.isConnected && !d.open) open(d);
        });
      },
      onPointerDown: (e) => {
        down.current = e.target;
      },
      onClick: (e) => {
        if (closeOnBackdrop && e.target === e.currentTarget && down.current === e.currentTarget) onCloseRef.current();
      },
      children
    }
  );
}

// client/chat/ui/chat/ForwardDialog.tsx
var import_jsx_runtime3 = __toESM(require_jsx_runtime(), 1);
function ForwardDialog() {
  const forwarding = useStore(ui, (s) => s.forwarding);
  const byConv = useStore(contacts, (s) => s.byConv);
  const removed = useStore(undoing, (s) => s.removedContacts);
  const targets = (0, import_react5.useMemo)(
    () => sortActive(Object.values(byConv).filter((r) => !r.isBlocked && !isDeletedAccount(r) && !removed[r.conversationId]), {}),
    [byConv, removed]
  );
  const choose = (convId) => {
    if (!forwarding) return;
    cancelSelection();
    closeDialog();
    openChat(convId);
    patchComposer(convId, { action: { kind: "forward", items: forwarding.items, fromName: forwarding.fromName }, mode: "normal", scheduledFor: null });
  };
  return /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)(Dialog, { className: "forward-dialog", onClose: closeDialog, label: "Forward to", children: [
    /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("div", { className: "forward-dialog-header", children: [
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { children: "Forward to..." }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("button", { type: "button", className: "close-forward-dialog", "aria-label": "Close", onClick: closeDialog, children: "\u2715" })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "forwarded-contact-dialog", children: targets.map((row) => /* @__PURE__ */ (0, import_jsx_runtime3.jsxs)("button", { type: "button", className: "forwarded-contact-card", onClick: () => choose(row.conversationId), children: [
      row.isSaved ? /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("div", { className: "forwarded-contact-profile saved-icon forwarded-saved-icon", children: /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(Icons.Saved, {}) }) : /* @__PURE__ */ (0, import_jsx_runtime3.jsx)(Avatar, { name: displayName(row), picture: row.contact?.profilePics[0], className: "forwarded-contact-profile" }),
      /* @__PURE__ */ (0, import_jsx_runtime3.jsx)("span", { className: "forwarded-contact-name", dir: "auto", children: displayName(row) })
    ] }, row.conversationId)) })
  ] });
}

// client/chat/ui/chat/ChatPart.tsx
var import_react14 = __toESM(require_react(), 1);

// client/chat/services/actions.ts
var OFFLINE = "No connection. Check your internet and try again.";
async function copyText(text) {
  const done = () => showToast("Message copied", { icon: "copy" });
  try {
    await navigator.clipboard.writeText(text);
    done();
    return;
  } catch {
  }
  try {
    const area = document.createElement("textarea");
    area.value = text;
    area.setAttribute("readonly", "");
    area.style.position = "fixed";
    area.style.opacity = "0";
    document.body.appendChild(area);
    area.select();
    const ok = document.execCommand("copy");
    area.remove();
    if (ok) done();
    else showToast("Couldn't copy the message", { icon: "error" });
  } catch {
    showToast("Couldn't copy the message", { icon: "error" });
  }
}
async function editMessage(convId, message, rawText) {
  const text = rawText.trim();
  if (!text || text === message.text) return;
  const before = { text: message.text, isEdited: message.isEdited };
  updateExisting(convId, (c) => patchMessage(c, message.id, { text, isEdited: true }));
  try {
    const ack = await request("message:edit", { messageId: message.id, text });
    if (ack.error !== void 0) throw new Error(ack.error);
    updateExisting(convId, (c) => patchMessage(c, message.id, { text: ack.text, isEdited: true, updatedAt: ack.updatedAt }));
    updateExisting(
      convId,
      (c) => c.pinned?.some((p) => p.id === message.id) ? { ...c, pinned: c.pinned.map((p) => p.id === message.id ? { ...p, text: ack.text } : p) } : c
    );
    patchRow(convId, (r) => r.lastMessage?.id === message.id ? { lastMessage: { ...r.lastMessage, text: ack.text, isEdited: true } } : {});
  } catch (e) {
    updateExisting(convId, (c) => patchMessage(c, message.id, before));
    showToast(e instanceof OfflineError ? OFFLINE : e.message || "Couldn't edit the message", { icon: "error" });
  }
}
function newestRemaining(convId, hidden) {
  const list = getCache(convId)?.messages ?? [];
  for (let i = list.length - 1; i >= 0; i--) if (!hidden.has(list[i].id)) return list[i];
  return null;
}
function deleteMessages(convId, ids) {
  if (ids.length === 0) return;
  const idSet = new Set(ids);
  const row = getRow(convId);
  const previousPreview = row?.lastMessage ?? null;
  let shownPreview;
  withUndo({
    key: `messages:${convId}:${[...ids].sort((a, b) => a - b).join(",")}`,
    text: ids.length > 1 ? `${ids.length} messages deleted` : "Message deleted",
    icon: "delete",
    apply: () => {
      undoing.set((s) => {
        const messages = { ...s.messages };
        for (const id of ids) messages[id] = true;
        return { ...s, messages };
      });
      if (previousPreview && idSet.has(previousPreview.id)) {
        const hidden = new Set(Object.keys(undoing.get().messages).map(Number));
        const before = newestRemaining(convId, hidden);
        shownPreview = before ? toPreview(before) : null;
        patchRow(convId, { lastMessage: shownPreview });
      }
    },
    revert: () => {
      undoing.set((s) => {
        const messages = { ...s.messages };
        for (const id of ids) delete messages[id];
        return { ...s, messages };
      });
      if (shownPreview !== void 0 && getRow(convId)?.lastMessage === shownPreview) patchRow(convId, { lastMessage: previousPreview });
    },
    commit: async () => {
      if (isConnected()) {
        const ack = await request("messages:delete", { messageIds: ids });
        if (ack.error !== void 0) throw new Error(ack.error);
      } else {
        await messagesApi.deleteMany(ids);
      }
      updateExisting(convId, (c) => removeFromCache(c, ids));
      undoing.set((s) => {
        const messages = { ...s.messages };
        for (const id of ids) delete messages[id];
        return { ...s, messages };
      });
      if (previousPreview && idSet.has(previousPreview.id) && !getCache(convId)) refreshRowSoon(convId);
    },
    commitOnExit: () => void messagesApi.deleteMany(ids, true).catch(() => void 0),
    failedText: ids.length > 1 ? "Couldn't delete the messages. Try again." : "Couldn't delete the message. Try again."
  });
}
async function togglePin(convId, message) {
  closeMenu();
  try {
    const ack = await request("message:pin", { messageId: message.id });
    if (ack.error !== void 0) throw new Error(ack.error);
    updateExisting(convId, (c) => {
      const next = patchMessage(c, message.id, { isPinned: ack.isPinned });
      if (!next.pinned) return next;
      return {
        ...next,
        pinned: ack.isPinned ? insertPinned(next.pinned, message) : next.pinned.filter((p) => p.id !== message.id)
      };
    });
  } catch (e) {
    const msg = e.message;
    showToast(e instanceof OfflineError ? OFFLINE : msg.startsWith("Pin limit") ? msg : "Failed to update pin", { icon: "error" });
  }
}
async function react(convId, message, emoji) {
  const me = session.get().me?.id;
  if (me === void 0) return;
  const before = message.reactions;
  const mine = before.find((r) => r.userId === me);
  const optimistic = mine?.emoji === emoji ? before.filter((r) => r.userId !== me) : [...before.filter((r) => r.userId !== me), { userId: me, emoji }];
  updateExisting(convId, (c) => patchMessage(c, message.id, { reactions: optimistic }));
  try {
    const ack = await request("reaction:add", { messageId: message.id, emoji });
    if (ack.error !== void 0) throw new Error(ack.error);
    updateExisting(convId, (c) => patchMessage(c, message.id, { reactions: ack.reactions }));
  } catch (e) {
    updateExisting(convId, (c) => patchMessage(c, message.id, { reactions: before }));
    showToast(e instanceof OfflineError ? OFFLINE : "Failed to send reaction", { icon: "error" });
  }
}
function forwardSource(convId, m) {
  const me = session.get().me;
  const row = getRow(convId);
  let author;
  if (m.forwardedFrom) author = m.forwardedFrom === "You" ? m.senderId === me?.id ? me?.name ?? "" : realName(row) : m.forwardedFrom;
  else if (m.senderId === me?.id || row?.isSaved) author = me?.name ?? "";
  else author = realName(row);
  return { sourceId: m.id, text: m.text ?? "", forwardedFrom: author || "Unknown" };
}
function startReply(convId, message) {
  closeMenu();
  patchComposer(convId, { action: { kind: "reply", message } });
}
function startEdit(convId, message) {
  closeMenu();
  patchComposer(convId, { action: { kind: "edit", message }, draft: message.text ?? "" });
}
async function updateContact(convId, patch, optimistic) {
  const row = getRow(convId);
  if (!row) return false;
  const before = {};
  for (const k of Object.keys(optimistic)) before[k] = row[k];
  patchRow(convId, optimistic);
  try {
    upsertRow(await contactsApi.update(row.id, patch));
    return true;
  } catch (e) {
    patchRow(convId, before);
    showToast(errorText(e, "Couldn't update. Try again."), { icon: "error" });
    return false;
  }
}
function togglePinChat(row) {
  void updateContact(row.conversationId, { isPinned: !row.isPinned }, { isPinned: !row.isPinned });
}
function toggleMute(row) {
  void updateContact(row.conversationId, { isMuted: !row.isMuted }, { isMuted: !row.isMuted });
}
async function toggleBlock(row) {
  if (row.isSaved) return;
  const next = !row.isBlocked;
  if (await updateContact(row.conversationId, { isBlocked: next }, { isBlocked: next })) {
    showToast(next ? "Contact blocked" : "Contact unblocked", { icon: "block" });
  }
}
async function setArchived(row, archived) {
  if (row.isSaved) return false;
  if (archived && ui.get().openConvId === row.conversationId) closeChat();
  const ok = await updateContact(row.conversationId, { isArchived: archived }, { isArchived: archived });
  if (ok) showToast(archived ? "Chat archived" : "Chat unarchived", { icon: "archive" });
  return ok;
}
async function rename(row, nickname) {
  const clean = nickname.replace(/\s+/g, " ").trim().slice(0, 100);
  const shown = row.nickname || row.contact?.name || "";
  if (clean === shown) return;
  const value2 = clean && clean !== row.contact?.name ? clean : null;
  if (value2 === row.nickname) return;
  const ok = await updateContact(row.conversationId, { nickname: value2 ?? "" }, { nickname: value2 });
  if (!ok) showToast("Couldn't change the name. Try again.", { icon: "error" });
}
function newestKnownId(convId) {
  const fromList = getRow(convId)?.lastMessage?.id ?? 0;
  const list = getCache(convId)?.messages;
  const fromChat = list && list.length ? list[list.length - 1].id : 0;
  return Math.max(fromList, fromChat) || null;
}
function deleteChat(row) {
  const convId = row.conversationId;
  if (ui.get().openConvId === convId) closeChat();
  const upToId = newestKnownId(convId);
  withUndo({
    key: `chat:${convId}`,
    text: "Chat deleted",
    icon: "delete",
    apply: () => undoing.set((s) => ({ ...s, clearedChats: { ...s.clearedChats, [convId]: true } })),
    revert: () => undoing.set((s) => {
      const clearedChats = { ...s.clearedChats };
      delete clearedChats[convId];
      return { ...s, clearedChats };
    }),
    commit: async () => {
      await conversationsApi.clear(convId, upToId);
      if (upToId !== null) updateExisting(convId, (c) => clearUpTo(c, upToId));
      const last = getRow(convId)?.lastMessage;
      if (!last || upToId === null || last.id <= upToId) patchRow(convId, { lastMessage: null, unreadCount: 0 });
      else refreshRowSoon(convId);
      undoing.set((s) => {
        const clearedChats = { ...s.clearedChats };
        delete clearedChats[convId];
        return { ...s, clearedChats };
      });
    },
    commitOnExit: () => void conversationsApi.clear(convId, upToId, true).catch(() => void 0),
    failedText: "Couldn't delete the chat. Try again."
  });
}
function deleteContact(row) {
  if (row.isSaved) return;
  const convId = row.conversationId;
  if (ui.get().openConvId === convId) closeChat();
  withUndo({
    key: `contact:${convId}`,
    text: "Contact deleted",
    icon: "delete",
    apply: () => undoing.set((s) => ({ ...s, removedContacts: { ...s.removedContacts, [convId]: true } })),
    revert: () => undoing.set((s) => {
      const removedContacts = { ...s.removedContacts };
      delete removedContacts[convId];
      return { ...s, removedContacts };
    }),
    commit: async () => {
      await contactsApi.remove(row.id);
      forgetChat(convId);
      removeRow(convId);
      undoing.set((s) => {
        const removedContacts = { ...s.removedContacts };
        delete removedContacts[convId];
        return { ...s, removedContacts };
      });
    },
    commitOnExit: () => void contactsApi.remove(row.id, true).catch(() => void 0),
    failedText: "Couldn't delete the contact. Try again."
  });
}
async function addContact(username, name) {
  const clean = username.trim().replace(/^@/, "");
  try {
    const row = await contactsApi.add(clean, name.trim() || void 0);
    cancelUndo(`contact:${row.conversationId}`);
    upsertRow(row);
    return row;
  } catch (e) {
    if (e instanceof ApiError && e.status === 409) {
      const key2 = clean.toLowerCase();
      const row = Object.values(contacts.get().byConv).find((r) => !r.isSaved && r.contact?.username.toLowerCase() === key2);
      if (row) {
        cancelUndo(`contact:${row.conversationId}`);
        return row;
      }
    }
    throw e;
  }
}

// client/chat/ui/selectors.ts
var import_react6 = __toESM(require_react(), 1);
function useNewestPending() {
  const box = useStore(outbox, (s) => s);
  return (0, import_react6.useMemo)(() => {
    const out = {};
    for (const p of Object.values(box)) {
      const cur = out[p.conversationId];
      if (!cur || p.createdAt > cur.createdAt) out[p.conversationId] = p;
    }
    return out;
  }, [box]);
}
function useChatLists() {
  const byConv = useStore(contacts, (s) => s.byConv);
  const openConvId = useStore(ui, (s) => s.openConvId);
  const meId2 = useStore(session, (s) => s.me?.id ?? null);
  const pending3 = useNewestPending();
  return (0, import_react6.useMemo)(() => {
    const active = [];
    const list = [];
    const archived = [];
    for (const row of Object.values(byConv)) {
      const section = sectionOf(row, openConvId, meId2, pending3[row.conversationId]);
      if (section === "active") active.push(row);
      else if (section === "contacts") list.push(row);
      else archived.push(row);
    }
    return {
      active: sortActive(active, pending3),
      contacts: sortContacts(list),
      archived: archived.sort((a, b) => b.id - a.id)
    };
  }, [byConv, openConvId, meId2, pending3]);
}
function useRow(convId) {
  return useStore(contacts, (s) => convId === null ? null : s.byConv[convId] ?? null);
}
function useMeId() {
  return useStore(session, (s) => s.me?.id ?? null);
}
function useUi(pick2, eq = Object.is) {
  return useStore(ui, pick2, eq);
}

// client/chat/ui/chat/ChatHeader.tsx
var import_jsx_runtime4 = __toESM(require_jsx_runtime(), 1);
function ChatHeader({ row, withPinnedBar }) {
  const isTyping = useStore(typing, (s) => (s[row.conversationId] ?? 0) > Date.now());
  const elsewhere = useStore(
    contacts,
    (s) => Object.values(s.byConv).reduce((n, r) => r.conversationId === row.conversationId ? n : n + (r.unreadCount || 0), 0)
  );
  const online = isOnline(row);
  const name = displayName(row);
  return /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(
    "header",
    {
      className: `chat-header${withPinnedBar ? " chat-header-radius-top" : ""}`,
      onClick: () => {
        if (!row.isSaved) openPanel("profile");
      },
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime4.jsxs)(
          "span",
          {
            className: "chat-back",
            role: "button",
            tabIndex: 0,
            "aria-label": elsewhere ? `Back, ${elsewhere} unread` : "Back",
            onClick: (e) => {
              e.stopPropagation();
              closeChat();
            },
            onKeyDown: (e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                e.stopPropagation();
                closeChat();
              }
            },
            children: [
              /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(Icons.Back, {}),
              /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "unread-message-count", style: { opacity: elsewhere ? 1 : 0 }, children: elsewhere > 999 ? "999+" : elsewhere })
            ]
          }
        ),
        row.isSaved ? /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "chat-profile saved-icon", children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(Icons.Saved, { className: "saved-icon-svg" }) }) : /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: `chat-profile${online ? " online" : ""}`, children: /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(Avatar, { name, picture: row.contact?.profilePics[0], className: "chat-profile-picture", online, deleted: isDeletedAccount(row) }) }),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "chat-name", dir: "auto", children: name }),
        !row.isSaved && // the whole header opens the profile; this is its keyboard way in
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)(
          "button",
          {
            type: "button",
            className: "visually-hidden",
            onClick: (e) => {
              e.stopPropagation();
              openPanel("profile");
            },
            children: "View profile"
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime4.jsx)("span", { className: "chat-typing-status", "aria-live": "polite", children: isTyping ? "typing..." : "" })
      ]
    }
  );
}

// client/chat/ui/chat/Composer.tsx
var import_react9 = __toESM(require_react(), 1);

// client/chat/ui/chat/CapsulePicker.tsx
var import_react7 = __toESM(require_react(), 1);

// client/shared/lib/time.ts
var MINUTE = 6e4;
var HOUR = 60 * MINUTE;
var DAY = 24 * HOUR;
function toDate(value2) {
  if (value2 === null || value2 === void 0 || value2 === "") return null;
  const d = value2 instanceof Date ? value2 : new Date(value2);
  return Number.isNaN(d.getTime()) ? null : d;
}
var pad = (n) => String(n).padStart(2, "0");
function dayKey(value2 = /* @__PURE__ */ new Date()) {
  const d = toDate(value2);
  return d ? `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}` : "";
}
function shiftDayKey(key2, days) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(key2);
  if (!m) return "";
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]));
  d.setDate(d.getDate() + days);
  return dayKey(d);
}
function clock(value2) {
  const d = toDate(value2);
  return d ? `${pad(d.getHours())}:${pad(d.getMinutes())}` : "";
}
function shortDate(value2) {
  const d = toDate(value2);
  return d ? d.toLocaleDateString("en-US", { month: "short", day: "numeric" }) : "";
}
function listTime(value2, now = /* @__PURE__ */ new Date()) {
  const d = toDate(value2);
  if (!d) return "";
  const key2 = dayKey(d);
  const today = dayKey(now);
  if (key2 === today) return clock(d);
  if (key2 === shiftDayKey(today, -1)) return "yesterday";
  if (d.getFullYear() !== now.getFullYear()) return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  return shortDate(d);
}
function dayLabel(key2, now = /* @__PURE__ */ new Date()) {
  const today = dayKey(now);
  if (key2 === today) return "Today";
  if (key2 === shiftDayKey(today, -1)) return "Yesterday";
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(key2);
  if (!m) return "";
  return new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3])).toLocaleDateString("en-US", {
    month: "long",
    day: "numeric",
    year: "numeric"
  });
}
function dateAtTime(value2) {
  const d = toDate(value2);
  return d ? `${shortDate(d)} at ${clock(d)}` : "";
}
var plural = (n, word) => `${n} ${word}${n === 1 ? "" : "s"}`;
function timeAgo(value2, now = Date.now()) {
  const d = toDate(value2);
  if (!d) return "";
  const diff = Math.max(0, now - d.getTime());
  if (diff < MINUTE) return "just now";
  if (diff < HOUR) return `${plural(Math.floor(diff / MINUTE), "minute")} ago`;
  if (diff < DAY) return `${plural(Math.floor(diff / HOUR), "hour")} ago`;
  if (diff < 2 * DAY) return "yesterday";
  if (diff < 7 * DAY) return `${plural(Math.floor(diff / DAY), "day")} ago`;
  if (diff < 14 * DAY) return "last week";
  if (diff < 30 * DAY) return `${plural(Math.floor(diff / (7 * DAY)), "week")} ago`;
  if (diff < 60 * DAY) return "last month";
  if (diff < 365 * DAY) return `${plural(Math.floor(diff / (30 * DAY)), "month")} ago`;
  return "a long time ago";
}
function toLocalInputValue(d) {
  return `${dayKey(d)}T${clock(d)}`;
}
function fromLocalInputValue(v) {
  const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})$/.exec(v);
  if (!m) return null;
  const d = new Date(Number(m[1]), Number(m[2]) - 1, Number(m[3]), Number(m[4]), Number(m[5]));
  return Number.isNaN(d.getTime()) ? null : d;
}

// client/chat/ui/chat/CapsulePicker.tsx
var import_jsx_runtime5 = __toESM(require_jsx_runtime(), 1);
var MIN_MS = 5 * 6e4;
var MAX_MS = 365 * 24 * 60 * 6e4;
var toMinute = (d) => new Date(d.getFullYear(), d.getMonth(), d.getDate(), d.getHours(), d.getMinutes(), 0, 0);
function CapsulePicker({ onCancel, onConfirm }) {
  const now = toMinute(/* @__PURE__ */ new Date());
  const min = new Date(now.getTime() + MIN_MS);
  const max = new Date(now.getTime() + MAX_MS);
  const [value2, setValue] = (0, import_react7.useState)(() => toLocalInputValue(min));
  const titleId = (0, import_react7.useId)();
  const confirm = () => {
    const chosen = fromLocalInputValue(value2);
    const base = toMinute(/* @__PURE__ */ new Date());
    if (!chosen || chosen.getTime() < base.getTime() + MIN_MS || chosen.getTime() > base.getTime() + MAX_MS) {
      showToast("Selected time out of range (min +5 minutes, max +1 year)", { icon: "error" });
      return;
    }
    onConfirm(toMinute(chosen).toISOString());
  };
  return /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(Dialog, { className: "capsule-picker-wrap", onClose: onCancel, labelledBy: titleId, children: /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "capsule-picker-dialog", children: [
    /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("div", { className: "capsule-picker-title", id: titleId, children: "\u23F3 Set unlock time" }),
    /* @__PURE__ */ (0, import_jsx_runtime5.jsx)(
      "input",
      {
        className: "capsule-datetime-input",
        type: "datetime-local",
        min: toLocalInputValue(min),
        max: toLocalInputValue(max),
        value: value2,
        onChange: (e) => setValue(e.target.value),
        onKeyDown: (e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            confirm();
          }
        }
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime5.jsxs)("div", { className: "capsule-picker-actions", children: [
      /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("button", { type: "button", onClick: onCancel, children: "Cancel" }),
      /* @__PURE__ */ (0, import_jsx_runtime5.jsx)("button", { type: "button", className: "capsule-confirm", onClick: confirm, children: "Set & Arm \u{1F4A3}" })
    ] })
  ] }) });
}

// client/chat/ui/chat/EmojiPicker.tsx
var import_react8 = __toESM(require_react(), 1);
var import_jsx_runtime6 = __toESM(require_jsx_runtime(), 1);
var loading2 = null;
function loadPicker() {
  loading2 ?? (loading2 = import("./chunks/emoji-picker-element-JCST5IN7.js").catch((e) => {
    loading2 = null;
    throw e;
  }));
  return loading2;
}
function EmojiPicker({ onPick, dark }) {
  const host = (0, import_react8.useRef)(null);
  const [failed, setFailed] = (0, import_react8.useState)(false);
  const pick2 = useEvent(onPick);
  (0, import_react8.useEffect)(() => {
    let alive = true;
    let picker = null;
    const onClick = (e) => {
      const unicode = e.detail?.unicode;
      if (unicode) pick2(unicode);
    };
    loadPicker().then(() => {
      if (!alive || !host.current) return;
      picker = document.createElement("emoji-picker");
      picker.className = `emoji-picker ${dark ? "dark" : "light"}`;
      picker.setAttribute("data-source", "/assets/data.json");
      picker.addEventListener("emoji-click", onClick);
      host.current.appendChild(picker);
    }).catch(() => alive && setFailed(true));
    return () => {
      alive = false;
      picker?.removeEventListener("emoji-click", onClick);
      picker?.remove();
    };
  }, [dark, pick2]);
  return /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("div", { ref: host, className: "emoji-picker-host", children: failed && /* @__PURE__ */ (0, import_jsx_runtime6.jsx)("p", { className: "emoji-picker-failed", children: "Couldn't load emojis." }) });
}

// client/chat/ui/chat/Composer.tsx
var import_jsx_runtime7 = __toESM(require_jsx_runtime(), 1);
var MAX_LINES = 7;
var LONG_PRESS_MS = 500;
var MODE_LABEL = {
  normal: "Send normally",
  "one-time": "One-time message",
  "time-capsule": "Time Capsule"
};
function ModeIcon({ mode }) {
  if (mode === "one-time") return /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(Icons.OneTime, { size: 18 });
  if (mode === "time-capsule") return /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(Icons.CapsuleLock, { size: 20 });
  return /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(Icons.Send, {});
}
var enterSends = () => window.matchMedia("(pointer: fine)").matches;
function Composer({ row, refCallback, dark }) {
  const convId = row.conversationId;
  const state = useStore(composers, (s) => s[convId] ?? EMPTY_COMPOSER);
  const { draft, action, mode } = state;
  const input = (0, import_react9.useRef)(null);
  const selection = (0, import_react9.useRef)({ start: 0, end: 0 });
  const [emojiOpen, setEmojiOpen] = (0, import_react9.useState)(false);
  const [popup, setPopup] = (0, import_react9.useState)(false);
  const [picker, setPicker] = (0, import_react9.useState)(null);
  const [slots, setSlots] = (0, import_react9.useState)(["normal", "time-capsule", "one-time"]);
  const pressTimer = (0, import_react9.useRef)(null);
  const suppressClick = useClickSuppressor();
  const longPressed = (0, import_react9.useRef)(false);
  const emojiArea = (0, import_react9.useRef)(null);
  (0, import_react9.useEffect)(() => {
    if (slots[0] === mode) return;
    const at = slots.indexOf(mode);
    if (at > 0) {
      const next = [...slots];
      [next[0], next[at]] = [next[at], next[0]];
      setSlots(next);
    } else setSlots(["normal", "time-capsule", "one-time"]);
  }, [mode, slots]);
  (0, import_react9.useEffect)(() => {
    if (!action || action.kind === "forward") return;
    const ta = input.current;
    if (!ta) return;
    ta.focus({ preventScroll: true });
    const end = ta.value.length;
    ta.setSelectionRange(end, end);
  }, [action]);
  (0, import_react9.useLayoutEffect)(() => {
    const ta = input.current;
    if (!ta) return;
    const cs = getComputedStyle(ta);
    const line = parseFloat(cs.lineHeight) || 22.4;
    const chrome = parseFloat(cs.paddingTop) + parseFloat(cs.paddingBottom) + parseFloat(cs.borderTopWidth) + parseFloat(cs.borderBottomWidth);
    const max = line * MAX_LINES + chrome;
    ta.style.height = "auto";
    const want = ta.scrollHeight + parseFloat(cs.borderTopWidth) + parseFloat(cs.borderBottomWidth);
    ta.style.height = `${Math.min(want, max)}px`;
    ta.style.overflowY = want > max ? "auto" : "hidden";
  }, [draft]);
  (0, import_react9.useEffect)(() => {
    if (!emojiOpen && !popup) return void 0;
    const onDown = (e) => {
      const t = e.target;
      if (emojiOpen && !emojiArea.current?.contains(t)) setEmojiOpen(false);
    };
    document.addEventListener("pointerdown", onDown, true);
    return () => document.removeEventListener("pointerdown", onDown, true);
  }, [emojiOpen, popup]);
  const setDraft = (value2) => {
    patchComposer(convId, { draft: value2 });
    if (value2.trim()) userTyped(convId);
    else stopTyping();
  };
  const cancelAction = () => {
    if (action?.kind === "edit") patchComposer(convId, { action: null, draft: "" });
    else patchComposer(convId, { action: null });
  };
  const send2 = () => {
    const c = getComposer(convId);
    if (c.action?.kind === "edit") {
      const target = c.action.message;
      patchComposer(convId, { action: null, draft: "" });
      void editMessage(convId, target, c.draft);
      return;
    }
    if (c.action?.kind === "forward") {
      const items = c.action.items;
      patchComposer(convId, { action: null, draft: "" });
      forwardTo(convId, items, c.draft);
      return;
    }
    if (!c.draft.trim()) return;
    const ok = sendText(convId, c.draft, {
      replyTo: c.action?.kind === "reply" ? c.action.message : null,
      isOneTime: c.mode === "one-time",
      scheduledFor: c.mode === "time-capsule" ? c.scheduledFor : null
    });
    if (!ok) return;
    patchComposer(convId, { draft: "", action: null, mode: "normal", scheduledFor: null });
  };
  const insertEmoji = (emoji) => {
    const { start: start3, end } = selection.current;
    const value2 = getComposer(convId).draft;
    const next = value2.slice(0, start3) + emoji + value2.slice(end);
    if (next.length > MAX_LENGTH) return;
    setDraft(next);
    const caret = start3 + emoji.length;
    selection.current = { start: caret, end: caret };
    setEmojiOpen(false);
    requestAnimationFrame(() => {
      const ta = input.current;
      if (!ta) return;
      ta.focus({ preventScroll: true });
      ta.setSelectionRange(caret, caret);
    });
  };
  const chooseSlot = (slot) => {
    const chosen = slots[slot];
    if (chosen === "time-capsule") {
      setPopup(false);
      setPicker({ slot });
      return;
    }
    const next = [...slots];
    [next[0], next[slot]] = [next[slot], next[0]];
    setSlots(next);
    setPopup(false);
    patchComposer(convId, { mode: chosen, scheduledFor: null });
  };
  const canChooseMode = !action || action.kind === "reply";
  const showSend = !!draft.trim() || action?.kind === "forward";
  let preview = null;
  if (action?.kind === "edit") preview = { name: "Edit", text: oneLine(action.message.text ?? "") };
  else if (action?.kind === "reply") {
    const mine = action.message.senderId === session.get().me?.id || row.isSaved;
    preview = { name: `Replying to ${mine ? "You" : displayName(row)}`, text: oneLine(action.message.text ?? "") };
  } else if (action?.kind === "forward") {
    preview = action.items.length === 1 ? { name: `Forwarding message from ${action.fromName}`, text: oneLine(action.items[0].text) } : { name: `Forwarding from: ${action.fromName}`, text: `${action.items.length} messages` };
  }
  return /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)("div", { ref: refCallback, className: "chat-send-message", style: popup ? { zIndex: 501 } : void 0, children: [
    popup && /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("div", { className: "send-mode-overlay", onClick: () => setPopup(false) }),
    preview && /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)("div", { className: "message-action-preview", children: [
      /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)("span", { className: "action-preview", children: [
        /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("span", { className: "action-name", children: preview.name }),
        /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("span", { className: "action-message-preview", dir: "auto", children: preview.text })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("button", { type: "button", className: "cancel-edit-btn", "aria-label": "Cancel", onClick: cancelAction, children: /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(Icons.CloseThin, {}) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)("div", { ref: emojiArea, className: "emoji-area", children: [
      /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("button", { type: "button", className: "emoji-btn", "aria-label": "Emoji", "aria-expanded": emojiOpen, onClick: () => setEmojiOpen((v) => !v), children: /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(Icons.Emoji, {}) }),
      emojiOpen && /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(EmojiPicker, { onPick: insertEmoji, dark })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(
      "textarea",
      {
        ref: input,
        rows: 1,
        placeholder: "Message...",
        className: `message-input${preview ? " input-rounded-bottom" : ""}`,
        name: "msg",
        "aria-label": "Message",
        dir: textDirection(draft),
        maxLength: MAX_LENGTH,
        value: draft,
        enterKeyHint: enterSends() ? "send" : "enter",
        onChange: (e) => setDraft(e.target.value),
        onBlur: (e) => {
          selection.current = { start: e.currentTarget.selectionStart, end: e.currentTarget.selectionEnd };
        },
        onSelect: (e) => {
          selection.current = { start: e.currentTarget.selectionStart, end: e.currentTarget.selectionEnd };
        },
        onKeyDown: (e) => {
          if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing && enterSends()) {
            e.preventDefault();
            send2();
          } else if (e.key === "Escape" && action) {
            e.preventDefault();
            cancelAction();
          }
        }
      }
    ),
    showSend && /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(
      "button",
      {
        type: "button",
        className: "send-btn",
        "aria-label": mode === "normal" ? "Send" : `Send as ${MODE_LABEL[mode]}`,
        onMouseDown: (e) => e.preventDefault(),
        onPointerDown: (e) => {
          if (e.pointerType === "mouse" && e.button !== 0) return;
          if (!canChooseMode || popup) return;
          pressTimer.current = window.setTimeout(() => {
            pressTimer.current = null;
            longPressed.current = true;
            setPopup(true);
          }, LONG_PRESS_MS);
        },
        onPointerUp: () => {
          if (pressTimer.current !== null) window.clearTimeout(pressTimer.current);
          pressTimer.current = null;
          if (longPressed.current) suppressClick.arm();
          longPressed.current = false;
        },
        onPointerLeave: () => {
          if (pressTimer.current !== null) window.clearTimeout(pressTimer.current);
          pressTimer.current = null;
        },
        onContextMenu: (e) => {
          e.preventDefault();
          if (canChooseMode) setPopup(true);
        },
        onClick: () => {
          if (suppressClick.consume()) return;
          if (popup) setPopup(false);
          send2();
        },
        children: /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(ModeIcon, { mode: action && action.kind !== "reply" ? "normal" : mode })
      }
    ),
    popup && /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("div", { className: "send-trigger-popup", role: "menu", children: [1, 2].map((slot) => /* @__PURE__ */ (0, import_jsx_runtime7.jsxs)("div", { className: `onetime-trigger${slots[slot] === "time-capsule" ? " capsule-trigger" : ""}`, onClick: () => chooseSlot(slot), children: [
      /* @__PURE__ */ (0, import_jsx_runtime7.jsx)("span", { className: "onetime-trigger-label", children: MODE_LABEL[slots[slot]] }),
      /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(
        "button",
        {
          type: "button",
          role: "menuitem",
          className: `onetime-trigger-btn${slots[slot] === "time-capsule" ? " capsule-trigger-btn" : ""}`,
          "aria-label": MODE_LABEL[slots[slot]],
          onClick: (e) => {
            e.stopPropagation();
            chooseSlot(slot);
          },
          children: /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(ModeIcon, { mode: slots[slot] })
        }
      )
    ] }, slot)) }),
    picker && /* @__PURE__ */ (0, import_jsx_runtime7.jsx)(
      CapsulePicker,
      {
        onCancel: () => setPicker(null),
        onConfirm: (iso) => {
          const next = [...slots];
          const prevMain = next[0];
          next[0] = "time-capsule";
          next[picker.slot] = prevMain;
          setSlots(next);
          setPicker(null);
          patchComposer(convId, { mode: "time-capsule", scheduledFor: iso });
        }
      }
    )
  ] });
}

// client/chat/ui/chat/MessageList.tsx
var import_react11 = __toESM(require_react(), 1);

// client/chat/services/seen.ts
var pending2 = null;
var timer2 = null;
var inFlight = false;
function sawMessage(convId, messageId) {
  if (document.visibilityState !== "visible" || ui.get().openConvId !== convId) return;
  if (pending2 && pending2.convId === convId) pending2.upToId = Math.max(pending2.upToId, messageId);
  else pending2 = { convId, upToId: messageId };
  if (timer2 === null) timer2 = window.setTimeout(flush, 250);
}
async function flush() {
  timer2 = null;
  if (inFlight || !pending2) {
    if (pending2 && timer2 === null) timer2 = window.setTimeout(flush, 250);
    return;
  }
  const { convId, upToId } = pending2;
  pending2 = null;
  if (!isConnected() || ui.get().openConvId !== convId) return;
  inFlight = true;
  try {
    const ack = await request("message:seen", { conversationId: convId, upToId });
    if (ack.error !== void 0) return;
    const marked = new Set(ack.marked);
    const me = meId();
    if (marked.size) {
      updateExisting(
        convId,
        (c) => c.messages.some((m) => marked.has(m.id) && !m.isSeen) ? { ...c, messages: c.messages.map((m) => marked.has(m.id) && m.senderId !== me ? { ...m, isSeen: true } : m) } : c
      );
    }
    const unread = ack.unreadCount;
    if (typeof unread === "number") {
      patchRow(convId, (r) => ({
        unreadCount: unread,
        lastMessage: r.lastMessage && marked.has(r.lastMessage.id) ? { ...r.lastMessage, isSeen: true } : r.lastMessage
      }));
    }
  } catch {
  } finally {
    inFlight = false;
    if (pending2 && timer2 === null) timer2 = window.setTimeout(flush, 250);
  }
}

// client/chat/ui/people/Skeletons.tsx
var import_jsx_runtime8 = __toESM(require_jsx_runtime(), 1);
function ContactSkeletons({ count: count2 = 6 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_jsx_runtime8.Fragment, { children: Array.from({ length: count2 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("span", { className: "contacts-card skeleton-placeholder", "aria-hidden": "true", children: [
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "contact-profile skeleton" }),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("span", { className: "contact-name", children: /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "skel-line skeleton", style: { width: `${55 + i % 3 * 10}%` } }) }),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("span", { className: "contact-message", children: /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("span", { className: "last-message", children: /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "skel-line skeleton", style: { width: `${40 + i % 3 * 12}%` } }) }) })
  ] }, i)) });
}
function ActiveChatSkeletons({ count: count2 = 4 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_jsx_runtime8.Fragment, { children: Array.from({ length: count2 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "active-chat-wrapper skeleton-placeholder", "aria-hidden": "true", children: /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("div", { className: "active-chat skeleton-placeholder", children: [
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "active-chat-profile skeleton" }),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("span", { className: "active-chat-info", children: [
      /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("span", { className: "active-chat-name", style: { width: "100%" }, children: /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "skel-line skeleton", style: { width: `${45 + i % 3 * 12}%` } }) }),
      /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("span", { className: "active-chat-last-message", style: { width: "100%" }, children: /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "skel-line skeleton", style: { width: `${30 + i % 3 * 12}%` } }) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("span", { className: "active-chat-meta", children: /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("span", { className: "active-chat-message-time skel-line skeleton", style: { width: "40px" } }) })
  ] }) }, i)) });
}
function MessageSkeletons({ count: count2 = 8 }) {
  return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)(import_jsx_runtime8.Fragment, { children: Array.from({ length: count2 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime8.jsxs)("div", { className: `chat-message ${i % 2 ? "outgoing" : "incoming"} skeleton-placeholder`, "aria-hidden": "true", children: [
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "chat-message-text skeleton skel-line", style: { width: `${40 + i % 4 * 12}%`, minHeight: `${20 + i % 3 * 8}px` } }),
    /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "chat-message-meta skeleton", children: /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("span", { className: "chat-message-time skel-line skeleton", style: { width: "36px" } }) })
  ] }, i)) });
}
function TopMessageSkeleton() {
  return /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "skeleton-top skeleton-placeholder", "aria-hidden": "true", children: /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "chat-message incoming skeleton-placeholder", children: /* @__PURE__ */ (0, import_jsx_runtime8.jsx)("div", { className: "chat-message-text skeleton skel-line", style: { width: "38%", minHeight: "28px" } }) }) });
}

// client/chat/ui/chat/bubbleData.ts
function replyLabel(m, meId2, otherName) {
  if (m.replyToSenderId !== null) return m.replyToSenderId === meId2 ? "You" : otherName || m.replyToName || "";
  if (m.replyToName === "You") return m.senderId === meId2 ? "You" : otherName || "You";
  return m.replyToName || otherName || "";
}
function fromMessage(m, meId2, otherName, saved = false) {
  const mine = m.senderId === meId2;
  let forwardedFrom = m.forwardedFrom;
  if (forwardedFrom === "You" && !mine && otherName) forwardedFrom = otherName;
  return {
    key: `m${m.id}`,
    id: m.id,
    clientId: m.clientId ?? null,
    mine,
    text: m.text,
    createdAt: m.createdAt,
    isEdited: m.isEdited,
    isPinned: m.isPinned,
    isOneTime: m.isOneTime,
    isTimeCapsule: m.isTimeCapsule,
    isLocked: m.isLocked,
    scheduledFor: m.scheduledFor,
    openedAt: m.openedAt,
    reply: m.replyToId !== null ? { id: m.replyToId, label: replyLabel(m, meId2, otherName), text: m.replyToText ?? "" } : null,
    forwardedFrom,
    reactions: m.reactions,
    status: mine && !saved ? m.isSeen ? "seen" : "sent" : null,
    error: null,
    unseen: !mine && !m.isSeen
  };
}
function fromPending(p, meId2, otherName) {
  return {
    key: `p${p.clientId}`,
    id: null,
    clientId: p.clientId,
    mine: true,
    text: p.text,
    createdAt: p.createdAt,
    isEdited: false,
    isPinned: false,
    isOneTime: p.isOneTime,
    isTimeCapsule: p.isTimeCapsule,
    isLocked: false,
    scheduledFor: p.scheduledFor,
    openedAt: null,
    reply: p.replyTo ? { id: p.replyTo.id, label: p.replyTo.senderId === meId2 ? "You" : otherName, text: p.replyTo.text } : null,
    forwardedFrom: p.forwardedFrom,
    reactions: [],
    status: p.status === "failed" ? "failed" : "pending",
    error: p.error,
    unseen: false
  };
}

// client/chat/ui/chat/MessageBubble.tsx
var import_react10 = __toESM(require_react(), 1);

// client/chat/services/capsules.ts
var MAX = 1e3;
var revealed = null;
function load() {
  if (revealed) return revealed;
  try {
    const v = JSON.parse(read(keys.revealedCapsules) || "[]");
    revealed = Array.isArray(v) ? v.map(String) : [];
  } catch {
    revealed = [];
  }
  return revealed;
}
function isRevealed(messageId) {
  return load().includes(String(messageId));
}
function markRevealed(messageId) {
  const list = load();
  const id = String(messageId);
  if (list.includes(id)) return;
  list.push(id);
  if (list.length > MAX) list.splice(0, list.length - MAX);
  write(keys.revealedCapsules, JSON.stringify(list));
}

// client/chat/ui/chat/MessageBubble.tsx
var import_jsx_runtime9 = __toESM(require_jsx_runtime(), 1);
var LONG_PRESS_MS2 = 500;
var SWIPE_REPLY_PX = 100;
function swallowNextClick() {
  const stop = (e) => {
    e.stopPropagation();
    e.preventDefault();
  };
  window.addEventListener("click", stop, { capture: true, once: true });
  window.setTimeout(() => window.removeEventListener("click", stop, { capture: true }), 600);
}
function MessageText({ text, style, className, plain = false }) {
  return /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("p", { className: `chat-message-text${className ? ` ${className}` : ""}`, dir: "auto", style, children: linkify(text).map(
    (part, i) => part.kind === "link" && plain ? /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "message-link", children: part.text }, i) : part.kind === "link" ? /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("a", { className: "message-link", href: part.href, target: "_blank", rel: "noopener noreferrer nofollow", onClick: (e) => e.stopPropagation(), children: part.text }, i) : part.text
  ) });
}
function Reactions({
  reactions,
  meId: meId2,
  outgoing,
  onReact,
  passive
}) {
  if (reactions.length === 0) return null;
  const counts = /* @__PURE__ */ new Map();
  for (const r of reactions) counts.set(r.emoji, (counts.get(r.emoji) ?? 0) + 1);
  const emojis = [...counts.keys()];
  const multi = emojis.length > 1;
  return /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("div", { className: "reaction-badge-wrap", children: emojis.slice(0, 2).map((emoji) => {
    const count2 = counts.get(emoji) ?? 0;
    const mine = reactions.some((r) => r.userId === meId2 && r.emoji === emoji);
    const others = count2 - (mine ? 1 : 0) > 0;
    let cls = "reaction-badge";
    if (multi) cls += ` single ${mine ? "outgoing-reaction" : "incoming-reaction"}`;
    else if (count2 > 1 && mine && others) cls += outgoing ? " outgoing-reaction" : " incoming-reaction";
    else {
      cls += mine ? " outgoing-reaction" : " incoming-reaction";
      if (count2 === 1 && reactions.length === 1) cls += " single";
    }
    if (passive) {
      return /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("span", { className: cls, children: [
        /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "reaction-badge-emoji", children: emoji }),
        count2 > 1 && /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "reaction-badge-count", children: count2 })
      ] }, emoji);
    }
    return /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)(
      "button",
      {
        type: "button",
        className: cls,
        "aria-label": `${emoji} ${count2}${mine ? ", including you" : ""}`,
        onClick: (e) => {
          e.stopPropagation();
          onReact(emoji);
        },
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "reaction-badge-emoji", children: emoji }),
          count2 > 1 && /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "reaction-badge-count", children: count2 })
        ]
      },
      emoji
    );
  }) });
}
function useCapsuleReveal(data, el, passive) {
  const id = data.id;
  const needs = !passive && !data.mine && data.isTimeCapsule && !data.isLocked && id !== null && !isRevealed(id);
  const [stage, setStage] = (0, import_react10.useState)(null);
  (0, import_react10.useEffect)(() => {
    if (!needs || id === null || !el.current) return void 0;
    const timers = [];
    const run = () => {
      timers.push(window.setTimeout(() => setStage("zoom"), 1e3));
      timers.push(window.setTimeout(() => setStage("fade"), 1500));
      timers.push(
        window.setTimeout(() => {
          markRevealed(id);
          setStage(null);
        }, 1900)
      );
    };
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting) && document.visibilityState === "visible") {
          io.disconnect();
          run();
        }
      },
      { threshold: 0.2 }
    );
    io.observe(el.current);
    return () => {
      io.disconnect();
      timers.forEach((t) => window.clearTimeout(t));
    };
  }, [needs, id, el]);
  return needs ? stage ?? "locked" : "done";
}
var MessageBubble = (0, import_react10.memo)(function MessageBubble2({
  data,
  meId: meId2,
  selecting,
  selected,
  fading,
  vanishing: vanishing2,
  highlighted,
  canReply,
  handlers: handlers2,
  passive = false
}) {
  const el = (0, import_react10.useRef)(null);
  const [swipeX, setSwipeX] = (0, import_react10.useState)(0);
  const [failedOpen, setFailedOpen] = (0, import_react10.useState)(false);
  const gesture = (0, import_react10.useRef)(null);
  const suppressClick = useClickSuppressor();
  const reveal = useCapsuleReveal(data, el, passive);
  const lockedView = data.isTimeCapsule && data.isLocked && !data.mine || reveal === "locked" || reveal === "zoom" || reveal === "fade";
  const pending3 = data.status === "pending";
  const failed = data.status === "failed";
  const interactive = data.id !== null && !passive;
  (0, import_react10.useEffect)(() => {
    if (!failed) setFailedOpen(false);
  }, [failed]);
  const clearTimer = () => {
    const g = gesture.current;
    if (g?.timer !== null && g?.timer !== void 0) window.clearTimeout(g.timer);
    if (g) g.timer = null;
  };
  const onPointerDown = (e) => {
    if (e.pointerType === "mouse" || !interactive) return;
    const target = e.currentTarget;
    gesture.current = {
      id: e.pointerId,
      x: e.clientX,
      y: e.clientY,
      swiping: false,
      menuOpened: false,
      timer: selecting ? null : window.setTimeout(() => {
        const g = gesture.current;
        if (!g || g.swiping) return;
        g.menuOpened = true;
        g.timer = null;
        handlers2.onMenu(data, target);
      }, LONG_PRESS_MS2)
    };
  };
  const onPointerMove = (e) => {
    const g = gesture.current;
    if (!g || g.id !== e.pointerId) return;
    const dx = e.clientX - g.x;
    const dy = e.clientY - g.y;
    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) clearTimer();
    if (g.menuOpened || selecting || !canReply) return;
    if (!g.swiping) {
      if (dx > 10 && Math.abs(dx) > Math.abs(dy)) {
        g.swiping = true;
        e.currentTarget.setPointerCapture(e.pointerId);
      } else return;
    }
    setSwipeX(Math.max(0, dx));
  };
  const onPointerEnd = (e) => {
    const g = gesture.current;
    if (!g || g.id !== e.pointerId) return;
    clearTimer();
    gesture.current = null;
    if (g.menuOpened) swallowNextClick();
    if (g.swiping) {
      suppressClick.arm();
      const dx = e.clientX - g.x;
      setSwipeX(0);
      if (dx >= SWIPE_REPLY_PX && e.type === "pointerup") handlers2.onReply(data);
    }
  };
  const onClick = () => {
    if (suppressClick.consume()) return;
    if (selecting && interactive) handlers2.onToggle(data);
  };
  const onContextMenu = (e) => {
    e.preventDefault();
    if (gesture.current?.menuOpened || suppressClick.consume()) return;
    if (!interactive || selecting) return;
    handlers2.onMenu(data, e.currentTarget);
  };
  const progress = Math.min(swipeX / SWIPE_REPLY_PX, 1);
  const classes = [
    "chat-message",
    data.mine ? "outgoing" : "incoming",
    pending3 && "pending",
    failed && "failed",
    data.isOneTime && "onetime-message",
    lockedView && "capsule-locked",
    selected && "selected",
    data.reactions.length > 0 && "has-reaction",
    highlighted && (data.mine ? "highlight-outgoing-reply" : "highlight-incoming-reply"),
    fading && "fading-slow",
    vanishing2 && "vanishing"
  ].filter(Boolean).join(" ");
  const style = {};
  if (swipeX) style.translate = `${Math.min(swipeX * 0.4, SWIPE_REPLY_PX * 0.4)}px 0`;
  if (fading) style.opacity = 0;
  const time = clock(data.createdAt);
  const pinIcon = data.isPinned ? /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "chat-pinned-icon", children: /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(Icons.PinSolid, {}) }) : null;
  const edited = data.isEdited ? /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "chat-edited-label", children: "edited" }) : null;
  return /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)(
    "div",
    {
      ref: el,
      className: classes,
      style,
      "data-message-id": data.id ?? void 0,
      tabIndex: interactive ? -1 : void 0,
      "data-unseen": data.unseen ? "true" : void 0,
      onPointerDown,
      onPointerMove,
      onPointerUp: onPointerEnd,
      onPointerCancel: onPointerEnd,
      onClick,
      onContextMenu,
      children: [
        data.reply && /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)(
          "div",
          {
            className: "chat-reply",
            role: interactive ? "button" : void 0,
            tabIndex: interactive ? 0 : void 0,
            "aria-label": interactive ? `Go to the quoted message from ${data.reply.label}` : void 0,
            onClick: (e) => {
              if (selecting) return;
              e.stopPropagation();
              if (data.reply) handlers2.onQuote(data.reply.id);
            },
            onKeyDown: (e) => {
              if (!interactive || selecting || e.key !== "Enter" && e.key !== " ") return;
              e.preventDefault();
              e.stopPropagation();
              if (data.reply) handlers2.onQuote(data.reply.id);
            },
            children: [
              /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "chat-reply-sender", children: data.reply.label }),
              /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "chat-reply-text", dir: "auto", children: data.reply.text })
            ]
          }
        ),
        data.forwardedFrom && /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("div", { className: "chat-forwarded-label", children: [
          "Forwarded from ",
          data.forwardedFrom
        ] }),
        data.isTimeCapsule && data.mine && /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("div", { className: "capsule-sender-label", children: [
          /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "capsule-sender-icon", children: data.openedAt ? /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(Icons.CapsuleUnlock, {}) : /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(Icons.CapsuleLock, {}) }),
          /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "capsule-sender-text", children: data.openedAt ? "Opened" : data.scheduledFor ? `Unlocks ${dateAtTime(data.scheduledFor)}` : "Time Capsule" })
        ] }),
        lockedView ? /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(
          MessageText,
          {
            text: data.text ?? "",
            style: reveal === "fade" ? void 0 : { filter: "blur(7px)", opacity: 0.18, userSelect: "none", pointerEvents: "none" },
            className: reveal === "fade" ? "capsule-reveal" : void 0
          }
        ) : /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(MessageText, { text: data.text ?? "", plain: passive }),
        /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("span", { className: "chat-message-meta", children: [
          data.mine && pinIcon,
          data.mine && edited,
          data.isOneTime && /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "chat-onetime-meta", children: /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(Icons.OneTime, {}) }),
          /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "chat-message-time", children: time }),
          !data.mine && edited,
          data.mine && (pending3 ? /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "chat-message-status", children: /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(Icons.Spinner, { className: "msg-pending-spinner" }) }) : failed ? /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(
            "button",
            {
              type: "button",
              className: "msg-failed-btn",
              "aria-label": "Not sent: options",
              onClick: (e) => {
                e.stopPropagation();
                setFailedOpen((v) => !v);
              },
              children: /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(Icons.Failed, {})
            }
          ) : /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("span", { className: "chat-message-status", children: data.status === "seen" ? /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(Icons.Seen, {}) : /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(Icons.Sent, {}) })),
          !data.mine && pinIcon
        ] }),
        lockedView && /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)(import_jsx_runtime9.Fragment, { children: [
          /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("div", { className: `capsule-lines${reveal === "fade" ? " capsule-fading" : ""}`, children: [82, 65, 90, 50].map((w) => /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("div", { className: "capsule-line", style: { width: `${w}%` } }, w)) }),
          /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("div", { className: `capsule-center${reveal === "fade" ? " capsule-fading" : ""}`, children: [
            /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("div", { className: `capsule-lock-icon${reveal === "zoom" || reveal === "fade" ? " capsule-zoom" : ""}`, children: reveal === "fade" ? /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(Icons.CapsuleUnlock, {}) : /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(Icons.CapsuleLock, {}) }),
            /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("div", { className: "capsule-unlock-time", children: data.scheduledFor ? `Opens ${dateAtTime(data.scheduledFor)}` : "" })
          ] })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(Reactions, { reactions: data.reactions, meId: meId2, outgoing: data.mine, passive, onReact: (emoji) => handlers2.onReact(data, emoji) }),
        swipeX > 0 && /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("div", { className: `swipe-reply-icon visible${progress >= 1 ? " bounce" : ""}`, style: { opacity: progress }, children: /* @__PURE__ */ (0, import_jsx_runtime9.jsx)(Icons.ReplyArrow, {}) }),
        failed && failedOpen && /* @__PURE__ */ (0, import_jsx_runtime9.jsxs)("div", { className: "msg-failed-panel", role: "menu", onClick: (e) => e.stopPropagation(), children: [
          data.error && /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("p", { className: "msg-failed-reason", children: data.error }),
          /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("button", { type: "button", className: "retry-btn", role: "menuitem", onClick: () => handlers2.onRetry(data), children: "Retry" }),
          /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("button", { type: "button", role: "menuitem", onClick: () => handlers2.onCopy(data), children: "Copy" }),
          /* @__PURE__ */ (0, import_jsx_runtime9.jsx)("button", { type: "button", className: "delete-btn", role: "menuitem", onClick: () => handlers2.onDiscard(data), children: "Delete" })
        ] })
      ]
    }
  );
});

// client/chat/ui/chat/MessageList.tsx
var import_jsx_runtime10 = __toESM(require_jsx_runtime(), 1);
var NEAR_BOTTOM_PX = 80;
var SHOW_DOWN_BUTTON_PX = 300;
function MessageList({ convId, row, composer, onPinnedInView, pinnedIds, scrollDownRef, onShowDownButton }) {
  const cache2 = useStore(chats, (s) => s[convId] ?? null);
  const box = useStore(outbox, (s) => s);
  const hidden = useStore(undoing, (s) => s.messages);
  const clearing = useStore(undoing, (s) => !!s.clearedChats[convId]);
  const fadingOut = useStore(vanishing, (s) => s);
  const selection = useUi((s) => s.selection?.conversationId === convId ? s.selection.ids : null);
  const focus = useUi((s) => s.focus?.conversationId === convId ? s.focus : null);
  const connected = useStore(connection, (s) => s.status === "online");
  const pageVisible2 = usePageVisible();
  const meId2 = useMeId();
  const otherName = row.isSaved ? "" : displayName(row);
  const ready = cache2?.status === "ready";
  const messages = cache2?.messages;
  const pending3 = (0, import_react11.useMemo)(
    () => Object.values(box).filter((p) => p.conversationId === convId).sort((a, b) => a.createdAt < b.createdAt ? -1 : a.createdAt > b.createdAt ? 1 : 0),
    [box, convId]
  );
  const [anchorId, setAnchorId] = (0, import_react11.useState)(void 0);
  if (ready && messages && anchorId === void 0) setAnchorId(messages.find((m) => m.senderId !== meId2 && !m.isSeen)?.id ?? null);
  if (ready && messages && typeof anchorId === "number" && messages[0] && messages[0].id < anchorId) {
    const first = messages.find((m) => m.senderId !== meId2 && !m.isSeen);
    if (first && first.id < anchorId) setAnchorId(first.id);
  }
  (0, import_react11.useEffect)(() => {
    if (anchorId !== null || pageVisible2 || !messages) return;
    const first = messages.find((m) => m.senderId !== meId2 && !m.isSeen);
    if (first) setAnchorId(first.id);
  }, [anchorId, pageVisible2, messages, meId2]);
  const bubbleCache = (0, import_react11.useRef)(/* @__PURE__ */ new WeakMap());
  const items = (0, import_react11.useMemo)(() => {
    const out = [];
    const sig = `${meId2}|${otherName}|${row.isSaved}`;
    const bubbleOf = (m) => {
      const hit = bubbleCache.current.get(m);
      if (hit && hit.sig === sig) return hit.data;
      const data = fromMessage(m, meId2, otherName, row.isSaved);
      bubbleCache.current.set(m, { sig, data });
      return data;
    };
    if (!messages || clearing) return out;
    let lastDay = "";
    const push = (data) => {
      const day = dayKey(data.createdAt);
      if (day !== lastDay) {
        out.push({ kind: "day", key: `d${day}`, label: dayLabel(day) });
        lastDay = day;
      }
      if (data.id !== null && data.id === anchorId) out.push({ kind: "unread", key: "unread" });
      out.push({ kind: "msg", key: data.key, data });
    };
    for (const m of messages) push(bubbleOf(m));
    for (const p of pending3) push(fromPending(p, meId2, otherName));
    return out;
  }, [messages, pending3, meId2, otherName, anchorId, clearing, row.isSaved]);
  const byId = (0, import_react11.useMemo)(() => new Map((messages ?? []).map((m) => [m.id, m])), [messages]);
  const lastKey = items.length ? items[items.length - 1].key : null;
  const lastMine = (() => {
    for (let i = items.length - 1; i >= 0; i--) {
      const it = items[i];
      if (it.kind === "msg") return it.data.mine;
    }
    return false;
  })();
  const scroller = (0, import_react11.useRef)(null);
  const positioned = (0, import_react11.useRef)(false);
  const positionedAt = (0, import_react11.useRef)(0);
  const snap = (0, import_react11.useRef)({ firstId: null, firstTop: null, lastKey: null, top: 0, atBottom: true });
  const [showDown, setShowDown] = (0, import_react11.useState)(false);
  const contentTop = (el, id) => {
    if (id === null) return null;
    const node = el.querySelector(`[data-message-id="${id}"]`);
    return node ? node.getBoundingClientRect().top - el.getBoundingClientRect().top + el.scrollTop : null;
  };
  const measure = () => {
    const el = scroller.current;
    if (!el) return;
    const fromBottom = el.scrollHeight - el.scrollTop - el.clientHeight;
    const first = el.querySelector(".chat-message[data-message-id]");
    const firstId = first ? Number(first.dataset.messageId) : null;
    snap.current = {
      firstId,
      firstTop: contentTop(el, firstId),
      lastKey,
      top: el.scrollTop,
      atBottom: fromBottom < NEAR_BOTTOM_PX
    };
    const down = fromBottom > SHOW_DOWN_BUTTON_PX;
    setShowDown((v) => v === down ? v : down);
  };
  const toBottom = (smooth = false) => {
    const el = scroller.current;
    if (!el) return;
    el.scrollTo({ top: el.scrollHeight, behavior: smooth ? "smooth" : "instant" });
  };
  (0, import_react11.useLayoutEffect)(() => {
    const el = scroller.current;
    if (!el || !ready) return;
    if (!positioned.current) {
      if (anchorId === void 0) return;
      const sep = el.querySelector(".unread-separator");
      if (sep) {
        const inset = parseFloat(getComputedStyle(el).paddingTop) || 0;
        const top = sep.getBoundingClientRect().top - el.getBoundingClientRect().top + el.scrollTop - inset;
        el.scrollTop = Math.min(top, el.scrollHeight - el.clientHeight);
      } else {
        el.scrollTop = el.scrollHeight;
      }
      positioned.current = true;
      positionedAt.current = Date.now();
    } else {
      const prev = snap.current;
      if (prev.lastKey !== lastKey && lastMine) {
        el.scrollTop = el.scrollHeight;
      } else if (prev.atBottom) {
        el.scrollTop = el.scrollHeight;
      } else {
        const now = contentTop(el, prev.firstId);
        if (now !== null && prev.firstTop !== null && now !== prev.firstTop) el.scrollTop = prev.top + (now - prev.firstTop);
      }
    }
    measure();
  });
  (0, import_react11.useEffect)(() => {
    scrollDownRef.current = () => toBottom(true);
    return () => {
      scrollDownRef.current = null;
    };
  });
  (0, import_react11.useEffect)(() => onShowDownButton(showDown), [showDown, onShowDownButton]);
  const measureLatest = useEvent(measure);
  (0, import_react11.useLayoutEffect)(() => {
    const box2 = composer;
    const el = scroller.current;
    if (!box2 || !el) return void 0;
    const apply = () => {
      const atBottom = snap.current.atBottom;
      const gap = parseFloat(getComputedStyle(document.documentElement).fontSize) * 0.5;
      el.style.paddingBottom = `${box2.offsetHeight + gap * 2}px`;
      if (atBottom) el.scrollTop = el.scrollHeight;
      measureLatest();
    };
    apply();
    const ro = new ResizeObserver(apply);
    ro.observe(box2);
    return () => ro.disconnect();
  }, [composer, ready, measureLatest]);
  const sayHello = () => {
    if (blocked || selecting || getComposer(convId).draft.trim()) return;
    sendText(convId, "hi");
  };
  const onListKey = (e) => {
    const list = scroller.current;
    if (!list) return;
    const all = [...list.querySelectorAll(".chat-message[data-message-id]")];
    if (all.length === 0) return;
    const current = e.target.closest(".chat-message[data-message-id]");
    const at = current ? all.indexOf(current) : -1;
    let next;
    if (e.key === "ArrowUp") next = at < 0 ? all[all.length - 1] : all[at - 1];
    else if (e.key === "ArrowDown") next = at < 0 ? all[all.length - 1] : all[at + 1];
    else if (e.key === "Home") next = all[0];
    else if (e.key === "End") next = all[all.length - 1];
    else if (current && (e.key === "Enter" && e.target === current || e.key === "ContextMenu" || e.key === "F10" && e.shiftKey)) {
      e.preventDefault();
      current.dispatchEvent(new MouseEvent("contextmenu", { bubbles: true, cancelable: true }));
      return;
    } else if (current && e.key === " " && selecting && e.target === current) {
      e.preventDefault();
      current.click();
      return;
    } else return;
    e.preventDefault();
    if (!next) return;
    next.focus({ preventScroll: true });
    next.scrollIntoView({ block: "nearest" });
  };
  const onScroll = () => {
    const el = scroller.current;
    if (!el) return;
    measure();
    if (positioned.current && Date.now() - positionedAt.current > 400 && el.scrollTop < Math.min(200, el.scrollHeight * 0.15)) {
      void loadOlder(convId);
    }
    reportPinned();
  };
  const reportPinned = useEvent(() => {
    const el = scroller.current;
    if (!el || pinnedIds.length === 0) return;
    const box2 = el.getBoundingClientRect();
    for (let i = pinnedIds.length - 1; i >= 0; i--) {
      const node = el.querySelector(`[data-message-id="${pinnedIds[i]}"]`);
      if (!node) continue;
      const r = node.getBoundingClientRect();
      if (r.bottom >= box2.top && r.top <= box2.bottom) {
        onPinnedInView(pinnedIds[i]);
        return;
      }
    }
  });
  const markVisible = useEvent(() => {
    const el = scroller.current;
    if (!el || document.visibilityState !== "visible") return;
    const box2 = el.getBoundingClientRect();
    let newest = 0;
    el.querySelectorAll('[data-unseen="true"]').forEach((node) => {
      const r = node.getBoundingClientRect();
      if (r.bottom > box2.top + 4 && r.top < box2.bottom - (composer?.offsetHeight ?? 0)) {
        const id = Number(node.dataset.messageId);
        if (id > newest) newest = id;
      }
    });
    if (newest) sawMessage(convId, newest);
  });
  (0, import_react11.useEffect)(() => {
    const el = scroller.current;
    if (!el || !ready) return void 0;
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) markVisible();
      },
      { root: el, threshold: 0.6 }
    );
    el.querySelectorAll('[data-unseen="true"]').forEach((n) => io.observe(n));
    return () => io.disconnect();
  }, [items, ready, markVisible]);
  (0, import_react11.useEffect)(() => {
    if (pageVisible2 && connected && ready) {
      const t = window.setTimeout(markVisible, 400);
      return () => window.clearTimeout(t);
    }
    return void 0;
  }, [pageVisible2, connected, ready, markVisible]);
  const [highlighted, setHighlighted] = (0, import_react11.useState)(null);
  const byIdRef = (0, import_react11.useRef)(byId);
  byIdRef.current = byId;
  (0, import_react11.useEffect)(() => {
    if (!focus || !ready) return void 0;
    let alive = true;
    void (async () => {
      const found = byIdRef.current.get(focus.messageId) ?? await loadUntil(convId, focus.messageId);
      if (!alive) return;
      if (!found) {
        showToast("This message is no longer available");
        return;
      }
      requestAnimationFrame(() => {
        const node = scroller.current?.querySelector(`[data-message-id="${focus.messageId}"]`);
        if (!node) return;
        node.scrollIntoView({ block: "center", behavior: "smooth" });
        setHighlighted(focus.messageId);
        window.setTimeout(() => setHighlighted((h) => h === focus.messageId ? null : h), 500);
      });
    })();
    return () => {
      alive = false;
    };
  }, [focus?.seq, ready, convId]);
  const handlers2 = (0, import_react11.useMemo)(() => {
    const live = (data) => data.id !== null ? byIdRef.current.get(data.id) ?? null : null;
    return {
      onMenu: (data, el) => {
        if (data.id === null) return;
        const r = el.getBoundingClientRect();
        openMenu(convId, data.id, r.left, r.top);
      },
      onReply: (data) => {
        const m = live(data);
        if (m) startReply(convId, m);
      },
      onToggle: (data) => {
        if (data.id !== null) toggleSelected(data.id);
      },
      onQuote: (id) => {
        ui.set((s) => ({ ...s, focus: { conversationId: convId, messageId: id, seq: Date.now() } }));
      },
      onReact: (data, emoji) => {
        const m = live(data);
        if (m) void react(convId, m, emoji);
      },
      onRetry: (data) => data.clientId && retry(data.clientId),
      onDiscard: (data) => data.clientId && discard(data.clientId),
      onCopy: (data) => data.text && void copyText(data.text)
    };
  }, [convId]);
  const selecting = selection !== null;
  const blocked = row.isBlocked || isDeletedAccount(row);
  const empty2 = ready && items.length === 0;
  return /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(
    "div",
    {
      ref: scroller,
      className: `chat${selecting ? " selection-mode" : ""}`,
      onScroll,
      role: "log",
      "aria-label": "Messages",
      tabIndex: 0,
      "aria-keyshortcuts": "ArrowUp ArrowDown Enter",
      onKeyDown: onListKey,
      children: [
        cache2?.loadingOlder && /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(TopMessageSkeleton, {}),
        !ready && cache2?.status !== "error" && /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(MessageSkeletons, {}),
        cache2?.status === "error" && cache2.messages.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)("button", { type: "button", className: "chat-empty chat-load-error", onClick: () => void prepareChat(convId).catch(() => void 0), children: [
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(Icons.ChatBubble, {}),
          /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { className: "chat-empty-text", children: "Couldn't load the messages. Tap to try again." })
        ] }),
        items.map(
          (it) => it.kind === "day" ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "date-separator", children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { children: it.label }) }, it.key) : it.kind === "unread" ? /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("div", { className: "unread-separator", role: "separator", "aria-label": "Unread messages", children: /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("span", { children: "Unread messages" }) }, it.key) : /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(
            MessageBubble,
            {
              data: it.data,
              meId: meId2,
              selecting,
              selected: !!(selection && it.data.id !== null && selection.includes(it.data.id)),
              fading: it.data.id !== null && !!hidden[it.data.id],
              vanishing: it.data.id !== null && !!fadingOut[it.data.id],
              highlighted: highlighted !== null && it.data.id === highlighted,
              canReply: !selecting && !blocked && it.data.id !== null && !(!it.data.mine && (it.data.isLocked || it.data.isOneTime)),
              handlers: handlers2
            },
            it.key
          )
        ),
        empty2 && /* @__PURE__ */ (0, import_jsx_runtime10.jsxs)(
          "div",
          {
            className: "chat-empty",
            role: "button",
            tabIndex: 0,
            onClick: sayHello,
            onKeyDown: (e) => {
              if (e.key !== "Enter" && e.key !== " ") return;
              e.preventDefault();
              e.stopPropagation();
              sayHello();
            },
            children: [
              /* @__PURE__ */ (0, import_jsx_runtime10.jsx)(Icons.ChatBubble, {}),
              /* @__PURE__ */ (0, import_jsx_runtime10.jsx)("p", { className: "chat-empty-text", children: "Say hello!" })
            ]
          }
        )
      ]
    }
  );
}

// client/chat/ui/chat/MessageMenu.tsx
var import_react12 = __toESM(require_react(), 1);
var import_jsx_runtime11 = __toESM(require_jsx_runtime(), 1);
var REACTIONS = ["\u{1F44D}", "\u2764\uFE0F", "\u{1F602}", "\u{1F62E}", "\u{1F622}", "\u{1F525}"];
var BAR_GAP = 10;
var MENU_GAP = 5;
var EDGE = 8;
function MessageMenu({ row, message, meId: meId2, scroller }) {
  const bar = (0, import_react12.useRef)(null);
  const menu = (0, import_react12.useRef)(null);
  const [layout, setLayout] = (0, import_react12.useState)(null);
  const [shown, setShown] = (0, import_react12.useState)(false);
  const openedAt = (0, import_react12.useRef)(Date.now());
  const convId = row.conversationId;
  const mine = message.senderId === meId2;
  const sealed = message.isTimeCapsule && !message.openedAt;
  const hiddenContent = !mine && (message.isLocked || message.isOneTime);
  const cannotSend = row.isBlocked || isDeletedAccount(row);
  const canEdit = mine && !message.forwardedFrom && !message.isOneTime && !sealed;
  const canPin = !(message.isLocked && !mine);
  (0, import_react12.useLayoutEffect)(() => {
    const bubble = scroller?.querySelector(`[data-message-id="${message.id}"]`);
    const barEl = bar.current;
    const menuEl = menu.current;
    if (!bubble || !menuEl) {
      closeMenu();
      return void 0;
    }
    const r = bubble.getBoundingClientRect();
    const vh = window.innerHeight;
    const vw = window.innerWidth;
    const menuH = menuEl.offsetHeight;
    const barH = barEl?.offsetHeight ?? 0;
    let lift = 0;
    let menuTop = r.bottom + MENU_GAP;
    if (vh - r.bottom < menuH + EDGE * 3) {
      lift = menuH + r.bottom - vh + EDGE * 3;
      if (r.top - lift - barH - BAR_GAP < EDGE) lift = Math.max(0, r.top - barH - BAR_GAP - EDGE);
      menuTop = Math.min(r.bottom - lift + MENU_GAP, vh - menuH - EDGE);
    }
    const side = mine ? { right: Math.max(EDGE, vw - r.right), left: "auto" } : { left: Math.max(EDGE, r.left), right: "auto" };
    setLayout({
      lift,
      bar: { top: Math.max(EDGE, r.top - lift - barH - BAR_GAP), ...side },
      menu: { top: menuTop, ...side }
    });
    bubble.style.zIndex = "500";
    bubble.style.transform = lift ? `translateY(-${lift}px)` : "";
    const t = window.setTimeout(() => setShown(true), 100);
    return () => {
      window.clearTimeout(t);
      bubble.style.zIndex = "";
      bubble.style.transform = "";
    };
  }, [message.id, mine, scroller]);
  (0, import_react12.useEffect)(() => {
    const stop = (e) => {
      if (menu.current?.contains(e.target)) return;
      e.preventDefault();
    };
    document.addEventListener("wheel", stop, { passive: false, capture: true });
    document.addEventListener("touchmove", stop, { passive: false, capture: true });
    return () => {
      document.removeEventListener("wheel", stop, { capture: true });
      document.removeEventListener("touchmove", stop, { capture: true });
    };
  }, []);
  (0, import_react12.useEffect)(() => {
    if (!shown) return void 0;
    const items2 = () => [...menu.current?.querySelectorAll("[role=menuitem]") ?? []];
    const before = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    items2()[0]?.focus({ preventScroll: true });
    const onKey = (e) => {
      if (e.key === "Escape") {
        e.preventDefault();
        closeMenu();
        return;
      }
      if (e.key !== "ArrowDown" && e.key !== "ArrowUp" && e.key !== "Home" && e.key !== "End") return;
      const list = items2();
      if (list.length === 0) return;
      e.preventDefault();
      const at = list.indexOf(document.activeElement);
      const next = e.key === "Home" ? 0 : e.key === "End" ? list.length - 1 : e.key === "ArrowDown" ? (at + 1) % list.length : (at - 1 + list.length) % list.length;
      list[next]?.focus({ preventScroll: true });
    };
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("keydown", onKey);
      const now = document.activeElement;
      if (before?.isConnected && (!now || now === document.body || menu.current?.contains(now))) before.focus({ preventScroll: true });
    };
  }, [shown]);
  const run = (fn) => () => {
    closeMenu();
    fn();
  };
  const items = [];
  if (!hiddenContent && !cannotSend) items.push({ key: "reply", label: "Reply", icon: /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(Icons.Reply, {}), onClick: run(() => startReply(convId, message)) });
  if (!hiddenContent) {
    items.push({
      key: "forward",
      label: "Forward",
      icon: /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(Icons.Forward, {}),
      onClick: run(() => {
        ui.set((s) => ({ ...s, forwarding: { items: [forwardSource(convId, message)], fromName: mine || row.isSaved ? "You" : displayName(row) } }));
        openDialog("forward");
      })
    });
    items.push({ key: "copy", label: "Copy", icon: /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(Icons.Copy, {}), onClick: run(() => void copyText(message.text ?? "")) });
  }
  if (canEdit) items.push({ key: "edit", label: "Edit", icon: /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(Icons.Edit, {}), onClick: run(() => startEdit(convId, message)) });
  if (canPin)
    items.push({
      key: "pin",
      label: message.isPinned ? "Unpin" : "Pin",
      icon: /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("span", { className: "pin-icon", children: message.isPinned ? /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(Icons.Unpin, {}) : /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(Icons.Pin, {}) }),
      onClick: () => void togglePin(convId, message)
    });
  items.push({ key: "select", label: "Select Message", icon: /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(Icons.Select, {}), onClick: run(() => startSelection(convId, message.id)) });
  if (mine) items.push({ key: "delete", label: "Delete Message", icon: /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(Icons.Delete, {}), onClick: run(() => deleteMessages(convId, [message.id])), danger: true });
  const hidden = layout ? {} : { visibility: "hidden" };
  return /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)(import_jsx_runtime11.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime11.jsx)(
      "div",
      {
        className: "chat-overlay visible",
        onClick: () => {
          if (Date.now() - openedAt.current > 350) closeMenu();
        }
      }
    ),
    !cannotSend && /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("div", { ref: bar, className: "reaction-bar", style: { display: "flex", ...hidden, ...layout?.bar }, role: "toolbar", "aria-label": "Reactions", children: REACTIONS.map((emoji) => /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("button", { type: "button", className: "reaction-bar-btn", "aria-label": `React ${emoji}`, onClick: run(() => void react(convId, message, emoji)), children: emoji }, emoji)) }),
    /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("div", { ref: menu, className: `message-menu${shown ? " visible" : ""}`, style: { display: "block", ...hidden, ...layout?.menu }, role: "menu", children: /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("ul", { children: items.map((it) => /* @__PURE__ */ (0, import_jsx_runtime11.jsxs)(
      "li",
      {
        className: `${it.key}-message${it.danger ? " delete-message" : ""}`,
        role: "menuitem",
        tabIndex: -1,
        onClick: it.onClick,
        onKeyDown: (e) => {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            it.onClick();
          }
        },
        children: [
          it.icon,
          /* @__PURE__ */ (0, import_jsx_runtime11.jsx)("p", { children: it.label })
        ]
      },
      it.key
    )) }) })
  ] });
}

// client/chat/ui/chat/PinnedBar.tsx
var import_jsx_runtime12 = __toESM(require_jsx_runtime(), 1);
function pinnedText(p) {
  return p.text === null ? LOCKED_CAPSULE_PREVIEW : p.text.replace(/\s+/g, " ").trim();
}
function activeBar(pos, total) {
  if (total <= 3) return pos;
  if (pos === 0) return 0;
  if (pos === total - 1) return 2;
  return 1;
}
function PinnedBar({
  pinned,
  currentId,
  onJump,
  onOpenList
}) {
  if (pinned.length === 0) return null;
  let pos = currentId === null ? -1 : pinned.findIndex((p) => p.id === currentId);
  if (pos < 0) pos = pinned.length - 1;
  const current = pinned[pos];
  const bars = Math.min(pinned.length, 3);
  const active = activeBar(pos, pinned.length);
  const jump = () => onJump(current, pinned[(pos - 1 + pinned.length) % pinned.length]);
  return /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("div", { className: "pinned-message-container", onClick: jump, children: [
    /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("div", { className: "pinned-message-count", "aria-hidden": "true", children: Array.from({ length: bars }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("span", { className: `pinned-dot-bar${i === active ? " active" : ""}` }, i)) }),
    /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)("div", { className: "pinned-message", children: [
      /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("span", { className: "pinned-label", children: "Pinned Message" }),
      /* @__PURE__ */ (0, import_jsx_runtime12.jsx)("p", { className: "pinned-message-text", dir: "auto", children: pinnedText(current) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime12.jsxs)(
      "button",
      {
        type: "button",
        className: "visually-hidden",
        onClick: (e) => {
          e.stopPropagation();
          jump();
        },
        children: [
          "Go to pinned message: ",
          pinnedText(current)
        ]
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(
      "button",
      {
        type: "button",
        className: "pinned-message-icon",
        "aria-label": "All pinned messages",
        onClick: (e) => {
          e.stopPropagation();
          onOpenList();
        },
        children: /* @__PURE__ */ (0, import_jsx_runtime12.jsx)(Icons.Pin, {})
      }
    )
  ] });
}

// client/chat/ui/chat/PinnedViewDialog.tsx
var import_jsx_runtime13 = __toESM(require_jsx_runtime(), 1);
function PinnedViewDialog({ row, pinned, meId: meId2 }) {
  const newestFirst = [...pinned].reverse();
  return /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(Dialog, { className: "pinned-view-dialog", onClose: closeDialog, label: "Pinned messages", children: [
    /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("div", { className: "pinned-view-header", children: [
      /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("span", { className: "pinned-view-title", children: "Pinned Messages" }),
      /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("button", { type: "button", className: "pinned-view-close", "aria-label": "Close", onClick: closeDialog, children: /* @__PURE__ */ (0, import_jsx_runtime13.jsx)(Icons.Close, {}) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("div", { className: "pinned-view-list", children: newestFirst.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("p", { className: "pinned-view-empty", children: "No pinned messages" }) : newestFirst.map((p) => /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)(
      "button",
      {
        type: "button",
        className: "pinned-view-item",
        onClick: () => {
          closeDialog();
          focusMessage(row.conversationId, p.id);
        },
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime13.jsxs)("div", { className: "pinned-view-item-meta", children: [
            /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("span", { className: "pinned-view-item-sender", children: p.senderId === meId2 ? "You" : displayName(row) }),
            /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("span", { className: "pinned-view-item-time", children: clock(p.createdAt) })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime13.jsx)("p", { className: "pinned-view-item-text", dir: "auto", children: pinnedText(p) })
        ]
      },
      p.id
    )) })
  ] });
}

// client/chat/ui/chat/SelectionToolbar.tsx
var import_jsx_runtime14 = __toESM(require_jsx_runtime(), 1);
function SelectionToolbar({
  row,
  selected,
  meId: meId2,
  refCallback
}) {
  const convId = row.conversationId;
  const allMine = selected.length > 0 && selected.every((m) => m.senderId === meId2);
  const forward = () => {
    const items = selected.filter((m) => m.senderId === meId2 || !m.isLocked && !m.isOneTime).map((m) => forwardSource(convId, m));
    if (items.length === 0) {
      cancelSelection();
      showToast("These messages can't be forwarded", { icon: "error" });
      return;
    }
    ui.set((s) => ({ ...s, forwarding: { items, fromName: row.isSaved ? "You" : displayName(row) || "Unknown" } }));
    openDialog("forward");
  };
  const remove = () => {
    if (!allMine) {
      showToast("You can only delete your own messages", { icon: "error" });
      cancelSelection();
      return;
    }
    const ids = selected.map((m) => m.id);
    cancelSelection();
    deleteMessages(convId, ids);
  };
  return /* @__PURE__ */ (0, import_jsx_runtime14.jsxs)("div", { ref: refCallback, className: "selection-toolbar", role: "toolbar", "aria-label": "Selected messages", children: [
    /* @__PURE__ */ (0, import_jsx_runtime14.jsxs)("p", { className: "selection-count", "aria-live": "polite", children: [
      selected.length,
      " selected"
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime14.jsxs)("div", { className: "selection-actions", children: [
      /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("button", { type: "button", className: "selection-forward-btn", "aria-label": "Forward", onClick: forward, children: /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(Icons.Forward, {}) }),
      allMine && /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("button", { type: "button", className: "selection-delete-btn", "aria-label": "Delete", onClick: remove, children: /* @__PURE__ */ (0, import_jsx_runtime14.jsx)(Icons.Delete, {}) }),
      /* @__PURE__ */ (0, import_jsx_runtime14.jsx)("button", { type: "button", className: "cancel-selection-btn", onClick: cancelSelection, children: "Cancel" })
    ] })
  ] });
}

// client/chat/ui/refs.ts
var import_react13 = __toESM(require_react(), 1);
var searchResultsRef = (0, import_react13.createRef)();
var bottomBarRef = { current: null };

// client/chat/ui/chat/ChatPart.tsx
var import_jsx_runtime15 = __toESM(require_jsx_runtime(), 1);
var NO_PINS = [];
function ChatView({ convId }) {
  const row = useRow(convId);
  const meId2 = useMeId();
  const dark = useIsDark();
  const pinned = useStore(chats, (s) => s[convId]?.pinned ?? NO_PINS);
  const messages = useStore(chats, (s) => s[convId]?.messages);
  const selection = useUi((s) => s.selection?.conversationId === convId ? s.selection.ids : null);
  const menu = useUi((s) => s.menu?.conversationId === convId ? s.menu : null);
  const dialog = useUi((s) => s.dialog);
  const [bottomEl, setBottomElState] = (0, import_react14.useState)(null);
  const setBottomEl = (0, import_react14.useCallback)((el) => {
    bottomBarRef.current = el;
    setBottomElState(el);
  }, []);
  const [scrollerEl, setScrollerEl] = (0, import_react14.useState)(null);
  const [pinnedCurrent, setPinnedCurrent] = (0, import_react14.useState)(null);
  const [showDown, setShowDown] = (0, import_react14.useState)(false);
  const scrollDown = (0, import_react14.useRef)(null);
  const quietPinnedUntil = (0, import_react14.useRef)(0);
  const sectionRef = (0, import_react14.useCallback)((el) => setScrollerEl(el?.querySelector(".chat") ?? null), []);
  const pinnedIds = (0, import_react14.useMemo)(() => pinned.map((p) => p.id), [pinned]);
  const onPinnedInView = (0, import_react14.useCallback)((id) => {
    if (Date.now() < quietPinnedUntil.current) return;
    setPinnedCurrent(id);
  }, []);
  const selected = (0, import_react14.useMemo)(() => {
    if (!selection || !messages) return [];
    const ids = new Set(selection);
    return messages.filter((m) => ids.has(m.id));
  }, [selection, messages]);
  const menuMessage = menu ? messages?.find((m) => m.id === menu.messageId) ?? null : null;
  if (!row) return null;
  const deleted = isDeletedAccount(row);
  const blocked = row.isBlocked && !deleted;
  return /* @__PURE__ */ (0, import_jsx_runtime15.jsxs)("section", { className: "chat-section", ref: sectionRef, children: [
    /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(ChatHeader, { row, withPinnedBar: pinned.length > 0 }),
    /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(
      PinnedBar,
      {
        pinned,
        currentId: pinnedCurrent,
        onJump: (current, next) => {
          quietPinnedUntil.current = Date.now() + 1200;
          focusMessage(convId, current.id);
          setPinnedCurrent(next.id);
        },
        onOpenList: () => openDialog("pinned")
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("button", { type: "button", className: `scroll-to-bottom-btn${showDown ? " visible" : ""}`, "aria-label": "Scroll to the newest message", onClick: () => scrollDown.current?.(), children: /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(Icons.ChevronDown, {}) }),
    menu && menuMessage && /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(MessageMenu, { row, message: menuMessage, meId: meId2, scroller: scrollerEl }),
    /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(
      MessageList,
      {
        convId,
        row,
        composer: bottomEl,
        onPinnedInView,
        pinnedIds,
        scrollDownRef: scrollDown,
        onShowDownButton: setShowDown
      }
    ),
    selection ? /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(SelectionToolbar, { row, selected, meId: meId2, refCallback: setBottomEl }) : deleted ? /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("div", { ref: setBottomEl, className: "chat-unavailable-notice", role: "status", children: "This account was deleted" }) : blocked ? /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("button", { ref: setBottomEl, type: "button", className: "unblock-action-btn", onClick: () => void toggleBlock(row), children: "Unblock" }) : /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(Composer, { row, refCallback: setBottomEl, dark }),
    dialog === "pinned" && /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(PinnedViewDialog, { row, pinned, meId: meId2 })
  ] });
}
function ChatPart({ phone }) {
  const openConvId = useUi((s) => s.openConvId);
  const { mounted, state } = usePresence(openConvId !== null, phone ? 300 : 0);
  const shown = (0, import_react14.useRef)(null);
  if (openConvId !== null) shown.current = openConvId;
  const convId = openConvId ?? shown.current;
  if (!mounted || convId === null) return null;
  const anim = phone ? state === "enter" ? " slide-in" : state === "exit" ? " slide-out" : "" : "";
  return /* @__PURE__ */ (0, import_jsx_runtime15.jsx)("div", { className: `chat-part${anim}`, id: "chat-part", children: /* @__PURE__ */ (0, import_jsx_runtime15.jsx)(ChatView, { convId }, convId) });
}

// client/chat/ui/dialogs/AddContactDialog.tsx
var import_react15 = __toESM(require_react(), 1);
var import_jsx_runtime16 = __toESM(require_jsx_runtime(), 1);
var USERNAME_RE = /^[a-zA-Z0-9_]{3,30}$/;
function AddContact() {
  const myUsername = useStore(session, (s) => s.me?.username ?? "");
  const [name, setName] = (0, import_react15.useState)("");
  const [username, setUsername] = (0, import_react15.useState)("");
  const [error, setError] = (0, import_react15.useState)("");
  const [busy, setBusy] = (0, import_react15.useState)(false);
  const usernameRef = (0, import_react15.useRef)(null);
  const fail = (text) => {
    setError(text);
    usernameRef.current?.focus();
  };
  const submit = async () => {
    if (busy) return;
    const clean = username.trim().replace(/^@/, "");
    if (!clean) return fail("Username is required");
    if (!USERNAME_RE.test(clean)) return fail("Usernames are 3-30 letters, numbers or underscores");
    if (clean.toLowerCase() === myUsername.toLowerCase()) return fail("That's your own username");
    setBusy(true);
    setError("");
    try {
      const row = await addContact(clean, name);
      openChat(row.conversationId);
    } catch (e) {
      setBusy(false);
      if (e instanceof ApiError && e.status === 404) fail("No one has this username");
      else fail(errorText(e, "Something went wrong. Please try again."));
    }
  };
  return /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(Dialog, { className: "add-contact-dialog", onClose: closeDialog, labelledBy: "add-contact-title", children: /* @__PURE__ */ (0, import_jsx_runtime16.jsxs)(
    "form",
    {
      className: "add-contact-body",
      noValidate: true,
      onSubmit: (e) => {
        e.preventDefault();
        void submit();
      },
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("h3", { className: "add-contact-title", id: "add-contact-title", children: "Add Contact" }),
        /* @__PURE__ */ (0, import_jsx_runtime16.jsxs)("div", { className: "add-contact-field", children: [
          /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("label", { htmlFor: "add-contact-name", children: "Name" }),
          /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
            "input",
            {
              id: "add-contact-name",
              type: "text",
              placeholder: "Contact name (optional)",
              autoComplete: "off",
              maxLength: 100,
              dir: "auto",
              autoFocus: true,
              value: name,
              onChange: (e) => setName(e.target.value),
              onKeyDown: (e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  usernameRef.current?.focus();
                }
              }
            }
          )
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime16.jsxs)("div", { className: "add-contact-field", children: [
          /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("label", { htmlFor: "add-contact-username", children: "Username" }),
          /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(
            "input",
            {
              ref: usernameRef,
              id: "add-contact-username",
              type: "text",
              placeholder: "@username",
              autoComplete: "off",
              autoCapitalize: "none",
              autoCorrect: "off",
              spellCheck: false,
              maxLength: 31,
              "aria-invalid": error ? true : void 0,
              "aria-describedby": "add-contact-error",
              value: username,
              onChange: (e) => {
                setUsername(e.target.value);
                if (error) setError("");
              }
            }
          )
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("p", { className: "add-contact-error", id: "add-contact-error", role: "alert", children: error }),
        /* @__PURE__ */ (0, import_jsx_runtime16.jsxs)("div", { className: "add-contact-actions", children: [
          /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("button", { type: "button", className: "add-contact-cancel", onClick: closeDialog, children: "Cancel" }),
          /* @__PURE__ */ (0, import_jsx_runtime16.jsx)("button", { type: "submit", className: "add-contact-submit", disabled: busy, children: busy ? "Adding\u2026" : "Add" })
        ] })
      ]
    }
  ) });
}
function AddContactDialog() {
  const open2 = useUi((s) => s.dialog === "addContact");
  return open2 ? /* @__PURE__ */ (0, import_jsx_runtime16.jsx)(AddContact, {}) : null;
}

// client/chat/ui/dialogs/ArchivedDialog.tsx
var import_react16 = __toESM(require_react(), 1);
var import_jsx_runtime17 = __toESM(require_jsx_runtime(), 1);
function Archived() {
  const byConv = useStore(contacts, (s) => s.byConv);
  const removed = useStore(undoing, (s) => s.removedContacts);
  const rows = (0, import_react16.useMemo)(
    () => Object.values(byConv).filter((r) => r.isArchived && !r.isSaved && !removed[r.conversationId]).sort((a, b) => lastTime(b) - lastTime(a) || b.id - a.id),
    [byConv, removed]
  );
  return /* @__PURE__ */ (0, import_jsx_runtime17.jsxs)(Dialog, { className: "archived-dialog", onClose: closeDialog, labelledBy: "archived-dialog-title", children: [
    /* @__PURE__ */ (0, import_jsx_runtime17.jsxs)("div", { className: "archived-dialog-header", children: [
      /* @__PURE__ */ (0, import_jsx_runtime17.jsx)("button", { type: "button", className: "archived-dialog-close", "aria-label": "Close", onClick: closeDialog, children: /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(Icons.Close, { size: 22 }) }),
      /* @__PURE__ */ (0, import_jsx_runtime17.jsx)("h3", { className: "archived-dialog-title", id: "archived-dialog-title", children: "Archived Chats" })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime17.jsx)("div", { className: "archived-dialog-list", children: rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime17.jsx)("p", { className: "archived-dialog-empty", children: "No archived chats" }) : rows.map((row) => {
      const name = displayName(row);
      return /* @__PURE__ */ (0, import_jsx_runtime17.jsxs)("div", { className: "archived-card", onClick: () => openChat(row.conversationId), children: [
        /* @__PURE__ */ (0, import_jsx_runtime17.jsxs)(
          "button",
          {
            type: "button",
            className: "card-open-btn visually-hidden",
            onClick: (e) => {
              e.stopPropagation();
              openChat(row.conversationId);
            },
            children: [
              "Open chat with ",
              name
            ]
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime17.jsxs)("div", { className: "archived-card-left", children: [
          /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(
            Avatar,
            {
              name,
              picture: row.contact?.profilePics[0],
              className: "archived-card-avatar",
              online: isOnline(row),
              onlineClass: "online",
              deleted: isDeletedAccount(row)
            }
          ),
          /* @__PURE__ */ (0, import_jsx_runtime17.jsx)("span", { className: "archived-card-name", dir: "auto", children: name })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(
          "button",
          {
            type: "button",
            className: "archived-card-unarchive-btn",
            title: "Unarchive",
            "aria-label": `Unarchive ${name}`,
            onClick: (e) => {
              e.stopPropagation();
              void setArchived(row, false);
            },
            children: /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(Icons.Unarchive, {})
          }
        )
      ] }, row.conversationId);
    }) })
  ] });
}
function ArchivedDialog() {
  const open2 = useUi((s) => s.dialog === "archived");
  return open2 ? /* @__PURE__ */ (0, import_jsx_runtime17.jsx)(Archived, {}) : null;
}

// client/chat/ui/dialogs/DeleteAccountDialog.tsx
var import_react17 = __toESM(require_react(), 1);
var import_jsx_runtime18 = __toESM(require_jsx_runtime(), 1);
function DeleteAccount() {
  const [password, setPassword] = (0, import_react17.useState)("");
  const [error, setError] = (0, import_react17.useState)("");
  const [busy, setBusy] = (0, import_react17.useState)(false);
  const input = (0, import_react17.useRef)(null);
  const fail = (text) => {
    setError(text);
    input.current?.focus();
  };
  const submit = async () => {
    if (busy) return;
    if (!password) return fail("Please enter your password.");
    setBusy(true);
    setError("");
    try {
      await usersApi.deleteAccount(password);
      await accountDeleted();
    } catch (e) {
      setBusy(false);
      if (e instanceof ApiError && e.status === 403) fail("Incorrect password.");
      else fail(errorText(e, "Couldn't delete your account. Please try again."));
    }
  };
  return /* @__PURE__ */ (0, import_jsx_runtime18.jsx)(Dialog, { className: "confirm-dialog", onClose: () => !busy && closeDialog(), closeOnBackdrop: !busy, labelledBy: "delete-account-title", children: /* @__PURE__ */ (0, import_jsx_runtime18.jsxs)(
    "form",
    {
      className: "confirm-dialog-body",
      noValidate: true,
      onSubmit: (e) => {
        e.preventDefault();
        void submit();
      },
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime18.jsx)("h3", { className: "confirm-dialog-title", id: "delete-account-title", children: "Delete Account" }),
        /* @__PURE__ */ (0, import_jsx_runtime18.jsx)("p", { className: "confirm-dialog-desc", children: "This cannot be undone. Your chats stay with the people you talked to, shown as \u201CDeleted account\u201D. Enter your password to confirm." }),
        /* @__PURE__ */ (0, import_jsx_runtime18.jsx)(
          PasswordInput,
          {
            inputRef: input,
            wrapperClass: "confirm-dialog-input-wrap password-wrapper",
            className: "confirm-dialog-input",
            value: password,
            onChange: (v) => {
              setPassword(v);
              if (error) setError("");
            },
            placeholder: "Password",
            label: "Password",
            autoComplete: "current-password",
            invalid: !!error,
            autoFocus: true
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime18.jsx)("p", { className: "confirm-dialog-error", role: "alert", children: error }),
        /* @__PURE__ */ (0, import_jsx_runtime18.jsxs)("div", { className: "confirm-dialog-actions", children: [
          /* @__PURE__ */ (0, import_jsx_runtime18.jsx)("button", { type: "button", className: "confirm-dialog-btn confirm-dialog-btn--cancel", disabled: busy, onClick: closeDialog, children: "Cancel" }),
          /* @__PURE__ */ (0, import_jsx_runtime18.jsx)("button", { type: "submit", className: "confirm-dialog-btn confirm-dialog-btn--danger", disabled: busy, children: busy ? "Deleting\u2026" : "Delete" })
        ] })
      ]
    }
  ) });
}
function DeleteAccountDialog() {
  const open2 = useUi((s) => s.dialog === "deleteAccount");
  return open2 ? /* @__PURE__ */ (0, import_jsx_runtime18.jsx)(DeleteAccount, {}) : null;
}

// client/chat/ui/dialogs/DevicesDialog.tsx
var import_react18 = __toESM(require_react(), 1);
var import_jsx_runtime19 = __toESM(require_jsx_runtime(), 1);
function describeDevice(ua) {
  const browser = /Edg(?:e|A|iOS)?\//.test(ua) ? "Edge" : /OPR\/|Opera/.test(ua) ? "Opera" : /SamsungBrowser\//.test(ua) ? "Samsung Internet" : /Firefox\/|FxiOS\//.test(ua) ? "Firefox" : /Chrome\/|CriOS\//.test(ua) ? "Chrome" : /Safari\//.test(ua) ? "Safari" : null;
  const os = /Android/.test(ua) ? "Android" : /iPhone|iPod/.test(ua) ? "iPhone" : /iPad/.test(ua) ? "iPad" : /Windows/.test(ua) ? "Windows" : /CrOS/.test(ua) ? "ChromeOS" : /Mac OS X|Macintosh/.test(ua) ? "macOS" : /Linux/.test(ua) ? "Linux" : null;
  const mobile = /Mobi|Android|iPhone|iPad|iPod/.test(ua);
  if (browser && os) return { name: `${browser} on ${os}`, mobile };
  return { name: browser ?? os ?? "Unknown device", mobile };
}
function Devices() {
  const [load2, setLoad] = (0, import_react18.useState)({ status: "loading" });
  const [busy, setBusy] = (0, import_react18.useState)(null);
  const now = useNow(6e4);
  const fetchList = (0, import_react18.useCallback)(async () => {
    setLoad({ status: "loading" });
    try {
      const { sessions: sessions2 } = await sessionsApi.list();
      setLoad({ status: "ready", sessions: sessions2 });
    } catch (e) {
      setLoad({ status: "error", text: errorText(e, "Couldn't load your devices.") });
    }
  }, []);
  (0, import_react18.useEffect)(() => {
    void fetchList();
  }, [fetchList]);
  const sessions = load2.status === "ready" ? load2.sessions : [];
  const others = sessions.filter((s) => !s.current);
  const signOut = async (id) => {
    if (busy) return;
    setBusy(id);
    try {
      await sessionsApi.revoke(id);
      setLoad((l) => l.status === "ready" ? { ...l, sessions: l.sessions.filter((s) => s.id !== id) } : l);
      showToast("Device signed out", { icon: "check" });
    } catch (e) {
      showToast(errorText(e, "Couldn't sign out that device. Please try again."), { icon: "error" });
    } finally {
      setBusy(null);
    }
  };
  const signOutOthers = async () => {
    if (busy) return;
    setBusy("others");
    try {
      const { revoked } = await sessionsApi.revokeOthers();
      setLoad((l) => l.status === "ready" ? { ...l, sessions: l.sessions.filter((s) => s.current) } : l);
      showToast(revoked === 1 ? "1 device signed out" : `${revoked} devices signed out`, { icon: "check" });
    } catch (e) {
      showToast(errorText(e, "Couldn't sign out the other devices. Please try again."), { icon: "error" });
    } finally {
      setBusy(null);
    }
  };
  return /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)(Dialog, { className: "devices-dialog", onClose: closeDialog, labelledBy: "devices-dialog-title", children: [
    /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)("div", { className: "archived-dialog-header", children: [
      /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("button", { type: "button", className: "archived-dialog-close", "aria-label": "Close", onClick: closeDialog, children: /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(Icons.Close, { size: 22 }) }),
      /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("h3", { className: "archived-dialog-title", id: "devices-dialog-title", children: "Devices" })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)("div", { className: "devices-list", "aria-busy": load2.status === "loading", children: [
      load2.status === "loading" && /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)("div", { className: "devices-loading", role: "status", children: [
        /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(Icons.Spinner, {}),
        /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("span", { children: "Loading\u2026" })
      ] }),
      load2.status === "error" && /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)("div", { className: "devices-error", children: [
        /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("p", { children: load2.text }),
        /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("button", { type: "button", className: "settings-wallpaper-btn", onClick: () => void fetchList(), children: "Try again" })
      ] }),
      sessions.map((s) => {
        const device = describeDevice(s.userAgent);
        return /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)("div", { className: `device-item${s.current ? " current" : ""}`, children: [
          /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("span", { className: "device-icon", children: device.mobile ? /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(Icons.Phone, {}) : /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(Icons.Desktop, {}) }),
          /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)("div", { className: "device-info", children: [
            /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("span", { className: "device-name", children: device.name }),
            /* @__PURE__ */ (0, import_jsx_runtime19.jsxs)("span", { className: "device-meta", children: [
              s.current ? "This device" : `Active ${timeAgo(s.lastSeenAt, now)}`,
              " \xB7 Signed in ",
              shortDate(s.createdAt)
            ] })
          ] }),
          !s.current && /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("button", { type: "button", className: "device-signout", disabled: busy !== null, onClick: () => void signOut(s.id), children: busy === s.id ? "\u2026" : "Sign out" })
        ] }, s.id);
      })
    ] }),
    others.length > 1 && /* @__PURE__ */ (0, import_jsx_runtime19.jsx)("button", { type: "button", className: "devices-signout-all", disabled: busy !== null, onClick: () => void signOutOthers(), children: busy === "others" ? "Signing out\u2026" : "Sign out all other devices" })
  ] });
}
function DevicesDialog() {
  const open2 = useUi((s) => s.dialog === "devices");
  return open2 ? /* @__PURE__ */ (0, import_jsx_runtime19.jsx)(Devices, {}) : null;
}

// client/chat/ui/feedback/ConnectionStatus.tsx
var import_react19 = __toESM(require_react(), 1);
var import_jsx_runtime20 = __toESM(require_jsx_runtime(), 1);
var DELAY_MS = 1500;
function subscribeOnline(cb) {
  window.addEventListener("online", cb);
  window.addEventListener("offline", cb);
  return () => {
    window.removeEventListener("online", cb);
    window.removeEventListener("offline", cb);
  };
}
function ConnectionStatus() {
  const status = useStore(connection, (s) => s.status);
  const online = (0, import_react19.useSyncExternalStore)(subscribeOnline, () => navigator.onLine, () => true);
  const down = status !== "online";
  const [visible2, setVisible] = (0, import_react19.useState)(false);
  (0, import_react19.useEffect)(() => {
    if (!down) {
      setVisible(false);
      return void 0;
    }
    const t = window.setTimeout(() => setVisible(true), DELAY_MS);
    return () => window.clearTimeout(t);
  }, [down]);
  return /* @__PURE__ */ (0, import_jsx_runtime20.jsx)("div", { className: `connection-status${visible2 ? " visible" : ""}`, role: "status", "aria-live": "polite", "aria-hidden": !visible2, children: /* @__PURE__ */ (0, import_jsx_runtime20.jsx)("span", { className: "connection-status-text", children: visible2 ? online ? "Connecting..." : "Waiting for network..." : "" }) });
}

// client/chat/ui/feedback/InAppNotifications.tsx
var import_react20 = __toESM(require_react(), 1);
var import_jsx_runtime21 = __toESM(require_jsx_runtime(), 1);
var SHOW_MS2 = 3e3;
var SLIDE_MS = 320;
var DISMISS_DRAG = 40;
function Banner({ notice }) {
  const row = useRow(notice.conversationId);
  const [phase, setPhase] = (0, import_react20.useState)("enter");
  const [drag, setDrag] = (0, import_react20.useState)(null);
  const start3 = (0, import_react20.useRef)(null);
  const suppressClick = (0, import_react20.useRef)(false);
  (0, import_react20.useEffect)(() => {
    let r2 = 0;
    const r1 = requestAnimationFrame(() => {
      r2 = requestAnimationFrame(() => setPhase("shown"));
    });
    return () => {
      cancelAnimationFrame(r1);
      cancelAnimationFrame(r2);
    };
  }, []);
  (0, import_react20.useEffect)(() => {
    if (phase !== "shown" || drag !== null) return void 0;
    const t = window.setTimeout(() => setPhase("leaving"), SHOW_MS2);
    return () => window.clearTimeout(t);
  }, [phase, drag, notice.text, notice.messageId]);
  (0, import_react20.useEffect)(() => {
    if (phase !== "leaving") return void 0;
    const t = window.setTimeout(() => dismissNotice(notice.id), prefersReducedMotion() ? 0 : SLIDE_MS);
    return () => window.clearTimeout(t);
  }, [phase, notice.id]);
  const onPointerDown = (e) => {
    start3.current = { id: e.pointerId, y: e.clientY, moved: false };
    suppressClick.current = false;
    e.currentTarget.setPointerCapture(e.pointerId);
  };
  const onPointerMove = (e) => {
    const s = start3.current;
    if (!s || s.id !== e.pointerId) return;
    const dy = e.clientY - s.y;
    if (Math.abs(dy) > 8) {
      s.moved = true;
      suppressClick.current = true;
    }
    setDrag(Math.min(0, dy));
  };
  const onPointerEnd = (e) => {
    const s = start3.current;
    if (!s || s.id !== e.pointerId) return;
    start3.current = null;
    const dy = drag ?? 0;
    setDrag(null);
    if (dy < -DISMISS_DRAG) dismissNotice(notice.id);
  };
  const open2 = () => {
    if (suppressClick.current) {
      suppressClick.current = false;
      return;
    }
    openChat(notice.conversationId, { focusMessageId: notice.messageId });
  };
  const title = notice.title || (row ? displayName(row) : "");
  const classes = ["in-app-notif"];
  if (phase === "shown" || drag !== null) classes.push("show");
  if (drag !== null) classes.push("dragging");
  return /* @__PURE__ */ (0, import_jsx_runtime21.jsx)(
    "div",
    {
      className: classes.join(" "),
      style: drag !== null ? { transform: `translateY(${drag}px)` } : void 0,
      role: "button",
      tabIndex: 0,
      "aria-label": `New message from ${title}: ${notice.text}. Open chat.`,
      onPointerDown,
      onPointerMove,
      onPointerUp: onPointerEnd,
      onPointerCancel: onPointerEnd,
      onClick: open2,
      onKeyDown: (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          open2();
        } else if (e.key === "Escape") dismissNotice(notice.id);
      },
      children: /* @__PURE__ */ (0, import_jsx_runtime21.jsxs)("div", { className: "notif-card", children: [
        /* @__PURE__ */ (0, import_jsx_runtime21.jsx)(Avatar, { name: title, picture: row?.contact?.profilePics[0], className: "notif-avatar", deleted: row ? isDeletedAccount(row) : false }),
        /* @__PURE__ */ (0, import_jsx_runtime21.jsxs)("div", { className: "notif-body", children: [
          /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("div", { className: "notif-title", dir: "auto", children: title }),
          /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("div", { className: "notif-text", dir: "auto", children: notice.text })
        ] })
      ] })
    }
  );
}
function InAppNotifications() {
  const current = useStore(notices, (s) => s.list[0] ?? null);
  return /* @__PURE__ */ (0, import_jsx_runtime21.jsx)("div", { className: "in-app-notif-wrap", children: current && /* @__PURE__ */ (0, import_jsx_runtime21.jsx)(Banner, { notice: current }, current.id) });
}

// client/chat/ui/feedback/Toaster.tsx
var import_react22 = __toESM(require_react(), 1);

// client/shared/ui/TopLayer.tsx
var import_react21 = __toESM(require_react(), 1);
var import_react_dom = __toESM(require_react_dom(), 1);
var import_jsx_runtime22 = __toESM(require_jsx_runtime(), 1);
var canPopover = typeof HTMLElement !== "undefined" && "showPopover" in HTMLElement.prototype;
function TopLayer({ className, style, children }) {
  const host = useStore(openDialogs, (list) => list[list.length - 1] ?? null);
  const ref = (0, import_react21.useRef)(null);
  const asPopover = host !== null && canPopover;
  (0, import_react21.useLayoutEffect)(() => {
    const el = ref.current;
    if (!el || !asPopover) return void 0;
    try {
      el.showPopover();
    } catch {
    }
    return () => {
      try {
        el.hidePopover();
      } catch {
      }
    };
  }, [asPopover, host]);
  const node = /* @__PURE__ */ (0, import_jsx_runtime22.jsx)("div", { ref, className: `top-layer ${className}`, style, popover: asPopover ? "manual" : void 0, children });
  return host ? (0, import_react_dom.createPortal)(node, host) : node;
}

// client/chat/ui/feedback/Toaster.tsx
var import_jsx_runtime23 = __toESM(require_jsx_runtime(), 1);
var ICONS = {
  delete: Icons.Delete,
  copy: Icons.Copy,
  archive: Icons.Archive,
  pin: Icons.Pin,
  mute: Icons.Mute,
  block: Icons.Block,
  error: Icons.Failed,
  check: Icons.Check,
  bell: Icons.Bell
};
var GAP = 14;
var FADE_MS = 150;
function bottomOffset() {
  const box = bottomBarRef.current;
  if (!box) return GAP;
  const r = box.getBoundingClientRect();
  if (r.height === 0 || r.top >= window.innerHeight) return GAP;
  return Math.max(GAP, window.innerHeight - r.top + GAP);
}
function Toaster() {
  const toast = useStore(toasts, (s) => s.current);
  const [shown, setShown] = (0, import_react22.useState)(toast);
  const [bottom, setBottom] = (0, import_react22.useState)(GAP);
  (0, import_react22.useLayoutEffect)(() => {
    if (toast) {
      setShown(toast);
      setBottom(bottomOffset());
    }
  }, [toast]);
  (0, import_react22.useEffect)(() => {
    if (toast) return void 0;
    const t = window.setTimeout(() => setShown(null), FADE_MS);
    return () => window.clearTimeout(t);
  }, [toast]);
  const Icon = shown?.icon ? ICONS[shown.icon] : null;
  return /* @__PURE__ */ (0, import_jsx_runtime23.jsxs)(TopLayer, { className: "toast-layer", children: [
    /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("div", { className: "visually-hidden", role: "status", "aria-live": "polite", children: toast?.text ?? "" }),
    shown && /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("div", { className: `toaster${toast ? "" : " leaving"}`, style: { bottom }, children: /* @__PURE__ */ (0, import_jsx_runtime23.jsxs)("div", { className: "toast", children: [
      Icon && /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("span", { className: "toast-icon", children: /* @__PURE__ */ (0, import_jsx_runtime23.jsx)(Icon, {}) }),
      /* @__PURE__ */ (0, import_jsx_runtime23.jsx)("span", { className: "toast-message", children: shown.text }),
      shown.action && /* @__PURE__ */ (0, import_jsx_runtime23.jsx)(
        "button",
        {
          type: "button",
          className: "undo-btn",
          onClick: () => {
            const run = shown.action?.run;
            hideToast();
            run?.();
          },
          children: shown.action.label
        }
      )
    ] }) })
  ] });
}

// client/chat/ui/panels/EditProfilePanel.tsx
var import_react24 = __toESM(require_react(), 1);

// client/chat/ui/panels/AvatarCropper.tsx
var import_react23 = __toESM(require_react(), 1);
var import_jsx_runtime24 = __toESM(require_jsx_runtime(), 1);
var OUTPUT = 400;
var FRAME = 0.8;
var MAX_ZOOM = 4;
function AvatarCropper({ file, busy, onCancel, onDone }) {
  const box = (0, import_react23.useRef)(null);
  const [img, setImg] = (0, import_react23.useState)(null);
  const [url2, setUrl] = (0, import_react23.useState)(null);
  const [failed, setFailed] = (0, import_react23.useState)(false);
  const [size, setSize] = (0, import_react23.useState)({ w: 0, h: 0 });
  const [view, setView] = (0, import_react23.useState)(null);
  const pointers = (0, import_react23.useRef)(/* @__PURE__ */ new Map());
  const pinch = (0, import_react23.useRef)(null);
  (0, import_react23.useEffect)(() => {
    const u = URL.createObjectURL(file);
    setUrl(u);
    const image = new Image();
    image.onload = () => setImg(image);
    image.onerror = () => setFailed(true);
    image.src = u;
    return () => URL.revokeObjectURL(u);
  }, [file]);
  (0, import_react23.useEffect)(() => {
    const el = box.current;
    if (!el) return void 0;
    const ro = new ResizeObserver(() => setSize({ w: el.clientWidth, h: el.clientHeight }));
    ro.observe(el);
    return () => ro.disconnect();
  }, []);
  const frame = Math.min(size.w, size.h) * FRAME;
  const frameX = (size.w - frame) / 2;
  const frameY = (size.h - frame) / 2;
  const minScale = img ? Math.max(frame / img.naturalWidth, frame / img.naturalHeight) : 1;
  const clamp = (0, import_react23.useCallback)(
    (v) => {
      if (!img) return v;
      const scale = Math.min(Math.max(v.scale, minScale), minScale * MAX_ZOOM);
      const w = img.naturalWidth * scale;
      const h = img.naturalHeight * scale;
      const x = Math.min(frameX, Math.max(frameX + frame - w, v.x));
      const y = Math.min(frameY, Math.max(frameY + frame - h, v.y));
      return { scale, x, y };
    },
    [img, minScale, frame, frameX, frameY]
  );
  (0, import_react23.useEffect)(() => {
    if (!img || !frame) return;
    const scale = minScale;
    setView(clamp({ scale, x: (size.w - img.naturalWidth * scale) / 2, y: (size.h - img.naturalHeight * scale) / 2 }));
  }, [img, frame, minScale, size.w, size.h, clamp]);
  const zoomAt = (scale, px, py) => {
    setView((v) => {
      if (!v) return v;
      const k = Math.min(Math.max(scale, minScale), minScale * MAX_ZOOM) / v.scale;
      return clamp({ scale: v.scale * k, x: px - (px - v.x) * k, y: py - (py - v.y) * k });
    });
  };
  const local = (e) => {
    const r = box.current.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };
  const onPointerDown = (e) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    pointers.current.set(e.pointerId, local(e));
    if (pointers.current.size === 2 && view) {
      const [a, b] = [...pointers.current.values()];
      pinch.current = { dist: Math.hypot(a.x - b.x, a.y - b.y), scale: view.scale };
    }
  };
  const onPointerMove = (e) => {
    const prev = pointers.current.get(e.pointerId);
    if (!prev || !view) return;
    const now = local(e);
    pointers.current.set(e.pointerId, now);
    if (pointers.current.size === 2 && pinch.current) {
      const [a, b] = [...pointers.current.values()];
      const dist = Math.hypot(a.x - b.x, a.y - b.y);
      zoomAt(pinch.current.scale * dist / pinch.current.dist, (a.x + b.x) / 2, (a.y + b.y) / 2);
      return;
    }
    setView((v) => v ? clamp({ ...v, x: v.x + now.x - prev.x, y: v.y + now.y - prev.y }) : v);
  };
  const onPointerUp = (e) => {
    pointers.current.delete(e.pointerId);
    if (pointers.current.size < 2) pinch.current = null;
  };
  (0, import_react23.useEffect)(() => {
    const el = box.current;
    if (!el) return void 0;
    const onWheel = (e) => {
      e.preventDefault();
      const r = el.getBoundingClientRect();
      setView((v) => {
        if (!v) return v;
        const target = v.scale * Math.exp(-e.deltaY * 15e-4);
        const k = Math.min(Math.max(target, minScale), minScale * MAX_ZOOM) / v.scale;
        const px = e.clientX - r.left;
        const py = e.clientY - r.top;
        return clamp({ scale: v.scale * k, x: px - (px - v.x) * k, y: py - (py - v.y) * k });
      });
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, [minScale, clamp]);
  const apply = () => {
    if (!img || !view) return;
    const canvas2 = document.createElement("canvas");
    canvas2.width = OUTPUT;
    canvas2.height = OUTPUT;
    const ctx = canvas2.getContext("2d");
    if (!ctx) return;
    ctx.fillStyle = "#fff";
    ctx.fillRect(0, 0, OUTPUT, OUTPUT);
    ctx.imageSmoothingQuality = "high";
    const sx = (frameX - view.x) / view.scale;
    const sy = (frameY - view.y) / view.scale;
    const s = frame / view.scale;
    ctx.drawImage(img, sx, sy, s, s, 0, 0, OUTPUT, OUTPUT);
    canvas2.toBlob((blob) => blob && onDone(blob), "image/jpeg", 0.9);
  };
  const zoomPercent = view && minScale ? (view.scale / minScale - 1) / (MAX_ZOOM - 1) : 0;
  return /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)(Dialog, { className: "avatar-crop-dialog", onClose: () => !busy && onCancel(), label: "Crop picture", closeOnBackdrop: false, children: [
    /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)(
      "div",
      {
        ref: box,
        className: "avatar-crop-container",
        onPointerDown,
        onPointerMove,
        onPointerUp,
        onPointerCancel: onPointerUp,
        children: [
          failed && /* @__PURE__ */ (0, import_jsx_runtime24.jsx)("p", { className: "avatar-crop-error", children: "This image can't be opened. Please try another one." }),
          url2 && img && view && /* @__PURE__ */ (0, import_jsx_runtime24.jsx)(
            "img",
            {
              src: url2,
              alt: "",
              draggable: false,
              className: "avatar-crop-image",
              style: { width: img.naturalWidth * view.scale, height: img.naturalHeight * view.scale, transform: `translate(${view.x}px, ${view.y}px)` }
            }
          ),
          frame > 0 && /* @__PURE__ */ (0, import_jsx_runtime24.jsx)("div", { className: "avatar-crop-frame", style: { left: frameX, top: frameY, width: frame, height: frame } })
        ]
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime24.jsx)(
      "input",
      {
        type: "range",
        className: "avatar-crop-zoom",
        "aria-label": "Zoom",
        min: 0,
        max: 1,
        step: 0.01,
        value: zoomPercent,
        onChange: (e) => zoomAt(minScale * (1 + Number(e.target.value) * (MAX_ZOOM - 1)), size.w / 2, size.h / 2)
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime24.jsxs)("div", { className: "avatar-crop-actions", children: [
      /* @__PURE__ */ (0, import_jsx_runtime24.jsx)("button", { type: "button", className: "avatar-crop-cancel", disabled: busy, onClick: onCancel, children: "Cancel" }),
      /* @__PURE__ */ (0, import_jsx_runtime24.jsx)("button", { type: "button", className: "avatar-crop-confirm", disabled: busy || !view, onClick: apply, children: busy ? "Saving\u2026" : "Apply" })
    ] })
  ] });
}

// client/chat/ui/panels/ResponsivePanel.tsx
var import_jsx_runtime25 = __toESM(require_jsx_runtime(), 1);
function ResponsivePanel({
  open: open2,
  phone,
  panelClass,
  dialogClass,
  onClose,
  label,
  children
}) {
  const { mounted, state } = usePresence(open2 && phone, 300);
  useEscape(() => {
    if (!document.querySelector("dialog[open]")) onClose();
  }, open2 && phone);
  if (!phone) {
    if (!open2) return null;
    return /* @__PURE__ */ (0, import_jsx_runtime25.jsx)(Dialog, { className: dialogClass, onClose, label, children: /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: panelClass, children }) });
  }
  if (!mounted) return null;
  const anim = state === "enter" ? " slide-in" : state === "exit" ? " slide-out" : "";
  return /* @__PURE__ */ (0, import_jsx_runtime25.jsx)("div", { className: `${panelClass}${anim}`, style: { display: "flex" }, role: "dialog", "aria-modal": "true", "aria-label": label, children });
}

// client/chat/ui/panels/EditProfilePanel.tsx
var import_jsx_runtime26 = __toESM(require_jsx_runtime(), 1);
var NAME_MIN = 2;
var NAME_MAX = 100;
var BIO_MAX = 300;
var USERNAME_RE2 = /^[a-zA-Z0-9_]{3,30}$/;
function EditProfile() {
  const me = useStore(session, (s) => s.me);
  const [name, setName] = (0, import_react24.useState)(me?.name ?? "");
  const [username, setUsername] = (0, import_react24.useState)(me?.username ?? "");
  const [bio, setBio] = (0, import_react24.useState)(me?.bio ?? "");
  const [saving, setSaving] = (0, import_react24.useState)(false);
  const [avatarBusy, setAvatarBusy] = (0, import_react24.useState)(false);
  const [cropping, setCropping] = (0, import_react24.useState)(null);
  const fileInput = (0, import_react24.useRef)(null);
  const nameInput = (0, import_react24.useRef)(null);
  const usernameInput = (0, import_react24.useRef)(null);
  const bioInput = (0, import_react24.useRef)(null);
  const hasPicture = !!me?.profilePics[0];
  if (!me) return null;
  const save = async () => {
    if (saving) return;
    const cleanName = name.trim();
    const cleanUsername = username.trim().replace(/^@/, "");
    const cleanBio = bio.trim();
    if (cleanName.length < NAME_MIN || cleanName.length > NAME_MAX) {
      showToast(`Name must be ${NAME_MIN}-${NAME_MAX} characters`, { icon: "error" });
      nameInput.current?.focus();
      return;
    }
    if (!USERNAME_RE2.test(cleanUsername)) {
      showToast("Username must be 3-30 characters: letters, numbers or underscores", { icon: "error" });
      usernameInput.current?.focus();
      return;
    }
    if (cleanBio.length > BIO_MAX) {
      showToast(`Bio must be ${BIO_MAX} characters or fewer`, { icon: "error" });
      bioInput.current?.focus();
      return;
    }
    const changes = {};
    if (cleanName !== me.name) changes.name = cleanName;
    if (cleanUsername !== me.username) changes.username = cleanUsername;
    if (cleanBio !== (me.bio || "")) changes.bio = cleanBio;
    if (Object.keys(changes).length === 0) {
      closePanel();
      return;
    }
    setSaving(true);
    try {
      setMe(await usersApi.update(changes));
      closePanel();
      showToast("Profile updated", { icon: "check" });
    } catch (e) {
      if (e instanceof ApiError && e.status === 409) {
        showToast("This username is already taken", { icon: "error" });
        usernameInput.current?.focus();
      } else showToast(errorText(e, "Couldn't save your profile. Please try again."), { icon: "error" });
    } finally {
      setSaving(false);
    }
  };
  const upload = async (jpeg) => {
    setAvatarBusy(true);
    try {
      const { url: url2 } = await usersApi.uploadAvatar(jpeg);
      patchMe({ profilePics: [url2] });
      setCropping(null);
    } catch (e) {
      showToast(errorText(e, "Upload failed. Please try again."), { icon: "error" });
    } finally {
      setAvatarBusy(false);
    }
  };
  const removePicture = async () => {
    if (avatarBusy || !hasPicture) return;
    setAvatarBusy(true);
    try {
      setMe(await usersApi.update({ profilePics: [] }));
    } catch (e) {
      showToast(errorText(e, "Couldn't remove the picture. Please try again."), { icon: "error" });
    } finally {
      setAvatarBusy(false);
    }
  };
  return /* @__PURE__ */ (0, import_jsx_runtime26.jsxs)(import_jsx_runtime26.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime26.jsxs)("div", { className: "edit-profile-banner", children: [
      /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("button", { type: "button", className: "edit-profile-close", "aria-label": "Close", onClick: closePanel, children: /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(Icons.Close, {}) }),
      /* @__PURE__ */ (0, import_jsx_runtime26.jsxs)("div", { className: `edit-profile-avatar-wrapper${avatarBusy ? " uploading" : ""}`, children: [
        /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(Avatar, { name: me.name || me.username, picture: me.profilePics[0], className: "edit-profile-avatar" }),
        /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("button", { type: "button", className: "edit-profile-avatar-btn", "aria-label": "Change picture", disabled: avatarBusy, onClick: () => fileInput.current?.click(), children: /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(Icons.Rotate, {}) }),
        hasPicture && /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("button", { type: "button", className: "edit-profile-delete-avatar-btn", "aria-label": "Remove picture", disabled: avatarBusy, onClick: () => void removePicture(), children: /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(Icons.Delete, {}) })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(
        "input",
        {
          ref: fileInput,
          type: "file",
          accept: "image/jpeg,image/png,image/webp,image/gif",
          hidden: true,
          onChange: (e) => {
            const file = e.target.files?.[0];
            e.target.value = "";
            if (!file) return;
            if (file.type && !file.type.startsWith("image/")) {
              showToast("Please choose an image file", { icon: "error" });
              return;
            }
            setCropping(file);
          }
        }
      )
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime26.jsxs)(
      "form",
      {
        className: "edit-profile-body",
        noValidate: true,
        onSubmit: (e) => {
          e.preventDefault();
          void save();
        },
        children: [
          /* @__PURE__ */ (0, import_jsx_runtime26.jsxs)("div", { className: "edit-profile-field", children: [
            /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("label", { htmlFor: "edit-name-input", children: "Name" }),
            /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("input", { ref: nameInput, id: "edit-name-input", type: "text", placeholder: "Your name", autoComplete: "name", maxLength: NAME_MAX, dir: "auto", value: name, onChange: (e) => setName(e.target.value) })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime26.jsxs)("div", { className: "edit-profile-field", children: [
            /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("label", { htmlFor: "edit-username-input", children: "Username" }),
            /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(
              "input",
              {
                ref: usernameInput,
                id: "edit-username-input",
                type: "text",
                placeholder: "@username",
                autoComplete: "username",
                autoCapitalize: "none",
                spellCheck: false,
                maxLength: 31,
                value: username,
                onChange: (e) => setUsername(e.target.value)
              }
            )
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime26.jsxs)("div", { className: "edit-profile-field", children: [
            /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("label", { htmlFor: "edit-bio-input", children: "Bio" }),
            /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("textarea", { ref: bioInput, id: "edit-bio-input", placeholder: "Write something about yourself...", rows: 3, maxLength: BIO_MAX, dir: "auto", value: bio, onChange: (e) => setBio(e.target.value) })
          ] }),
          /* @__PURE__ */ (0, import_jsx_runtime26.jsx)("button", { type: "submit", className: "edit-profile-save", disabled: saving, children: saving ? "Saving\u2026" : "Save Changes" })
        ]
      }
    ),
    cropping && /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(AvatarCropper, { file: cropping, busy: avatarBusy, onCancel: () => setCropping(null), onDone: (b) => void upload(b) })
  ] });
}
function EditProfilePanel({ phone }) {
  const open2 = useUi((s) => s.panel === "editProfile");
  return /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(ResponsivePanel, { open: open2, phone, panelClass: "edit-profile-panel", dialogClass: "edit-profile-dialog", onClose: closePanel, label: "Edit profile", children: /* @__PURE__ */ (0, import_jsx_runtime26.jsx)(EditProfile, {}) });
}

// client/chat/ui/panels/ProfilePanel.tsx
var import_react25 = __toESM(require_react(), 1);

// client/shared/ui/pressable.ts
function pressable(fn) {
  return {
    role: "button",
    tabIndex: 0,
    onClick: (e) => fn(e),
    onKeyDown: (e) => {
      if (e.target !== e.currentTarget) return;
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        fn(e);
      }
    }
  };
}

// client/chat/ui/panels/ProfilePanel.tsx
var import_jsx_runtime27 = __toESM(require_jsx_runtime(), 1);
function Copyable({ label, value: value2, id }) {
  const [copied, setCopied] = (0, import_react25.useState)(false);
  (0, import_react25.useEffect)(() => {
    if (!copied) return void 0;
    const t = window.setTimeout(() => setCopied(false), 1500);
    return () => window.clearTimeout(t);
  }, [copied]);
  const copy = () => {
    navigator.clipboard?.writeText(value2).then(
      () => setCopied(true),
      () => void 0
    );
  };
  return /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("div", { id, children: [
    /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("p", { children: label }),
    /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("h3", { className: "copyable", ...pressable(copy), "aria-label": `${label}: ${value2}. Tap to copy.`, children: copied ? "Copied!" : value2 })
  ] });
}
function Profile({ row }) {
  const [editing, setEditing] = (0, import_react25.useState)(false);
  const nameEl = (0, import_react25.useRef)(null);
  const now = useNow(3e4);
  const deleted = isDeletedAccount(row);
  const person = row.contact;
  const name = displayName(row);
  const online = isOnline(row);
  const nameNow = (0, import_react25.useRef)(name);
  nameNow.current = name;
  (0, import_react25.useEffect)(() => setEditing(false), [row.conversationId]);
  (0, import_react25.useEffect)(() => {
    if (!editing || !nameEl.current) return;
    const el = nameEl.current;
    el.textContent = nameNow.current;
    el.focus();
    const range = document.createRange();
    range.selectNodeContents(el);
    range.collapse(false);
    const sel = window.getSelection();
    sel?.removeAllRanges();
    sel?.addRange(range);
  }, [editing]);
  const finishRename = () => {
    const typed = nameEl.current?.textContent ?? "";
    setEditing(false);
    void rename(row, typed);
  };
  let status = "";
  if (!deleted) {
    if (online) status = "Online";
    else if (person?.lastSeen) status = `Last seen ${timeAgo(person.lastSeen, now)}`;
  }
  return /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)(import_jsx_runtime27.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("div", { className: "contact-detail-pic", children: [
      /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("div", { className: "detail-picture", children: /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(Avatar, { name, picture: person?.profilePics[0], className: "contact-profile", online, deleted }) }),
      /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("button", { type: "button", "aria-label": "Close profile", onClick: closePanel, children: /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(Icons.Back, {}) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("div", { className: "contact-profile-actions", children: [
      /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("div", { className: "contact-detail-name", children: [
        /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("div", { children: [
          editing && /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("button", { type: "button", className: "name-edit-btn", "aria-label": "Cancel", onClick: () => setEditing(false), children: /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(Icons.CloseThin, {}) }),
          editing ? /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
            "h3",
            {
              ref: nameEl,
              className: "editing",
              contentEditable: true,
              suppressContentEditableWarning: true,
              role: "textbox",
              "aria-label": "Name for this contact",
              dir: "auto",
              onKeyDown: (e) => {
                if (e.key === "Enter") {
                  e.preventDefault();
                  finishRename();
                } else if (e.key === "Escape") {
                  e.preventDefault();
                  e.stopPropagation();
                  setEditing(false);
                }
              },
              onPaste: (e) => {
                e.preventDefault();
                document.execCommand("insertText", false, e.clipboardData.getData("text/plain").replace(/\s+/g, " "));
              }
            }
          ) : /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("h3", { dir: "auto", children: name }),
          editing && /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("button", { type: "button", className: "name-edit-btn", "aria-label": "Save name", onClick: finishRename, children: /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(Icons.Check, {}) })
        ] }),
        !deleted && person?.bio ? /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("h6", { dir: "auto", children: person.bio }) : null,
        /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("p", { children: status })
      ] }),
      !deleted && (person?.username || person?.email) && /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("div", { className: "contact-info", children: [
        person?.username && /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(Copyable, { id: "contact-username", label: "Username", value: `@${person.username}` }),
        person?.email && /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(Copyable, { id: "contact-email", label: "Email", value: person.email })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime27.jsxs)("div", { className: "contact-actions", children: [
        !deleted && /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("div", { ...pressable(() => setEditing(true)), id: "edit-name-btn", children: "Edit Name" }),
        !deleted && /* @__PURE__ */ (0, import_jsx_runtime27.jsx)("div", { ...pressable(() => void toggleBlock(row)), id: "block-contact-btn", children: row.isBlocked ? "Unblock Contact" : "Block Contact" }),
        /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
          "div",
          {
            ...pressable(() => {
              if (row.isArchived) void setArchived(row, false);
              else {
                closePanel();
                void setArchived(row, true);
              }
            }),
            id: "archive-contact-btn",
            children: row.isArchived ? "Unarchive Chat" : "Archive Chat"
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
          "div",
          {
            ...pressable(() => {
              closePanel();
              deleteChat(row);
            }),
            id: "delete-chat-btn",
            className: "danger",
            children: "Delete Chat"
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(
          "div",
          {
            ...pressable(() => {
              closePanel();
              deleteContact(row);
            }),
            id: "delete-contact-btn",
            className: "danger",
            children: "Delete Contact"
          }
        )
      ] })
    ] })
  ] });
}
function ProfilePanel({ phone }) {
  const open2 = useUi((s) => s.panel === "profile" && s.openConvId !== null);
  const convId = useUi((s) => s.openConvId);
  const row = useRow(convId);
  const last = (0, import_react25.useRef)(null);
  if (row && open2) last.current = row;
  const shown = open2 ? row : last.current;
  return /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(ResponsivePanel, { open: open2 && !!row && !row.isSaved, phone, panelClass: "contact-profile-details", dialogClass: "profile-dialog", onClose: closePanel, label: "Profile", children: shown && /* @__PURE__ */ (0, import_jsx_runtime27.jsx)(Profile, { row: shown }) });
}

// client/chat/ui/panels/SettingsPanel.tsx
var import_react26 = __toESM(require_react(), 1);

// client/shared/lib/images.ts
async function decodeImage(file) {
  if (typeof createImageBitmap === "function") {
    try {
      const bmp = await createImageBitmap(file, { imageOrientation: "from-image" });
      return { source: bmp, width: bmp.width, height: bmp.height, close: () => bmp.close() };
    } catch {
    }
  }
  const url2 = URL.createObjectURL(file);
  try {
    const img = new Image();
    img.decoding = "async";
    img.src = url2;
    await img.decode();
    return { source: img, width: img.naturalWidth, height: img.naturalHeight, close: () => void 0 };
  } finally {
    URL.revokeObjectURL(url2);
  }
}
async function toJpegDataUrl(file, opts) {
  const img = await decodeImage(file);
  try {
    if (!img.width || !img.height) throw new Error("empty image");
    let side = opts.maxSide;
    for (let attempt = 0; attempt < 4; attempt++) {
      const scale = Math.min(1, side / Math.max(img.width, img.height));
      const w = Math.max(1, Math.round(img.width * scale));
      const h = Math.max(1, Math.round(img.height * scale));
      const canvas2 = document.createElement("canvas");
      canvas2.width = w;
      canvas2.height = h;
      const ctx = canvas2.getContext("2d");
      if (!ctx) throw new Error("no canvas");
      ctx.fillStyle = opts.background ?? "#fff";
      ctx.fillRect(0, 0, w, h);
      ctx.imageSmoothingQuality = "high";
      ctx.drawImage(img.source, 0, 0, w, h);
      const url2 = canvas2.toDataURL("image/jpeg", attempt === 0 ? 0.82 : 0.75);
      if (url2.length <= opts.maxChars) return url2;
      side = Math.round(side * 0.75);
    }
    throw new Error("image too large");
  } finally {
    img.close();
  }
}

// client/chat/ui/panels/SettingsPanel.tsx
var import_jsx_runtime28 = __toESM(require_jsx_runtime(), 1);
var PRIVACY_OPTIONS = [
  { value: "everyone", label: "Everyone" },
  { value: "contacts", label: "Contacts" },
  { value: "nobody", label: "Nobody" }
];
var privacyLabel = (v) => PRIVACY_OPTIONS.find((o) => o.value === v)?.label ?? "Everyone";
var WALLPAPER_MAX_CHARS = 25e5;
var PASSWORD_MAX = 128;
var RESET_COOLDOWN_MS = 3e4;
var resetCooldownUntil = 0;
function Row({
  id,
  icon,
  label,
  value: value2,
  onClick,
  expanded,
  danger,
  busy
}) {
  return /* @__PURE__ */ (0, import_jsx_runtime28.jsxs)(
    "button",
    {
      type: "button",
      id,
      className: `settings-row${danger ? " settings-row-danger" : ""}`,
      "aria-expanded": expanded,
      "aria-busy": busy || void 0,
      onClick,
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime28.jsxs)("span", { className: "settings-row-left", children: [
          icon,
          /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("span", { children: label })
        ] }),
        value2 !== void 0 && /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("span", { className: "settings-row-value", children: value2 })
      ]
    }
  );
}
function Expand({ open: open2, className, children }) {
  const { mounted } = usePresence(open2, 250);
  return /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("div", { className: `settings-expand${open2 ? " open" : ""}`, children: /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("div", { className: "settings-expand-inner", children: mounted && /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("div", { className, children }) }) });
}
function AccentPicker({ accent, onPick }) {
  const custom = !ACCENT_PRESETS.some((p) => p.hex === accent);
  return /* @__PURE__ */ (0, import_jsx_runtime28.jsxs)("div", { className: "settings-accent-presets", role: "radiogroup", "aria-label": "Accent color", children: [
    ACCENT_PRESETS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(
      "button",
      {
        type: "button",
        role: "radio",
        "aria-checked": accent === p.hex,
        "aria-label": p.name,
        title: p.name,
        className: `accent-swatch${accent === p.hex ? " active" : ""}`,
        style: { background: p.hex },
        onClick: () => onPick(p.hex)
      },
      p.hex
    )),
    /* @__PURE__ */ (0, import_jsx_runtime28.jsxs)("label", { className: `accent-swatch accent-swatch-custom${custom ? " active" : ""}`, title: "Custom color", children: [
      /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(Icons.Eyedropper, {}),
      /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("input", { type: "color", className: "visually-hidden", "aria-label": "Custom color", value: accent, onChange: (e) => onPick(e.target.value) })
    ] })
  ] });
}
function WallpaperActions({ has, onChange }) {
  const input = (0, import_react26.useRef)(null);
  const [busy, setBusy] = (0, import_react26.useState)(false);
  const choose = async (file) => {
    if (file.type && !file.type.startsWith("image/")) {
      showToast("Please choose an image file", { icon: "error" });
      return;
    }
    setBusy(true);
    try {
      const dataUrl = await toJpegDataUrl(file, { maxSide: 1600, maxChars: WALLPAPER_MAX_CHARS });
      if (saveWallpaper(dataUrl)) showToast("Background updated", { icon: "check" });
      else {
        applyWallpaper(dataUrl);
        showToast("Background set, but this device has no room to keep it", { icon: "error", ms: 4e3 });
      }
      onChange(true);
    } catch {
      showToast("This image can't be used. Please try another one.", { icon: "error" });
    } finally {
      setBusy(false);
    }
  };
  return /* @__PURE__ */ (0, import_jsx_runtime28.jsxs)("div", { className: "settings-wallpaper-actions", children: [
    /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(
      "input",
      {
        ref: input,
        type: "file",
        accept: "image/*",
        hidden: true,
        onChange: (e) => {
          const file = e.target.files?.[0];
          e.target.value = "";
          if (file) void choose(file);
        }
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("button", { type: "button", className: "settings-wallpaper-btn", disabled: busy, onClick: () => input.current?.click(), children: busy ? "Preparing\u2026" : has ? "Change Image" : "Upload Image" }),
    has && /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(
      "button",
      {
        type: "button",
        className: "settings-wallpaper-btn settings-wallpaper-btn-remove",
        disabled: busy,
        onClick: () => {
          saveWallpaper(null);
          applyWallpaper(null);
          onChange(false);
          showToast("Background removed", { icon: "check" });
        },
        children: "Remove"
      }
    )
  ] });
}
async function savePrivacy(me, field, value2) {
  const before = me[field];
  if (before === value2) return;
  patchMe({ [field]: value2 });
  try {
    setMe(await usersApi.update({ [field]: value2 }));
    showToast("Saved", { icon: "check" });
  } catch (e) {
    patchMe({ [field]: before });
    showToast(errorText(e, "Couldn't save. Please try again."), { icon: "error" });
  }
}
function PrivacyPicker({ label, value: value2, onPick }) {
  return /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("div", { role: "radiogroup", "aria-label": `Who can see your ${label.toLowerCase()}`, children: PRIVACY_OPTIONS.map((o) => /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(
    "button",
    {
      type: "button",
      role: "radio",
      "aria-checked": value2 === o.value,
      className: `settings-picker-option${value2 === o.value ? " active" : ""}`,
      onClick: () => onPick(o.value),
      children: o.label
    },
    o.value
  )) });
}
var PUSH_LABEL = {
  unsupported: "Unavailable",
  blocked: "Blocked",
  off: "Off",
  on: "On",
  working: "\u2026"
};
function isIosBrowserTab() {
  const ios = /iPhone|iPad|iPod/.test(navigator.userAgent);
  const standalone = navigator.standalone === true;
  return ios && !standalone;
}
async function togglePush(state) {
  switch (state) {
    case "working":
      return;
    case "on":
      await disablePush();
      showToast("Notifications turned off", { icon: "bell" });
      return;
    case "unsupported":
      showToast(
        isIosBrowserTab() ? "To get notifications on iPhone, add Rivo to your Home Screen first" : "This browser can't show notifications",
        { icon: "error", ms: 4500 }
      );
      return;
    case "blocked":
      showToast("Notifications are blocked. Allow them in your browser's site settings.", { icon: "error", ms: 4500 });
      return;
    case "off": {
      const result = await enablePush(true);
      if (result === "on") showToast("Notifications turned on", { icon: "bell" });
      else if (result === "blocked") showToast("Notifications are blocked. Allow them in your browser's site settings.", { icon: "error", ms: 4500 });
      else if (result === "off" && Notification.permission === "granted") showToast("Couldn't turn on notifications. Please try again.", { icon: "error" });
    }
  }
}
function useCooldown(until) {
  const [now, setNow] = (0, import_react26.useState)(() => Date.now());
  (0, import_react26.useEffect)(() => {
    if (until <= Date.now()) return void 0;
    const t = window.setInterval(() => {
      setNow(Date.now());
      if (Date.now() >= until) window.clearInterval(t);
    }, 1e3);
    return () => window.clearInterval(t);
  }, [until]);
  return Math.max(0, Math.ceil((until - now) / 1e3));
}
function ChangePasswordForm({ me, onDone }) {
  const [current, setCurrent] = (0, import_react26.useState)("");
  const [next, setNext] = (0, import_react26.useState)("");
  const [confirm, setConfirm] = (0, import_react26.useState)("");
  const [busy, setBusy] = (0, import_react26.useState)(false);
  const [feedback, setFeedback] = (0, import_react26.useState)(null);
  const [cooldownUntil, setCooldownUntil] = (0, import_react26.useState)(resetCooldownUntil);
  const [sending, setSending] = (0, import_react26.useState)(false);
  const wait = useCooldown(cooldownUntil);
  const currentRef = (0, import_react26.useRef)(null);
  const nextRef = (0, import_react26.useRef)(null);
  const confirmRef = (0, import_react26.useRef)(null);
  const fail = (text, field) => {
    setFeedback({ ok: false, text });
    field?.current?.focus();
  };
  const submit = async () => {
    if (busy) return;
    if (!current) return fail("Enter your current password.", currentRef);
    if (next.length < 8) return fail("Your new password must be at least 8 characters.", nextRef);
    if (next.length > PASSWORD_MAX) return fail("Your new password is too long.", nextRef);
    if (next !== confirm) return fail("The new passwords don't match.", confirmRef);
    if (next === current) return fail("The new password must be different from the current one.", nextRef);
    setBusy(true);
    setFeedback(null);
    try {
      const { signedOut } = await usersApi.changePassword(current, next);
      showToast(signedOut > 0 ? "Password changed. Other devices were signed out." : "Password changed", { icon: "check", ms: 4e3 });
      onDone();
    } catch (e) {
      if (e instanceof ApiError && e.status === 403) fail("Your current password is incorrect.", currentRef);
      else fail(errorText(e, "Couldn't change your password. Please try again."));
    } finally {
      setBusy(false);
    }
  };
  const sendReset = async () => {
    if (sending || wait > 0) return;
    setSending(true);
    try {
      await authApi.requestPasswordReset();
      resetCooldownUntil = Date.now() + RESET_COOLDOWN_MS;
      setCooldownUntil(resetCooldownUntil);
      setFeedback({ ok: true, text: `A reset link is on its way to ${me.email}.` });
    } catch (e) {
      setFeedback({ ok: false, text: errorText(e, "Couldn't send the reset link. Please try again.") });
    } finally {
      setSending(false);
    }
  };
  return /* @__PURE__ */ (0, import_jsx_runtime28.jsxs)(
    "form",
    {
      noValidate: true,
      onSubmit: (e) => {
        e.preventDefault();
        void submit();
      },
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("input", { type: "text", name: "username", autoComplete: "username", value: me.username, readOnly: true, className: "visually-hidden", tabIndex: -1, "aria-hidden": "true" }),
        /* @__PURE__ */ (0, import_jsx_runtime28.jsxs)("div", { className: "settings-change-password-field", children: [
          /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("p", { className: "settings-hint", children: "Your password must be at least 8 characters long." }),
          /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(PasswordInput, { inputRef: currentRef, value: current, onChange: setCurrent, placeholder: "Current password", label: "Current password", autoComplete: "current-password", className: "settings-password-input", autoFocus: true })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("div", { className: "settings-change-password-field", children: /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(PasswordInput, { inputRef: nextRef, value: next, onChange: setNext, placeholder: "New password", label: "New password", autoComplete: "new-password", className: "settings-password-input" }) }),
        /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("div", { className: "settings-change-password-field", children: /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(PasswordInput, { inputRef: confirmRef, value: confirm, onChange: setConfirm, placeholder: "Confirm new password", label: "Confirm new password", autoComplete: "new-password", className: "settings-password-input" }) }),
        /* @__PURE__ */ (0, import_jsx_runtime28.jsxs)("div", { className: "settings-change-password-actions", children: [
          /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("button", { type: "submit", className: "settings-change-password-submit", disabled: busy, children: busy ? "Changing\u2026" : "Change Password" }),
          /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("button", { type: "button", className: "settings-send-reset-email", disabled: sending || wait > 0, onClick: () => void sendReset(), children: sending ? "Sending\u2026" : wait > 0 ? `Send again in ${wait}s` : "Send reset email" })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("p", { className: `settings-change-password-feedback${feedback ? feedback.ok ? " settings-feedback--ok" : " settings-feedback--error" : ""}`, role: "status", "aria-live": "polite", children: feedback?.text })
      ]
    }
  );
}
function Settings() {
  const me = useStore(session, (s) => s.me);
  const dark = useIsDark();
  const push = useStore(pushState, (s) => s.state);
  const archivedCount = useStore(contacts, (s) => Object.values(s.byConv).filter((r) => r.isArchived && !r.isSaved).length);
  const [open2, setOpen] = (0, import_react26.useState)(null);
  const [accent, setAccent] = (0, import_react26.useState)(() => storedAccent() ?? DEFAULT_ACCENT);
  const [hasWallpaper, setHasWallpaper] = (0, import_react26.useState)(() => storedWallpaper() !== null || document.documentElement.style.getPropertyValue("--chat-wallpaper") !== "");
  if (!me) return null;
  const toggle = (s) => setOpen((o) => o === s ? null : s);
  const pickAccent = (hex) => {
    const color = normalizeHex(hex);
    if (!color) return;
    saveAccent(color);
    setAccent(color);
  };
  const privacyRow = (field, id, label, icon) => /* @__PURE__ */ (0, import_jsx_runtime28.jsxs)(import_jsx_runtime28.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(Row, { id, icon, label, value: privacyLabel(me[field]), expanded: open2 === field, onClick: () => toggle(field) }),
    /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(Expand, { open: open2 === field, className: "settings-privacy-picker", children: /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(
      PrivacyPicker,
      {
        label,
        value: me[field],
        onPick: (v) => {
          setOpen(null);
          void savePrivacy(me, field, v);
        }
      }
    ) })
  ] });
  return /* @__PURE__ */ (0, import_jsx_runtime28.jsxs)(import_jsx_runtime28.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime28.jsxs)("div", { className: "settings-panel-header", children: [
      /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("button", { type: "button", className: "settings-panel-close", "aria-label": "Close settings", onClick: closePanel, children: /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(Icons.Close, {}) }),
      /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("h2", { children: "Settings" })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("h3", { className: "settings-section-label", id: "settings-customization", children: "Customization" }),
    /* @__PURE__ */ (0, import_jsx_runtime28.jsxs)("div", { className: "settings-group", role: "group", "aria-labelledby": "settings-customization", children: [
      /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(
        Row,
        {
          id: "settings-theme-row",
          icon: /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(Icons.Theme, {}),
          label: "Theme",
          value: dark ? "Dark" : "Light",
          onClick: () => {
            setOpen(null);
            saveTheme(dark ? "light" : "dark");
          }
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(
        Row,
        {
          id: "settings-accent-row",
          icon: /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(Icons.Palette, {}),
          label: "Accent Color",
          value: /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("span", { className: "settings-accent-dot", style: { background: accent } }),
          expanded: open2 === "accent",
          onClick: () => toggle("accent")
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(Expand, { open: open2 === "accent", className: "settings-accent-panel", children: /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(AccentPicker, { accent, onPick: pickAccent }) }),
      /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(
        Row,
        {
          id: "settings-wallpaper-row",
          icon: /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(Icons.Image, {}),
          label: "Chat Background",
          value: hasWallpaper ? "Custom" : "Default",
          expanded: open2 === "wallpaper",
          onClick: () => toggle("wallpaper")
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(Expand, { open: open2 === "wallpaper", className: "settings-accent-panel", children: /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(WallpaperActions, { has: hasWallpaper, onChange: setHasWallpaper }) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("h3", { className: "settings-section-label", id: "settings-privacy", children: "Privacy" }),
    /* @__PURE__ */ (0, import_jsx_runtime28.jsxs)("div", { className: "settings-group", role: "group", "aria-labelledby": "settings-privacy", children: [
      privacyRow("privacyOnline", "settings-privacy-online", "Online Status", /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(Icons.Online, {})),
      privacyRow("privacyEmail", "settings-privacy-email", "Email", /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(Icons.Email, {})),
      privacyRow("privacyProfile", "settings-privacy-profile", "Profile Picture", /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(Icons.Person, {}))
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("h3", { className: "settings-section-label", id: "settings-chats", children: "Chats" }),
    /* @__PURE__ */ (0, import_jsx_runtime28.jsxs)("div", { className: "settings-group", role: "group", "aria-labelledby": "settings-chats", children: [
      /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(
        Row,
        {
          id: "settings-notifications",
          icon: /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(Icons.Bell, {}),
          label: "Notifications",
          value: PUSH_LABEL[push],
          busy: push === "working",
          onClick: () => {
            setOpen(null);
            void togglePush(push);
          }
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(
        Row,
        {
          id: "settings-archived",
          icon: /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(Icons.ArchiveOutline, {}),
          label: "Archived Chats",
          value: archivedCount > 0 ? String(archivedCount) : void 0,
          onClick: () => {
            setOpen(null);
            openDialog("archived");
          }
        }
      )
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime28.jsx)("h3", { className: "settings-section-label", id: "settings-account", children: "Account" }),
    /* @__PURE__ */ (0, import_jsx_runtime28.jsxs)("div", { className: "settings-group", role: "group", "aria-labelledby": "settings-account", children: [
      /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(
        Row,
        {
          id: "settings-devices",
          icon: /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(Icons.Devices, {}),
          label: "Devices",
          onClick: () => {
            setOpen(null);
            openDialog("devices");
          }
        }
      ),
      /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(Row, { id: "settings-change-password", icon: /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(Icons.Lock, {}), label: "Change Password", expanded: open2 === "password", onClick: () => toggle("password") }),
      /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(Expand, { open: open2 === "password", className: "settings-change-password-form", children: /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(ChangePasswordForm, { me, onDone: () => setOpen(null) }) }),
      /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(
        Row,
        {
          id: "settings-delete-account",
          icon: /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(Icons.Delete, {}),
          label: "Delete Account",
          danger: true,
          onClick: () => {
            setOpen(null);
            openDialog("deleteAccount");
          }
        }
      )
    ] })
  ] });
}
function SettingsPanel({ phone }) {
  const open2 = useUi((s) => s.panel === "settings");
  return /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(ResponsivePanel, { open: open2, phone, panelClass: "settings-panel", dialogClass: "settings-dialog", onClose: closePanel, label: "Settings", children: /* @__PURE__ */ (0, import_jsx_runtime28.jsx)(Settings, {}) });
}

// client/chat/ui/people/PeoplePart.tsx
var import_react33 = __toESM(require_react(), 1);

// client/chat/ui/people/ActiveChats.tsx
var import_react28 = __toESM(require_react(), 1);

// client/chat/ui/people/ActiveChatCard.tsx
var import_react27 = __toESM(require_react(), 1);
var import_jsx_runtime29 = __toESM(require_jsx_runtime(), 1);
var SNAP_PX = 70;
var REVEAL_PX = 140;
var SAVED_REVEAL_PX = 70;
function offsetOf(side, saved) {
  if (side === "left") return -REVEAL_PX;
  if (side === "right") return saved ? SAVED_REVEAL_PX : REVEAL_PX;
  return 0;
}
function StatusIcon({ last, saved }) {
  if (!last.mine) return null;
  if (saved && !last.pending && !last.failed) return null;
  return /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("span", { className: "active-chat-status", children: last.failed ? /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(Icons.Failed, { size: 16 }) : last.pending ? /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(Icons.Spinner, { size: 14, className: "msg-pending-spinner" }) : last.seen ? /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(Icons.Seen, { size: 16 }) : /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(Icons.Sent, { size: 16 }) });
}
var ActiveChatCard = (0, import_react27.memo)(function ActiveChatCard2({ row, pending: pending3, meId: meId2, swipe, onSwipe, fading = false }) {
  const last = effectiveLast(row, pending3, meId2);
  const cardRef = (0, import_react27.useRef)(null);
  const drag = (0, import_react27.useRef)(null);
  const suppressClick = useClickSuppressor();
  const saved = row.isSaved;
  const name = displayName(row);
  const unread = row.unreadCount;
  (0, import_react27.useLayoutEffect)(() => {
    const el = cardRef.current;
    if (!el || drag.current?.horizontal) return;
    el.style.transition = "transform 0.25s ease";
    el.style.transform = `translateX(${offsetOf(swipe, saved)}px)`;
  }, [swipe, saved]);
  const clamp = (v) => Math.max(saved ? 0 : -REVEAL_PX, Math.min(saved ? SAVED_REVEAL_PX : REVEAL_PX, v));
  const onPointerDown = (e) => {
    if (e.button !== 0) return;
    drag.current = { id: e.pointerId, x: e.clientX, y: e.clientY, base: offsetOf(swipe, saved), horizontal: null, moved: 0 };
  };
  const onPointerMove = (e) => {
    const d = drag.current;
    const el = cardRef.current;
    if (!d || d.id !== e.pointerId || !el) return;
    const dx = e.clientX - d.x;
    const dy = e.clientY - d.y;
    if (d.horizontal === null) {
      if (Math.abs(dx) < 8 && Math.abs(dy) < 8) return;
      d.horizontal = Math.abs(dx) > Math.abs(dy);
      if (!d.horizontal) {
        drag.current = null;
        return;
      }
      el.setPointerCapture(e.pointerId);
      el.style.transition = "none";
    }
    d.moved = dx;
    el.style.transform = `translateX(${clamp(d.base + dx)}px)`;
  };
  const onPointerEnd = (e) => {
    const d = drag.current;
    drag.current = null;
    const el = cardRef.current;
    if (!d || d.id !== e.pointerId || !el || !d.horizontal) return;
    if (Math.abs(d.moved) > 5) suppressClick.arm();
    const total = d.base + d.moved;
    let side = "closed";
    if (total < -SNAP_PX && !saved) side = "left";
    else if (total > SNAP_PX) side = "right";
    el.style.transition = "transform 0.25s ease";
    el.style.transform = `translateX(${offsetOf(side, saved)}px)`;
    onSwipe(row.conversationId, side);
  };
  const onCardClick = () => {
    if (suppressClick.consume()) return;
    if (swipe !== "closed") {
      onSwipe(row.conversationId, "closed");
      return;
    }
    openChat(row.conversationId);
  };
  const action = (fn) => (e) => {
    e.stopPropagation();
    onSwipe(row.conversationId, "closed");
    fn();
  };
  return /* @__PURE__ */ (0, import_jsx_runtime29.jsxs)(
    "div",
    {
      className: `active-chat-wrapper${fading ? " fading-slow" : ""}`,
      "data-saved": saved ? "true" : "false",
      "data-conv": row.conversationId,
      style: fading ? { opacity: 0, pointerEvents: "none" } : void 0,
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime29.jsxs)("div", { className: "card-actions card-actions--left", children: [
          /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("button", { type: "button", className: "card-action-btn card-action-btn--delete", title: "Delete", tabIndex: swipe === "right" ? 0 : -1, onClick: action(() => deleteChat(row)), children: /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(Icons.Delete, {}) }),
          !saved && /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("button", { type: "button", className: "card-action-btn card-action-btn--archive", title: "Archive", tabIndex: swipe === "right" ? 0 : -1, onClick: action(() => void setArchived(row, true)), children: /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(Icons.Archive, {}) })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime29.jsxs)(
          "div",
          {
            ref: cardRef,
            className: `active-chat${row.isPinned ? " pinned" : ""}`,
            role: "button",
            tabIndex: 0,
            "aria-label": `Open chat with ${name}${unread ? `, ${unread} unread` : ""}`,
            "aria-keyshortcuts": "ArrowLeft ArrowRight",
            onPointerDown,
            onPointerMove,
            onPointerUp: onPointerEnd,
            onPointerCancel: (e) => {
              if (drag.current?.horizontal) onPointerEnd(e);
              else drag.current = null;
            },
            onClick: onCardClick,
            onKeyDown: (e) => {
              if (e.target !== e.currentTarget) return;
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                openChat(row.conversationId);
              } else if (e.key === "ArrowRight") {
                e.preventDefault();
                onSwipe(row.conversationId, swipe === "left" ? "closed" : "right");
              } else if (e.key === "ArrowLeft") {
                e.preventDefault();
                onSwipe(row.conversationId, swipe === "right" || saved ? "closed" : "left");
              } else if (e.key === "Escape" && swipe !== "closed") {
                onSwipe(row.conversationId, "closed");
              }
            },
            children: [
              saved ? /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("div", { className: "active-chat-profile active-chat-saved-icon", children: /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(Icons.Saved, {}) }) : /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(
                Avatar,
                {
                  name,
                  picture: row.contact?.profilePics[0],
                  className: `active-chat-profile${isOnline(row) ? " online" : ""}`,
                  online: isOnline(row),
                  deleted: isDeletedAccount(row)
                }
              ),
              /* @__PURE__ */ (0, import_jsx_runtime29.jsxs)("span", { className: "active-chat-info", children: [
                /* @__PURE__ */ (0, import_jsx_runtime29.jsxs)("span", { className: "active-chat-name", dir: "auto", children: [
                  /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("span", { className: "active-chat-name-text", children: name }),
                  row.isPinned && /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("span", { className: "active-chat-pin", children: /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(Icons.PinSolid, {}) })
                ] }),
                /* @__PURE__ */ (0, import_jsx_runtime29.jsxs)("span", { className: "active-chat-last-message", children: [
                  last && /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(StatusIcon, { last, saved }),
                  /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("span", { className: "active-chat-last-text", dir: "auto", children: last?.text ?? "" }),
                  row.isMuted && /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("span", { className: "active-chat-mute", children: /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(Icons.Mute, {}) })
                ] })
              ] }),
              /* @__PURE__ */ (0, import_jsx_runtime29.jsxs)("span", { className: "active-chat-meta", children: [
                /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("span", { className: "active-chat-message-time", children: listTime(last?.at) }),
                /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("span", { className: `active-chat-unread-messages ${unread > 0 ? "opacity-1" : "opacity-0"}`, children: /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("p", { children: unread > 999 ? "999+" : unread }) })
              ] })
            ]
          }
        ),
        !saved && /* @__PURE__ */ (0, import_jsx_runtime29.jsxs)("div", { className: "card-actions card-actions--right", children: [
          /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("button", { type: "button", className: "card-action-btn card-action-btn--mute", title: row.isMuted ? "Unmute" : "Mute", tabIndex: swipe === "left" ? 0 : -1, onClick: action(() => toggleMute(row)), children: row.isMuted ? /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(Icons.Unmute, {}) : /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(Icons.Mute, {}) }),
          /* @__PURE__ */ (0, import_jsx_runtime29.jsx)("button", { type: "button", className: "card-action-btn card-action-btn--pin", title: row.isPinned ? "Unpin" : "Pin", tabIndex: swipe === "left" ? 0 : -1, onClick: action(() => togglePinChat(row)), children: row.isPinned ? /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(Icons.Unpin, {}) : /* @__PURE__ */ (0, import_jsx_runtime29.jsx)(Icons.PinSolid, {}) })
        ] })
      ]
    }
  );
});

// client/chat/ui/people/ActiveChats.tsx
var import_jsx_runtime30 = __toESM(require_jsx_runtime(), 1);
function ActiveChats({ rows }) {
  const loaded = useStore(contacts, (s) => s.loaded);
  const meId2 = useMeId();
  const pending3 = useNewestPending();
  const cleared = useStore(undoing, (s) => s.clearedChats);
  const removed = useStore(undoing, (s) => s.removedContacts);
  const [swipe, setSwipe] = (0, import_react28.useState)(null);
  const section = (0, import_react28.useRef)(null);
  const onSwipe = (0, import_react28.useCallback)((convId, side) => {
    setSwipe(side === "closed" ? (s) => s?.convId === convId ? null : s : { convId, side });
  }, []);
  (0, import_react28.useEffect)(() => {
    if (!swipe) return void 0;
    const onDown = (e) => {
      const wrapper = e.target?.closest?.(".active-chat-wrapper");
      if (wrapper && wrapper.getAttribute("data-conv") === String(swipe.convId)) return;
      setSwipe(null);
    };
    document.addEventListener("pointerdown", onDown, true);
    return () => document.removeEventListener("pointerdown", onDown, true);
  }, [swipe]);
  return /* @__PURE__ */ (0, import_jsx_runtime30.jsxs)("section", { ref: section, className: "active-chats-container", "aria-busy": !loaded, "aria-label": "Active chats", children: [
    /* @__PURE__ */ (0, import_jsx_runtime30.jsx)("h4", { className: "guid", children: "Active Chats" }),
    !loaded ? /* @__PURE__ */ (0, import_jsx_runtime30.jsx)(ActiveChatSkeletons, {}) : rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime30.jsx)(
      ActiveChatCard,
      {
        row,
        pending: pending3[row.conversationId],
        meId: meId2,
        swipe: swipe?.convId === row.conversationId ? swipe.side : "closed",
        onSwipe,
        fading: !!cleared[row.conversationId] || !!removed[row.conversationId]
      },
      row.conversationId
    ))
  ] });
}

// client/chat/ui/people/AllContacts.tsx
var import_react30 = __toESM(require_react(), 1);

// client/chat/ui/people/ContactCard.tsx
var import_react29 = __toESM(require_react(), 1);
var import_jsx_runtime31 = __toESM(require_jsx_runtime(), 1);
var ContactCard = (0, import_react29.memo)(function ContactCard2({ row, meId: meId2, fading = false }) {
  const [menuOpen, setMenuOpen] = (0, import_react29.useState)(false);
  const card = (0, import_react29.useRef)(null);
  useOutsidePointer([card], () => setMenuOpen(false), menuOpen);
  useEscape(() => setMenuOpen(false), menuOpen);
  const name = displayName(row);
  const preview = previewText(row.lastMessage, meId2);
  const hasMessages = !!row.lastMessage;
  const act = (fn) => (e) => {
    e.stopPropagation();
    setMenuOpen(false);
    fn();
  };
  const open2 = () => {
    if (menuOpen) setMenuOpen(false);
    else openChat(row.conversationId);
  };
  return /* @__PURE__ */ (0, import_jsx_runtime31.jsxs)(
    "div",
    {
      ref: card,
      className: `contacts-card${fading ? " fading-slow" : ""}`,
      style: fading ? { opacity: 0, pointerEvents: "none" } : void 0,
      onClick: open2,
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime31.jsxs)(
          "button",
          {
            type: "button",
            className: "card-open-btn visually-hidden",
            tabIndex: menuOpen ? -1 : 0,
            onClick: (e) => {
              e.stopPropagation();
              open2();
            },
            children: [
              "Open chat with ",
              name
            ]
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime31.jsx)(
          "button",
          {
            type: "button",
            className: `contact-menu-btn${menuOpen ? " contact-menu-btn--back" : ""}`,
            "aria-label": menuOpen ? "Close options" : "Chat options",
            "aria-expanded": menuOpen,
            onClick: (e) => {
              e.stopPropagation();
              setMenuOpen((v) => !v);
            },
            children: menuOpen ? /* @__PURE__ */ (0, import_jsx_runtime31.jsx)(Icons.Back, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime31.jsx)(Icons.Dots, {})
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime31.jsx)(
          "div",
          {
            className: `contact-menu-overlay${menuOpen ? " active" : ""}`,
            onClick: (e) => {
              e.stopPropagation();
              setMenuOpen(false);
            }
          }
        ),
        /* @__PURE__ */ (0, import_jsx_runtime31.jsxs)("div", { className: `contact-menu-panel${menuOpen ? " active" : ""}`, children: [
          /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("button", { type: "button", className: "contact-menu-item", tabIndex: menuOpen ? 0 : -1, "aria-label": row.isMuted ? "Unmute" : "Mute", onClick: act(() => toggleMute(row)), children: /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("span", { className: "contact-menu-icon", children: row.isMuted ? /* @__PURE__ */ (0, import_jsx_runtime31.jsx)(Icons.Unmute, {}) : /* @__PURE__ */ (0, import_jsx_runtime31.jsx)(Icons.Mute, {}) }) }),
          /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("button", { type: "button", className: "contact-menu-item", tabIndex: menuOpen ? 0 : -1, "aria-label": row.isPinned ? "Unpin" : "Pin", onClick: act(() => togglePinChat(row)), children: /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("span", { className: "contact-menu-icon", children: row.isPinned ? /* @__PURE__ */ (0, import_jsx_runtime31.jsx)(Icons.Unpin, { size: 18 }) : /* @__PURE__ */ (0, import_jsx_runtime31.jsx)(Icons.Pin, { size: 18 }) }) }),
          hasMessages && /* @__PURE__ */ (0, import_jsx_runtime31.jsx)(
            "button",
            {
              type: "button",
              className: "contact-menu-item contact-menu-item--danger",
              tabIndex: menuOpen ? 0 : -1,
              "aria-label": "Delete chat",
              onClick: act(() => deleteChat(row)),
              children: /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("span", { className: "contact-menu-icon", children: /* @__PURE__ */ (0, import_jsx_runtime31.jsx)(Icons.Delete, { size: 18 }) })
            }
          )
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime31.jsx)(Avatar, { name, picture: row.contact?.profilePics[0], className: "contact-profile", online: isOnline(row), deleted: isDeletedAccount(row) }),
        /* @__PURE__ */ (0, import_jsx_runtime31.jsxs)("span", { className: "contact-name", dir: "auto", children: [
          /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("span", { className: "contact-name-text", children: name }),
          row.isMuted && /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("span", { className: "contact-muted-icon", children: /* @__PURE__ */ (0, import_jsx_runtime31.jsx)(Icons.Mute, {}) })
        ] }),
        /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("span", { className: "contact-message", children: row.isBlocked ? /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("span", { className: "blocked-badge", children: "Blocked" }) : !hasMessages ? /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("span", { className: "send-message", children: "Send message" }) : /* @__PURE__ */ (0, import_jsx_runtime31.jsx)("span", { className: "last-message", dir: "auto", children: preview }) })
      ]
    }
  );
});

// client/chat/ui/people/AllContacts.tsx
var import_jsx_runtime32 = __toESM(require_jsx_runtime(), 1);
function AllContacts({ rows, phone, chatOpen }) {
  const open2 = useUi((s) => s.allContactsOpen);
  const visible2 = open2 && (phone || !chatOpen);
  const { mounted, state } = usePresence(visible2, phone ? 300 : 0);
  const [query, setQuery] = (0, import_react30.useState)("");
  const meId2 = useMeId();
  const cleared = useStore(undoing, (s) => s.clearedChats);
  const removed = useStore(undoing, (s) => s.removedContacts);
  const section = (0, import_react30.useRef)(null);
  const list = (0, import_react30.useRef)(null);
  const input = (0, import_react30.useRef)(null);
  const savedScroll = (0, import_react30.useRef)(0);
  (0, import_react30.useEffect)(() => {
    if (open2) return;
    setQuery("");
    savedScroll.current = 0;
  }, [open2]);
  const matched = (0, import_react30.useMemo)(() => {
    const q = normalizeForSearch(query.trim());
    if (!q) return rows;
    return rows.filter((r) => normalizeForSearch(displayName(r)).includes(q) || normalizeForSearch(r.contact?.username ?? "").includes(q));
  }, [rows, query]);
  (0, import_react30.useLayoutEffect)(() => {
    const el = section.current;
    if (!el) return void 0;
    if (!visible2 || phone) {
      el.style.height = "";
      return void 0;
    }
    const people = document.getElementById("people-part");
    const fit = () => {
      if (!people || !el.getClientRects().length) return;
      const offset = el.getBoundingClientRect().top - people.getBoundingClientRect().top + people.scrollTop;
      el.style.height = `${Math.max(260, people.clientHeight - offset)}px`;
    };
    people?.scrollTo({ top: 0, behavior: "instant" });
    fit();
    window.addEventListener("resize", fit);
    return () => window.removeEventListener("resize", fit);
  }, [visible2, phone, mounted]);
  (0, import_react30.useLayoutEffect)(() => {
    if (visible2 && list.current) list.current.scrollTop = savedScroll.current;
  }, [visible2]);
  (0, import_react30.useEffect)(() => {
    if (visible2 && !phone && window.matchMedia("(hover: hover)").matches) input.current?.focus({ preventScroll: true });
  }, [visible2, phone]);
  if (!mounted) return null;
  const anim = phone ? state === "enter" ? " slide-in" : state === "exit" ? " slide-out" : "" : "";
  return /* @__PURE__ */ (0, import_jsx_runtime32.jsxs)("section", { ref: section, className: `all-contacts-section is-open${anim}`, "aria-label": "All contacts", children: [
    /* @__PURE__ */ (0, import_jsx_runtime32.jsxs)("header", { className: "all-contacts-header", children: [
      /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("button", { type: "button", className: "all-contacts-back", "aria-label": "Back", onClick: closeAllContacts, children: /* @__PURE__ */ (0, import_jsx_runtime32.jsx)(Icons.Back, { size: 22 }) }),
      /* @__PURE__ */ (0, import_jsx_runtime32.jsxs)("div", { className: "all-contacts-search-bar", children: [
        /* @__PURE__ */ (0, import_jsx_runtime32.jsx)(Icons.SearchLine, {}),
        /* @__PURE__ */ (0, import_jsx_runtime32.jsx)(
          "input",
          {
            ref: input,
            type: "search",
            className: "all-contacts-search",
            placeholder: "Search contacts",
            autoComplete: "off",
            enterKeyHint: "search",
            value: query,
            onChange: (e) => {
              setQuery(e.target.value);
              if (list.current) list.current.scrollTop = 0;
            },
            onKeyDown: (e) => {
              if (e.key !== "Escape") return;
              e.preventDefault();
              if (query) setQuery("");
              else closeAllContacts();
            }
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("div", { ref: list, className: "all-contacts-list", onScroll: (e) => savedScroll.current = e.currentTarget.scrollTop, children: matched.map((row) => /* @__PURE__ */ (0, import_jsx_runtime32.jsx)(ContactCard, { row, meId: meId2, fading: !!cleared[row.conversationId] || !!removed[row.conversationId] }, row.conversationId)) }),
    matched.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime32.jsx)("p", { className: "all-contacts-empty", children: "No contact found" })
  ] });
}

// client/chat/ui/people/ContactsSection.tsx
var import_jsx_runtime33 = __toESM(require_jsx_runtime(), 1);
var PREVIEW_COUNT = 8;
function ContactsSection({ rows }) {
  const loaded = useStore(contacts, (s) => s.loaded);
  const nobody = useStore(contacts, (s) => s.loaded && !Object.values(s.byConv).some((r) => !r.isSaved));
  const meId2 = useMeId();
  const cleared = useStore(undoing, (s) => s.clearedChats);
  const removed = useStore(undoing, (s) => s.removedContacts);
  return /* @__PURE__ */ (0, import_jsx_runtime33.jsxs)("section", { className: "contacts-container", "aria-busy": !loaded, "aria-label": "Contacts", children: [
    /* @__PURE__ */ (0, import_jsx_runtime33.jsx)("h4", { className: "guid", children: "Contacts" }),
    nobody && /* @__PURE__ */ (0, import_jsx_runtime33.jsxs)("div", { className: "contacts-empty", children: [
      /* @__PURE__ */ (0, import_jsx_runtime33.jsx)(Icons.People, {}),
      /* @__PURE__ */ (0, import_jsx_runtime33.jsx)("p", { children: "No contacts yet" })
    ] }),
    !loaded ? /* @__PURE__ */ (0, import_jsx_runtime33.jsx)(ContactSkeletons, {}) : rows.slice(0, PREVIEW_COUNT).map((row) => /* @__PURE__ */ (0, import_jsx_runtime33.jsx)(
      ContactCard,
      {
        row,
        meId: meId2,
        fading: !!cleared[row.conversationId] || !!removed[row.conversationId]
      },
      row.conversationId
    )),
    loaded && rows.length > PREVIEW_COUNT && /* @__PURE__ */ (0, import_jsx_runtime33.jsx)("div", { className: "contacts-fade", children: /* @__PURE__ */ (0, import_jsx_runtime33.jsx)("button", { type: "button", className: "contacts-show-more", onClick: openAllContacts, children: "Show more" }) })
  ] });
}

// client/chat/ui/people/Header.tsx
var import_react31 = __toESM(require_react(), 1);
var import_jsx_runtime34 = __toESM(require_jsx_runtime(), 1);
function SettingsMenu() {
  const [open2, setOpen] = (0, import_react31.useState)(false);
  const ref = (0, import_react31.useRef)(null);
  useOutsidePointer([ref], () => setOpen(false), open2);
  const onSettings = () => {
    const list = ref.current;
    const expanded = open2 || !!list && (window.matchMedia("(hover: hover)").matches && list.matches(":hover") || !!list.querySelector(":focus-visible"));
    if (!expanded) {
      setOpen(true);
      return;
    }
    setOpen(false);
    ref.current?.querySelector(":focus")?.blur();
    openPanel("settings");
  };
  const onEdit = () => {
    setOpen(false);
    ref.current?.querySelector(":focus")?.blur();
    openPanel("editProfile");
  };
  const onLogout = async () => {
    try {
      await logout();
    } catch {
      showToast("Couldn't log out. Check your connection and try again.", { icon: "error" });
    }
  };
  return /* @__PURE__ */ (0, import_jsx_runtime34.jsxs)(import_jsx_runtime34.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime34.jsx)("span", { className: "settings", "aria-hidden": "true", children: /* @__PURE__ */ (0, import_jsx_runtime34.jsx)(Icons.Gear, {}) }),
    /* @__PURE__ */ (0, import_jsx_runtime34.jsxs)("ul", { ref, className: `settings-list${open2 ? " open" : ""}`, "aria-label": "Menu", children: [
      /* @__PURE__ */ (0, import_jsx_runtime34.jsxs)("li", { className: "settings-section", ...pressable(onSettings), "aria-label": "Settings", children: [
        /* @__PURE__ */ (0, import_jsx_runtime34.jsx)(Icons.Gear, { className: "settings-icon" }),
        /* @__PURE__ */ (0, import_jsx_runtime34.jsx)("span", { children: "Settings" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime34.jsxs)("li", { className: "edit-section", ...pressable(onEdit), children: [
        /* @__PURE__ */ (0, import_jsx_runtime34.jsx)(Icons.Edit, {}),
        /* @__PURE__ */ (0, import_jsx_runtime34.jsx)("span", { children: "Edit Profile" })
      ] }),
      /* @__PURE__ */ (0, import_jsx_runtime34.jsxs)("li", { className: "logout-section", ...pressable(() => void onLogout()), children: [
        /* @__PURE__ */ (0, import_jsx_runtime34.jsx)(Icons.Logout, {}),
        /* @__PURE__ */ (0, import_jsx_runtime34.jsx)("span", { children: "Log Out" })
      ] })
    ] })
  ] });
}
function SearchBox() {
  const search = useUi((s) => s.search);
  const [text, setText] = (0, import_react31.useState)(search.query);
  const bar = (0, import_react31.useRef)(null);
  const input = (0, import_react31.useRef)(null);
  (0, import_react31.useEffect)(() => {
    if (!search.open && !search.query) setText("");
  }, [search.open, search.query]);
  (0, import_react31.useEffect)(() => {
    const q = text.trim();
    if (q === search.query) return void 0;
    const t = window.setTimeout(() => setSearchQuery(q), 250);
    return () => window.clearTimeout(t);
  }, [text, search.query]);
  useOutsidePointer([bar, searchResultsRef], () => closeSearch(), search.open);
  return /* @__PURE__ */ (0, import_jsx_runtime34.jsxs)(
    "span",
    {
      ref: bar,
      className: `search-bar${search.open ? " open" : ""}`,
      onClick: (e) => {
        if (e.target === input.current) {
          openSearch();
          return;
        }
        if (search.open) closeSearch();
        else {
          openSearch();
          input.current?.focus();
        }
      },
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime34.jsx)(Icons.Search, {}),
        /* @__PURE__ */ (0, import_jsx_runtime34.jsx)(
          "input",
          {
            ref: input,
            type: "text",
            enterKeyHint: "search",
            placeholder: "Search...",
            className: "search-input",
            name: "search",
            "aria-label": "Search contacts and messages",
            autoComplete: "off",
            value: text,
            maxLength: 100,
            onFocus: openSearch,
            onChange: (e) => setText(e.target.value),
            onKeyDown: (e) => {
              if (e.key === "Escape") {
                closeSearch();
                input.current?.blur();
              }
            }
          }
        )
      ]
    }
  );
}
function Header({ hidden }) {
  return /* @__PURE__ */ (0, import_jsx_runtime34.jsxs)("header", { className: "main-header", style: hidden ? { display: "none" } : void 0, children: [
    /* @__PURE__ */ (0, import_jsx_runtime34.jsx)(SettingsMenu, {}),
    /* @__PURE__ */ (0, import_jsx_runtime34.jsx)(SearchBox, {}),
    /* @__PURE__ */ (0, import_jsx_runtime34.jsx)("span", { className: "add-friends", ...pressable(() => openDialog("addContact")), "aria-label": "Add contact", children: /* @__PURE__ */ (0, import_jsx_runtime34.jsx)(Icons.AddFriend, {}) })
  ] });
}

// client/chat/ui/people/SearchResults.tsx
var import_react32 = __toESM(require_react(), 1);
var import_jsx_runtime35 = __toESM(require_jsx_runtime(), 1);
var MAX_CONTACTS = 50;
var NOOP = () => void 0;
var NO_HANDLERS = {
  onMenu: NOOP,
  onReply: NOOP,
  onToggle: NOOP,
  onQuote: NOOP,
  onReact: NOOP,
  onRetry: NOOP,
  onDiscard: NOOP,
  onCopy: NOOP
};
function hitBubble(h, meId2) {
  const mine = h.senderId === meId2;
  return {
    key: `s${h.id}`,
    id: h.id,
    clientId: null,
    mine,
    text: h.text,
    createdAt: h.createdAt,
    isEdited: h.isEdited,
    isPinned: h.isPinned,
    isOneTime: h.isOneTime,
    isTimeCapsule: h.isTimeCapsule,
    isLocked: h.isLocked,
    scheduledFor: h.scheduledFor,
    openedAt: h.openedAt,
    reply: null,
    forwardedFrom: null,
    reactions: [],
    status: mine ? h.isSeen ? "seen" : "sent" : null,
    error: null,
    unseen: false
  };
}
function SearchResults({ query }) {
  const byConv = useStore(contacts, (s) => s.byConv);
  const meId2 = useMeId();
  const [found, setFound] = (0, import_react32.useState)({ kind: "loading" });
  const people = (0, import_react32.useMemo)(() => {
    const q = normalizeForSearch(query);
    return Object.values(byConv).filter((r) => !r.isBlocked && (normalizeForSearch(displayName(r)).includes(q) || normalizeForSearch(r.contact?.username ?? "").includes(q))).slice(0, MAX_CONTACTS);
  }, [byConv, query]);
  (0, import_react32.useEffect)(() => {
    const ctrl = new AbortController();
    setFound({ kind: "loading" });
    messagesApi.search(query, ctrl.signal).then((res) => setFound({ kind: "done", hits: res.results })).catch((e) => {
      if (e?.name === "AbortError") return;
      setFound({
        kind: "error",
        text: e instanceof ApiError && e.status === 429 ? "Too many searches. Please wait a moment." : "Search failed"
      });
    });
    return () => ctrl.abort();
  }, [query]);
  const go = (convId, messageId) => {
    closeSearch();
    openChat(convId, { focusMessageId: messageId });
  };
  return /* @__PURE__ */ (0, import_jsx_runtime35.jsxs)("div", { ref: searchResultsRef, className: "search-results", id: "search-results", children: [
    /* @__PURE__ */ (0, import_jsx_runtime35.jsxs)("section", { className: "search-contacts-section", "aria-label": "Contacts found", children: [
      /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("h4", { className: "guid", children: "Contacts" }),
      /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("div", { className: "search-contacts-list", children: people.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("p", { className: "search-no-results", children: "No contacts found" }) : people.map((row) => /* @__PURE__ */ (0, import_jsx_runtime35.jsx)(ContactCard, { row, meId: meId2 }, row.conversationId)) })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime35.jsxs)("section", { className: "search-messages-section", "aria-label": "Messages found", children: [
      /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("h4", { className: "guid", children: "Conversations" }),
      /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("div", { className: "search-messages-list", children: found.kind === "loading" ? /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("p", { className: "search-no-results", children: "Searching\u2026" }) : found.kind === "error" ? /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("p", { className: "search-no-results", children: found.text }) : found.hits.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("p", { className: "search-no-results", children: "No messages found" }) : found.hits.map((h) => {
        const row = byConv[h.conversationId];
        if (!row) return null;
        return /* @__PURE__ */ (0, import_jsx_runtime35.jsxs)(
          "div",
          {
            className: "search-message-result",
            role: "button",
            tabIndex: 0,
            onClick: () => go(h.conversationId, h.id),
            onKeyDown: (e) => {
              if (e.key === "Enter" || e.key === " ") {
                e.preventDefault();
                go(h.conversationId, h.id);
              }
            },
            children: [
              /* @__PURE__ */ (0, import_jsx_runtime35.jsx)("p", { className: "search-message-sender", children: displayName(row) }),
              /* @__PURE__ */ (0, import_jsx_runtime35.jsx)(
                MessageBubble,
                {
                  data: hitBubble(h, meId2),
                  meId: meId2,
                  selecting: false,
                  selected: false,
                  fading: false,
                  vanishing: false,
                  highlighted: false,
                  canReply: false,
                  handlers: NO_HANDLERS,
                  passive: true
                }
              )
            ]
          },
          h.id
        );
      }) })
    ] })
  ] });
}

// client/chat/ui/people/PeoplePart.tsx
var import_jsx_runtime36 = __toESM(require_jsx_runtime(), 1);
function PeoplePart({ phone }) {
  const lists = useChatLists();
  const chatOpen = useUi((s) => s.openConvId !== null);
  const allOpen = useUi((s) => s.allContactsOpen);
  const query = useUi((s) => s.search.query);
  const searching = query.trim().length >= 2;
  const [headerHidden, setHeaderHidden] = (0, import_react33.useState)(false);
  (0, import_react33.useEffect)(() => {
    if (!phone || !chatOpen) {
      setHeaderHidden(false);
      return void 0;
    }
    const t = window.setTimeout(() => setHeaderHidden(true), 200);
    return () => window.clearTimeout(t);
  }, [phone, chatOpen]);
  const classes = ["main-content"];
  if (!phone && chatOpen) classes.push("flex-column-reverse");
  if (allOpen && (phone || !chatOpen)) classes.push("all-contacts-open");
  return /* @__PURE__ */ (0, import_jsx_runtime36.jsxs)("div", { className: "people-part", id: "people-part", children: [
    /* @__PURE__ */ (0, import_jsx_runtime36.jsx)(Header, { hidden: headerHidden }),
    /* @__PURE__ */ (0, import_jsx_runtime36.jsxs)("div", { className: classes.join(" "), id: "main-content", style: searching ? { display: "none" } : void 0, children: [
      /* @__PURE__ */ (0, import_jsx_runtime36.jsx)(ContactsSection, { rows: lists.contacts }),
      /* @__PURE__ */ (0, import_jsx_runtime36.jsx)(AllContacts, { rows: lists.contacts, phone, chatOpen }),
      /* @__PURE__ */ (0, import_jsx_runtime36.jsx)(ActiveChats, { rows: lists.active })
    ] }),
    searching && /* @__PURE__ */ (0, import_jsx_runtime36.jsx)(SearchResults, { query: query.trim() })
  ] });
}

// client/chat/ui/App.tsx
var import_jsx_runtime37 = __toESM(require_jsx_runtime(), 1);
function App() {
  const phone = useIsPhone();
  const forwarding = useUi((s) => s.dialog === "forward" && s.forwarding !== null);
  return /* @__PURE__ */ (0, import_jsx_runtime37.jsxs)(import_jsx_runtime37.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime37.jsxs)("main", { className: "parts", children: [
      /* @__PURE__ */ (0, import_jsx_runtime37.jsx)(PeoplePart, { phone }),
      /* @__PURE__ */ (0, import_jsx_runtime37.jsx)(ChatPart, { phone })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime37.jsx)(ProfilePanel, { phone }),
    /* @__PURE__ */ (0, import_jsx_runtime37.jsx)(EditProfilePanel, { phone }),
    /* @__PURE__ */ (0, import_jsx_runtime37.jsx)(SettingsPanel, { phone }),
    /* @__PURE__ */ (0, import_jsx_runtime37.jsx)(AddContactDialog, {}),
    /* @__PURE__ */ (0, import_jsx_runtime37.jsx)(ArchivedDialog, {}),
    /* @__PURE__ */ (0, import_jsx_runtime37.jsx)(DevicesDialog, {}),
    /* @__PURE__ */ (0, import_jsx_runtime37.jsx)(DeleteAccountDialog, {}),
    forwarding && /* @__PURE__ */ (0, import_jsx_runtime37.jsx)(ForwardDialog, {}),
    /* @__PURE__ */ (0, import_jsx_runtime37.jsx)(InAppNotifications, {}),
    /* @__PURE__ */ (0, import_jsx_runtime37.jsx)(Toaster, {}),
    /* @__PURE__ */ (0, import_jsx_runtime37.jsx)(ConnectionStatus, {})
  ] });
}

// client/chat/main.tsx
var import_jsx_runtime38 = __toESM(require_jsx_runtime(), 1);
function positiveInt(v) {
  const n = typeof v === "string" ? Number(v) : typeof v === "number" ? v : NaN;
  return Number.isSafeInteger(n) && n > 0 ? n : null;
}
function takeLinkFromUrl() {
  const params = new URLSearchParams(location.search);
  const conversationId = positiveInt(params.get("conversationId"));
  if (params.has("conversationId") || params.has("messageId")) history.replaceState(history.state, "", location.pathname);
  return conversationId ? { conversationId, messageId: positiveInt(params.get("messageId")) } : null;
}
var contactsReady = false;
var waitingLink = null;
function openLink(link) {
  if (!contactsReady) {
    waitingLink = link;
    return;
  }
  if (getRow(link.conversationId)) openChat(link.conversationId, { focusMessageId: link.messageId });
  else showToast("This chat is no longer available", { icon: "error" });
}
function listenToServiceWorker() {
  if (!("serviceWorker" in navigator)) return;
  navigator.serviceWorker.addEventListener("message", (e) => {
    const data = e.data;
    if (!data || typeof data !== "object" || data.type !== "push:click") return;
    const payload = data.payload ?? {};
    const conversationId = positiveInt(payload.conversationId);
    if (conversationId) openLink({ conversationId, messageId: positiveInt(payload.messageId) });
  });
}
function trackViewport() {
  const vv = window.visualViewport;
  if (!vv) return;
  const root = document.documentElement.style;
  let frame = 0;
  const update = () => {
    frame = 0;
    if (Math.abs(vv.scale - 1) > 0.01) return;
    root.setProperty("--viewport-height", `${Math.round(vv.height)}px`);
    root.setProperty("--viewport-top", `${Math.round(vv.offsetTop)}px`);
  };
  const schedule = () => {
    if (!frame) frame = requestAnimationFrame(update);
  };
  vv.addEventListener("resize", schedule);
  vv.addEventListener("scroll", schedule);
  update();
}
function offerNotifications() {
  if (read(keys.notifyAsked) || !("Notification" in window) || Notification.permission !== "default") return;
  let tries = 0;
  const offer = () => {
    if (pushState.get().state !== "off" || Notification.permission !== "default") return;
    if (toasts.get().current || ui.get().dialog || ui.get().panel) {
      if (++tries < 10) window.setTimeout(offer, 5e3);
      return;
    }
    write(keys.notifyAsked, "1");
    showToast("Get notified about new messages?", {
      icon: "bell",
      ms: 8e3,
      action: {
        label: "Turn on",
        run: () => {
          void enablePush(true).then((r) => {
            if (r === "on") showToast("Notifications turned on", { icon: "bell" });
          });
        }
      }
    });
  };
  window.setTimeout(offer, 4e3);
}
async function start2() {
  applyStoredAppearance();
  trackViewport();
  setUnauthorizedHandler(() => void sessionEnded(true));
  setHeaderProvider(() => {
    const id = socketId();
    return id ? { "X-Socket-Id": id } : {};
  });
  const cached = cachedMe();
  if (cached) setMe(cached);
  const fresh = usersApi.me().then(
    (me2) => {
      setMe(me2);
      return me2;
    },
    (e) => {
      if (e instanceof ApiError && e.status === 401) return null;
      if (!cached) throw e;
      return cached;
    }
  );
  let me = cached;
  if (!me) {
    try {
      me = await fresh;
    } catch {
      const root = document.getElementById("root");
      if (root) {
        const p = document.createElement("p");
        p.className = "boot-error";
        p.textContent = "Can't reach Rivo right now. Trying again\u2026";
        root.replaceChildren(p);
      }
      window.setTimeout(() => location.reload(), 5e3);
      return;
    }
  }
  if (!me) {
    window.location.replace(SIGN_IN_PAGE);
    return;
  }
  const userId = me.id;
  const otherAccount = (m) => {
    if (!m || m.id === userId) return false;
    location.reload();
    return true;
  };
  const confirmed = (check) => check.then(
    (m) => otherAccount(m) ? new Promise(() => void 0) : void 0,
    () => void 0
  );
  holdSends(confirmed(fresh));
  window.addEventListener("storage", (e) => {
    if (e.key !== keys.user || !e.newValue) return;
    try {
      otherAccount(JSON.parse(e.newValue));
    } catch {
    }
  });
  restoreOutbox(userId);
  persistOutbox(userId);
  installEventHandlers();
  installExitFlush();
  listenToServiceWorker();
  const link = takeLinkFromUrl();
  connect({
    onConnect(first) {
      if (!first) holdSends(confirmed(usersApi.me()));
      const open2 = ui.get().openConvId;
      if (open2 !== null) send("conversation:join", { conversationId: open2 });
      requeueAfterReconnect();
      if (!first || contacts.get().loaded) void refreshContacts().catch(() => void 0);
      if (open2 !== null) {
        void catchUpPersistently(open2);
        if (!first) void loadPinned(open2).catch(() => void 0);
      }
    },
    onDisconnect() {
      markAllStale(serverNow(-silentForMs() - 3e4));
      clearAllTyping();
    },
    onSessionEnded(certain) {
      void sessionEnded(certain);
    }
  });
  (0, import_client.createRoot)(document.getElementById("root")).render(
    /* @__PURE__ */ (0, import_jsx_runtime38.jsx)(import_react34.StrictMode, { children: /* @__PURE__ */ (0, import_jsx_runtime38.jsx)(App, {}) })
  );
  void registerServiceWorker();
  initPush();
  try {
    await loadContactsUntilDone();
  } catch {
    return;
  }
  contactsReady = true;
  const target = waitingLink ?? link;
  waitingLink = null;
  if (target) openLink(target);
  offerNotifications();
}
void start2();
//# sourceMappingURL=chat-VBO4HSHT.js.map
