import "./chunks/chunk-RWXBUR7X.js";
import {
  ApiError,
  PasswordInput,
  authApi,
  errorText,
  keys,
  read,
  write,
  writeJson
} from "./chunks/chunk-OXYREE6K.js";
import {
  require_client,
  require_jsx_runtime,
  require_react
} from "./chunks/chunk-GRWXGSY5.js";
import {
  __toESM
} from "./chunks/chunk-EXRSNSHP.js";

// client/auth/main.tsx
var import_react2 = __toESM(require_react(), 1);
var import_client = __toESM(require_client(), 1);

// client/auth/AuthApp.tsx
var import_react = __toESM(require_react(), 1);
var import_jsx_runtime = __toESM(require_jsx_runtime(), 1);
var EMAIL_RE = /^[^\s@.]+(\.[^\s@.]+)*@[^\s@.]+(\.[^\s@.]+)+$/;
var isEmail = (v) => v.length <= 254 && EMAIL_RE.test(v);
var USERNAME_RE = /^[a-zA-Z0-9_]{3,30}$/;
var PASSWORD_MIN = 8;
var PASSWORD_MAX = 128;
var CODE_LENGTH = 6;
var RESEND_MS = 6e4;
var REMEMBERED = "rememberedUser";
var RESEND_KEY = "resendCooldown";
var CHAT_PAGE = "/chat/";
function FieldError({ id, text }) {
  if (!text) return null;
  return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "input-error", id, role: "alert", children: text });
}
function TextField({
  id,
  label,
  error,
  value,
  onChange,
  inputRef,
  ...rest
}) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { htmlFor: id, className: "form-label", children: label }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "input",
      {
        ref: inputRef,
        id,
        name: id,
        className: "form-input",
        value,
        "aria-invalid": error ? true : void 0,
        "aria-describedby": error ? `${id}-error` : void 0,
        spellCheck: false,
        onChange: (e) => onChange(e.target.value),
        ...rest,
        type: rest.type ?? "text"
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { id: `${id}-error`, text: error })
  ] });
}
function PasswordField({
  id,
  label,
  error,
  value,
  onChange,
  autoComplete,
  placeholder,
  inputRef,
  autoFocus
}) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { htmlFor: id, className: "form-label", children: label }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      PasswordInput,
      {
        id,
        name: id,
        inputRef,
        className: "form-input password-input",
        value,
        onChange,
        autoComplete,
        placeholder,
        invalid: !!error,
        describedBy: error ? `${id}-error` : void 0,
        autoFocus
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { id: `${id}-error`, text: error })
  ] });
}
function Form({ className, title, onSubmit, children, busy }) {
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(
    "form",
    {
      className: `form ${className}`,
      noValidate: true,
      "aria-busy": busy || void 0,
      onSubmit: (e) => {
        e.preventDefault();
        if (!busy) onSubmit();
      },
      children: [
        /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", { className: "form-title", children: title }),
        children
      ]
    }
  );
}
function saveUserCopy(user) {
  writeJson(keys.user, {
    id: user.id,
    name: user.name,
    username: user.username,
    bio: user.bio,
    profilePics: user.profilePics,
    privacyOnline: user.privacyOnline,
    privacyEmail: user.privacyEmail,
    privacyProfile: user.privacyProfile
  });
}
function Login({
  notice,
  identifier,
  setIdentifier,
  onSignUp,
  onForgot
}) {
  const [password, setPassword] = (0, import_react.useState)("");
  const [remember, setRemember] = (0, import_react.useState)(() => !!read(REMEMBERED));
  const [errors, setErrors] = (0, import_react.useState)({});
  const [busy, setBusy] = (0, import_react.useState)(false);
  const idRef = (0, import_react.useRef)(null);
  const passRef = (0, import_react.useRef)(null);
  const submit = async () => {
    const next = {};
    if (!identifier.trim()) next.identifier = "Please enter your email or username.";
    if (password.length < PASSWORD_MIN) next.password = `Password must be at least ${PASSWORD_MIN} characters.`;
    setErrors(next);
    if (next.identifier) return idRef.current?.focus();
    if (next.password) return passRef.current?.focus();
    setBusy(true);
    try {
      const { user } = await authApi.login(identifier.trim(), password);
      write(REMEMBERED, remember ? identifier.trim() : null);
      saveUserCopy(user);
      window.location.replace(CHAT_PAGE);
    } catch (e) {
      setBusy(false);
      setErrors({ identifier: e instanceof ApiError && e.status === 401 ? "Invalid email, username or password." : errorText(e, "Couldn't sign in. Please try again.") });
      idRef.current?.focus();
    }
  };
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Form, { className: "login", title: "Welcome", onSubmit: () => void submit(), busy, children: [
    notice && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "auth-notice", role: "status", children: notice }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      TextField,
      {
        id: "login-username",
        label: "Email or Username",
        inputRef: idRef,
        value: identifier,
        onChange: setIdentifier,
        error: errors.identifier,
        autoComplete: "username",
        autoCapitalize: "none",
        placeholder: "Email or Username",
        autoFocus: !identifier
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      PasswordField,
      {
        id: "login-password",
        label: "Password",
        inputRef: passRef,
        value: password,
        onChange: setPassword,
        error: errors.password,
        autoComplete: "current-password",
        placeholder: "Password",
        autoFocus: !!identifier
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { className: "form-row", children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { type: "checkbox", id: "remember", className: "checkbox", checked: remember, onChange: (e) => setRemember(e.target.checked) }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", { htmlFor: "remember", className: "form-label", children: "Remember Me" }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "link-btn forgotpass", onClick: onForgot, children: "Forgot Password?" })
    ] }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "submit", className: "form-submit", disabled: busy, children: busy ? "Logging in\u2026" : "Log In" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "link-btn signuplink", onClick: onSignUp, children: "Don't have an account? Sign up" })
  ] });
}
function SignUpForm({ data, setData, onCodeSent, onLogin }) {
  const [errors, setErrors] = (0, import_react.useState)({});
  const [busy, setBusy] = (0, import_react.useState)(false);
  const refs = { name: (0, import_react.useRef)(null), email: (0, import_react.useRef)(null), username: (0, import_react.useRef)(null) };
  const submit = async () => {
    const name = data.name.trim();
    const email = data.email.trim();
    const username = data.username.trim().replace(/^@/, "");
    const next = {};
    if (name.length < 2 || name.length > 100) next.name = "Name must be 2-100 characters.";
    if (!isEmail(email)) next.email = "Please enter a valid email address.";
    if (!USERNAME_RE.test(username)) next.username = "Username must be 3-30 characters, letters, numbers, or underscores only.";
    setErrors(next);
    const first = ["name", "email", "username"].find((k) => next[k]);
    if (first) return refs[first].current?.focus();
    setBusy(true);
    try {
      try {
        const taken = await authApi.checkAvailability(username);
        if (taken.usernameTaken) {
          setErrors({ username: "This username is already taken." });
          refs.username.current?.focus();
          return;
        }
      } catch (e) {
        if (e instanceof ApiError && e.status === 429) throw e;
      }
      await authApi.sendCode(email);
      write(RESEND_KEY, String(Date.now() + RESEND_MS));
      setData({ name, email, username });
      onCodeSent();
    } catch (e) {
      setErrors({ email: errorText(e, "Couldn't send the code. Please try again.") });
      refs.email.current?.focus();
    } finally {
      setBusy(false);
    }
  };
  const set = (k) => (v) => setData({ ...data, [k]: v });
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Form, { className: "signup", title: "Sign Up", onSubmit: () => void submit(), busy, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TextField, { id: "name", label: "Name", inputRef: refs.name, value: data.name, onChange: set("name"), error: errors.name, autoComplete: "name", placeholder: "Your name", maxLength: 100, dir: "auto", autoFocus: true }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      TextField,
      {
        id: "email",
        label: "Email",
        type: "email",
        inputMode: "email",
        inputRef: refs.email,
        value: data.email,
        onChange: set("email"),
        error: errors.email,
        autoComplete: "email",
        autoCapitalize: "none",
        placeholder: "you@example.com"
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      TextField,
      {
        id: "username",
        label: "Username",
        inputRef: refs.username,
        value: data.username,
        onChange: set("username"),
        error: errors.username,
        autoComplete: "username",
        autoCapitalize: "none",
        placeholder: "your_username",
        maxLength: 31
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "submit", className: "form-submit", disabled: busy, children: busy ? "Sending code\u2026" : "Submit" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "link-btn loginlink", onClick: onLogin, children: "Already have an account? Log in" })
  ] });
}
function useResendWait() {
  const [until, setUntil] = (0, import_react.useState)(() => Number(read(RESEND_KEY)) || 0);
  const [now, setNow] = (0, import_react.useState)(() => Date.now());
  (0, import_react.useEffect)(() => {
    if (until <= Date.now()) return void 0;
    const t = window.setInterval(() => {
      const n = Date.now();
      setNow(n);
      if (n >= until) {
        window.clearInterval(t);
        write(RESEND_KEY, null);
      }
    }, 1e3);
    return () => window.clearInterval(t);
  }, [until]);
  const restart = () => {
    const u = Date.now() + RESEND_MS;
    write(RESEND_KEY, String(u));
    setNow(Date.now());
    setUntil(u);
  };
  return [Math.max(0, Math.ceil((until - now) / 1e3)), restart];
}
function Verify({ email, onVerified, onBack }) {
  const [digits, setDigits] = (0, import_react.useState)(() => Array(CODE_LENGTH).fill(""));
  const [error, setError] = (0, import_react.useState)("");
  const [busy, setBusy] = (0, import_react.useState)(false);
  const [resending, setResending] = (0, import_react.useState)(false);
  const [wait, restartWait] = useResendWait();
  const inputs = (0, import_react.useRef)([]);
  (0, import_react.useEffect)(() => {
    inputs.current[0]?.focus();
  }, []);
  const setFrom = (start, text) => {
    const clean = text.replace(/\D/g, "");
    if (!clean) return;
    setDigits((d) => {
      const next = [...d];
      for (let i = 0; i < clean.length && start + i < CODE_LENGTH; i++) next[start + i] = clean[i];
      return next;
    });
    setError("");
    inputs.current[Math.min(start + clean.length, CODE_LENGTH - 1)]?.focus();
  };
  const submit = async () => {
    const code = digits.join("");
    if (code.length < CODE_LENGTH) {
      setError(`Please enter the full ${CODE_LENGTH}-digit code.`);
      inputs.current[digits.findIndex((d) => !d)]?.focus();
      return;
    }
    setBusy(true);
    try {
      await authApi.verifyCode(email, code);
      onVerified();
    } catch (e) {
      setBusy(false);
      setError(e instanceof ApiError && e.status === 400 ? "The code is incorrect. Please try again." : errorText(e, "Couldn't check the code. Please try again."));
      setDigits(Array(CODE_LENGTH).fill(""));
      inputs.current[0]?.focus();
    }
  };
  const resend = async () => {
    if (wait > 0 || resending) return;
    setResending(true);
    setError("");
    setDigits(Array(CODE_LENGTH).fill(""));
    try {
      await authApi.sendCode(email);
      restartWait();
      inputs.current[0]?.focus();
    } catch (e) {
      setError(errorText(e, "Couldn't resend the code. Please try again."));
    } finally {
      setResending(false);
    }
  };
  const clock = wait > 0 ? `${Math.floor(wait / 60)}:${String(wait % 60).padStart(2, "0")}` : "Resend";
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Form, { className: "verify", title: "Verify it's you", onSubmit: () => void submit(), busy, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "link-btn go-back", onClick: onBack, children: "Back" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "form-subtitle", id: "code-help", children: "Please enter the code sent to your email address. If it already has a Rivo account, we sent sign-in help there instead." }),
    error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "input-error code-error", id: "code-error", role: "alert", children: error }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "code-inputs", role: "group", "aria-label": "Verification code", "aria-describedby": error ? "code-error" : "code-help", children: digits.map((d, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "input",
      {
        ref: (el) => {
          inputs.current[i] = el;
        },
        className: "form-input code-digit",
        inputMode: "numeric",
        autoComplete: i === 0 ? "one-time-code" : "off",
        maxLength: i === 0 ? CODE_LENGTH : 1,
        "aria-label": `Digit ${i + 1}`,
        "aria-invalid": error ? true : void 0,
        value: d,
        onChange: (e) => {
          const v = e.target.value.replace(/\D/g, "");
          if (v.length > 1) return setFrom(i, v);
          setDigits((all) => {
            const next = [...all];
            next[i] = v;
            return next;
          });
          setError("");
          if (v && i < CODE_LENGTH - 1) inputs.current[i + 1]?.focus();
        },
        onKeyDown: (e) => {
          if (e.key === "Backspace" && !d && i > 0) inputs.current[i - 1]?.focus();
          else if (e.key === "ArrowLeft" && i > 0) {
            e.preventDefault();
            inputs.current[i - 1]?.focus();
          } else if (e.key === "ArrowRight" && i < CODE_LENGTH - 1) {
            e.preventDefault();
            inputs.current[i + 1]?.focus();
          }
        },
        onPaste: (e) => {
          e.preventDefault();
          setFrom(i, e.clipboardData.getData("text"));
        },
        onFocus: (e) => e.currentTarget.select()
      },
      i
    )) }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "submit", className: "form-submit", disabled: busy, children: busy ? "Checking\u2026" : "Verify" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "timer", disabled: wait > 0 || resending, onClick: () => void resend(), "aria-label": wait > 0 ? `Resend the code in ${wait} seconds` : "Resend the code", children: clock })
  ] });
}
function SetPassword({ data, onDone, onBack }) {
  const [password, setPassword] = (0, import_react.useState)("");
  const [confirm, setConfirm] = (0, import_react.useState)("");
  const [errors, setErrors] = (0, import_react.useState)({});
  const [busy, setBusy] = (0, import_react.useState)(false);
  const passRef = (0, import_react.useRef)(null);
  const confirmRef = (0, import_react.useRef)(null);
  const submit = async () => {
    const next = {};
    if (password.length < PASSWORD_MIN) next.password = `Password must be at least ${PASSWORD_MIN} characters.`;
    else if (password.length > PASSWORD_MAX) next.password = "Password is too long.";
    if (confirm !== password) next.confirm = "Passwords do not match.";
    setErrors(next);
    if (next.password) return passRef.current?.focus();
    if (next.confirm) return confirmRef.current?.focus();
    setBusy(true);
    try {
      await authApi.register({ ...data, password });
      onDone();
    } catch (e) {
      setBusy(false);
      setErrors({ password: errorText(e, "Couldn't create your account. Please try again.") });
      passRef.current?.focus();
    }
  };
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Form, { className: "password", title: "Set Your Password", onSubmit: () => void submit(), busy, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "link-btn go-back", onClick: onBack, children: "Back" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", { type: "text", name: "username", autoComplete: "username", value: data.username, readOnly: true, className: "visually-hidden", tabIndex: -1, "aria-hidden": "true" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      PasswordField,
      {
        id: "password",
        label: "Password",
        inputRef: passRef,
        value: password,
        onChange: setPassword,
        error: errors.password,
        autoComplete: "new-password",
        placeholder: `${PASSWORD_MIN} or more characters`,
        autoFocus: true
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      PasswordField,
      {
        id: "confirm-password",
        label: "Confirm Password",
        inputRef: confirmRef,
        value: confirm,
        onChange: setConfirm,
        error: errors.confirm,
        autoComplete: "new-password",
        placeholder: "Re-enter your password"
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "submit", className: "form-submit", disabled: busy, children: busy ? "Creating account\u2026" : "Submit" })
  ] });
}
function Forgot({ initial, onSent, onBack }) {
  const [value, setValue] = (0, import_react.useState)(initial);
  const [error, setError] = (0, import_react.useState)();
  const [busy, setBusy] = (0, import_react.useState)(false);
  const input = (0, import_react.useRef)(null);
  const submit = async () => {
    const v = value.trim();
    if (!isEmail(v) && !USERNAME_RE.test(v.replace(/^@/, ""))) {
      setError("Please enter a valid email or username.");
      input.current?.focus();
      return;
    }
    setBusy(true);
    try {
      await authApi.requestPasswordReset(v.replace(/^@/, ""));
      onSent();
    } catch (e) {
      setBusy(false);
      setError(errorText(e, "Couldn't send the reset link. Please try again."));
      input.current?.focus();
    }
  };
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Form, { className: "forget-password", title: "We Got You", onSubmit: () => void submit(), busy, children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "button", className: "link-btn go-back", onClick: onBack, children: "Back" }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { className: "form-subtitle", children: "Please enter your username or email address to reset your password." }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      "input",
      {
        ref: input,
        id: "forgot-identifier",
        className: "form-input",
        autoComplete: "username",
        autoCapitalize: "none",
        spellCheck: false,
        placeholder: "Email or Username",
        "aria-label": "Email or Username",
        "aria-invalid": error ? true : void 0,
        "aria-describedby": error ? "forgot-identifier-error" : void 0,
        autoFocus: true,
        value,
        onChange: (e) => setValue(e.target.value)
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FieldError, { id: "forgot-identifier-error", text: error }),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", { type: "submit", className: "form-submit", disabled: busy, children: busy ? "Sending\u2026" : "Reset" })
  ] });
}
var START = (() => {
  const params = new URLSearchParams(window.location.search);
  const reset = params.get("reset") === "1";
  const forgot = params.get("forgot") === "1";
  if (reset || forgot) history.replaceState(history.state, "", window.location.pathname);
  return {
    step: forgot ? "forgot" : "login",
    notice: reset ? "Your password was changed. Sign in with your new password." : ""
  };
})();
function AuthApp() {
  const [step, setStep] = (0, import_react.useState)(START.step);
  const [notice, setNotice] = (0, import_react.useState)(START.notice);
  const [identifier, setIdentifier] = (0, import_react.useState)(() => read(REMEMBERED) ?? "");
  const [signUp, setSignUp] = (0, import_react.useState)({ name: "", email: "", username: "" });
  (0, import_react.useEffect)(() => {
    if (!read(keys.user)) return;
    fetch("/api/users/me", { credentials: "same-origin", cache: "no-store" }).then((r) => {
      if (r.ok) window.location.replace(CHAT_PAGE);
    }).catch(() => void 0);
  }, []);
  const go = (s) => setStep(s);
  return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { className: "container", children: [
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "circle-top", "aria-hidden": "true" }),
    step === "login" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      Login,
      {
        notice,
        identifier,
        setIdentifier,
        onSignUp: () => {
          setNotice("");
          go("signup");
        },
        onForgot: () => {
          setNotice("");
          go("forgot");
        }
      }
    ),
    step === "signup" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignUpForm, { data: signUp, setData: setSignUp, onCodeSent: () => go("verify"), onLogin: () => go("login") }),
    step === "verify" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Verify, { email: signUp.email, onVerified: () => go("password"), onBack: () => go("signup") }),
    step === "password" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      SetPassword,
      {
        data: signUp,
        onBack: () => go("login"),
        onDone: () => {
          setIdentifier(signUp.username);
          setSignUp({ name: "", email: "", username: "" });
          setNotice("Your account is ready. Sign in with your new password.");
          go("login");
        }
      }
    ),
    step === "forgot" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(
      Forgot,
      {
        initial: identifier,
        onBack: () => go("login"),
        onSent: () => {
          setNotice("If the account exists, a password reset link is on its way to its email.");
          go("login");
        }
      }
    ),
    /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "circle-bottom", "aria-hidden": "true" })
  ] });
}

// client/auth/main.tsx
var import_jsx_runtime2 = __toESM(require_jsx_runtime(), 1);
(0, import_client.createRoot)(document.getElementById("root")).render(
  /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(import_react2.StrictMode, { children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(AuthApp, {}) })
);
//# sourceMappingURL=auth-DGFREXSC.js.map
